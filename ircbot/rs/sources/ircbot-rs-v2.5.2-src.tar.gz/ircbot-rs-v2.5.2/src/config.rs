//! The encrypted config file and the record codecs shared with the hub
//! (config.c).
//!
//! On disk: salt(16) || iv(12) || tag(16) || AES-256-GCM(ciphertext) under
//! PBKDF2-HMAC-SHA256(password, salt).  The plaintext is one record per
//! line, `X|fields...`, the same shapes irchub sends in CMD_CONFIG_DATA.

use std::fs::{self, OpenOptions};
use std::io::{Read, Write};
use std::os::unix::fs::{OpenOptionsExt, PermissionsExt};

use zeroize::Zeroizing;

use crate::consts::*;
use crate::crypto::{self, Key32};
use crate::cstr::{Scan, atoll, is_uuid, now, split_fields, strtoll, trunc_string};
use crate::secret::Locked;
use crate::state::{
    BotState, ChanStatus, HubEntry, MaskRecord, TrustedBot, UserLine, UserRecord, lww_accepts,
};
use crate::{access, chancfg, channel, hub_client, logm};

/// A key-shaped field: Some(b64) only if it is exactly a valid key.
fn field_pubkey(f: &str) -> Option<String> {
    if f.len() != COMBINED_KEY_B64 {
        return None;
    }
    crypto::pubkey_b64_decode(f).map(|_| f.to_string())
}

/// a|/o| body codec (irchub/docs/passwordless.md 3.1):
///   uuid|name|pubkey|add/del|last_seen|ts|<reserved, empty>
/// pubkey may be empty (a user not given a key yet); anything else that is
/// not a valid key refuses the line.
pub fn parse_user_line(data: &str) -> Option<UserLine> {
    let f = split_fields(data, 8);
    if f.len() < 6 || !is_uuid(f[0]) {
        return None;
    }
    if f[1].is_empty() || f[1].len() >= USER_NAME_BUF {
        return None;
    }
    let mut out = UserLine {
        uuid: f[0].to_string(),
        name: f[1].to_string(),
        ..UserLine::default()
    };
    if !f[2].is_empty() {
        out.pubkey_b64 = field_pubkey(f[2])?;
        out.has_pubkey = true;
    }
    out.is_active = f[3] == "add";
    out.last_seen = atoll(f[4]);
    out.timestamp = atoll(f[5]);
    Some(out)
}

/// One user record as a full "a|...\n" / "o|...\n" line.
pub fn format_user_line(u: &UserRecord) -> String {
    format!(
        "{}|{}|{}|{}|{}|{}|{}|\n",
        u.typ,
        u.uuid,
        u.name,
        if u.has_pubkey {
            u.pubkey_b64.as_str()
        } else {
            ""
        },
        if u.is_active { "add" } else { "del" },
        u.last_seen,
        u.timestamp
    )
}

/// b| body codec (passwordless.md 3.2):
///   mask|uuid|pubkey|ts       (pubkey may be empty)
/// Oversized fields are refused rather than truncated.
pub fn parse_bot_line(data: &str) -> Option<TrustedBot> {
    let f = split_fields(data, 5);
    if f.len() < 4 || f[0].is_empty() || f[0].len() >= MAX_MASK_LEN {
        return None;
    }
    let mut out = TrustedBot {
        mask: f[0].to_string(),
        ..TrustedBot::default()
    };
    if f[1].len() >= UUID_BUF {
        return None;
    }
    out.uuid = f[1].to_string();
    if !f[2].is_empty()
        && let Some(k) = field_pubkey(f[2]).and_then(|b| crypto::pubkey_b64_decode(&b))
    {
        out.pub_key = k;
        out.has_pub = true;
    }
    out.ts = atoll(f[3]);
    Some(out)
}

/// One trusted bot as a full "b|...\n" line (new format).
pub fn format_bot_line(tb: &TrustedBot) -> String {
    let pb = if tb.has_pub {
        crypto::b64_encode(&tb.pub_key)
    } else {
        String::new()
    };
    format!("b|{}|{}|{}|{}\n", tb.mask, tb.uuid, pb, tb.ts)
}

/// "m|uuid|mask|add/del|last_used|ts\n".
pub fn format_mask_line(m: &MaskRecord) -> String {
    format!(
        "m|{}|{}|{}|{}|{}\n",
        m.uuid,
        m.mask,
        if m.is_active { "add" } else { "del" },
        m.last_used,
        m.timestamp
    )
}

/// Keep only [a-zA-Z0-9] of an opt-flag string, at most MAX_OPT_FLAGS.
pub fn clean_opt_flags(s: &str) -> String {
    s.chars()
        .filter(|c| c.is_ascii_alphanumeric())
        .take(MAX_OPT_FLAGS)
        .collect()
}

/// Parse "O|<flags>|<ts>" data (also the hub's form).  "O||<ts>" is a
/// persisted clear.  None when sscanf would have matched nothing.
pub fn parse_opt_line(data: &str) -> Option<(String, i64)> {
    if let Some(rest) = data.strip_prefix('|') {
        let (v, used) = strtoll(rest);
        return (used > 0).then(|| (String::new(), v));
    }
    let mut sc = Scan::new(data);
    let flags = sc.set_not(MAX_OPT_FLAGS, b"|")?;
    let ts = if sc.lit(b'|') {
        sc.int().unwrap_or(0)
    } else {
        0
    };
    Some((clean_opt_flags(flags), ts))
}

/// Parse a c| body from the config: channel|key|add/del|timestamp, or
/// channel||add/del|timestamp.  Returns (chan, key, op, ts) when at least
/// the channel and op matched (sscanf count >= 2 on either form).
fn parse_cfg_chan(data: &str) -> Option<(String, String, String, i64)> {
    let mut chan = String::new();
    let mut key = String::new();
    let mut op = String::new();
    let mut ts = 0i64;
    let mut parsed = 0;
    {
        let mut sc = Scan::new(data);
        if let Some(c) = sc.set_not(64, b"|") {
            chan = c.to_string();
            parsed = 1;
            if sc.lit(b'|')
                && let Some(k) = sc.set_not(30, b"|")
            {
                key = k.to_string();
                parsed = 2;
                if sc.lit(b'|')
                    && let Some(o) = sc.set_not(15, b"|")
                {
                    op = o.to_string();
                    parsed = 3;
                    if sc.lit(b'|')
                        && let Some(t) = sc.int()
                    {
                        ts = t;
                        parsed = 4;
                    }
                }
            }
        }
    }
    if parsed < 3 {
        // Fallback for an empty key.
        key.clear();
        parsed = 0;
        let mut sc = Scan::new(data);
        if let Some(c) = sc.set_not(64, b"|") {
            chan = c.to_string();
            parsed = 1;
            if sc.lit(b'|')
                && sc.lit(b'|')
                && let Some(o) = sc.set_not(15, b"|")
            {
                op = o.to_string();
                parsed = 2;
                if sc.lit(b'|')
                    && let Some(t) = sc.int()
                {
                    ts = t;
                    parsed = 3;
                }
            }
        }
    }
    (parsed >= 2).then_some((chan, key, op, ts))
}

/// Read and decrypt the config file (PBKDF2_ITERATIONS only).
fn decrypt_file(state: &BotState, password: &str, filename: &str) -> Option<Zeroizing<Vec<u8>>> {
    let mut f = fs::File::open(filename).ok()?;
    let mut data = Vec::new();
    if f.read_to_end(&mut data).is_err() {
        logm!(
            state,
            L_INFO,
            "[CFG] Error: Could not read the full contents of the config file.\n"
        );
        return None;
    }
    if data.len() < SALT_SIZE {
        logm!(state, L_INFO, "[CFG] Failed to read Salt from config.\n");
        return None;
    }
    if data.len() < SALT_SIZE + GCM_IV_LEN + GCM_TAG_LEN {
        logm!(state, L_INFO, "[CFG] Failed to read IV/Tag from config.\n");
        return None;
    }
    let salt = &data[..SALT_SIZE];
    let iv = &data[SALT_SIZE..SALT_SIZE + GCM_IV_LEN];
    let tag = &data[SALT_SIZE + GCM_IV_LEN..SALT_SIZE + GCM_IV_LEN + GCM_TAG_LEN];
    let ct = &data[SALT_SIZE + GCM_IV_LEN + GCM_TAG_LEN..];
    if ct.is_empty() || ct.len() > MAX_CONFIG_SIZE {
        logm!(
            state,
            L_INFO,
            "[CFG] Error: Config file is empty or too large (Max 1MB).\n"
        );
        return None;
    }
    let key = crypto::derive_config_key(password.as_bytes(), salt, PBKDF2_ITERATIONS);
    if let Some(pt) = crypto::gcm_decrypt_detached(key.as_ref(), iv, &[], ct, tag) {
        cfg_key_keep(salt, &key);
        return Some(pt);
    }
    logm!(
        state,
        L_INFO,
        "[CFG] Decryption failed (wrong password, or a config written before 2.5.0: run 2.5.0 once).\n"
    );
    None
}

/// Review 23: the config key, derived once per process (the first load or
/// write) and reused.  A 600k-round PBKDF2 on every write froze the bot for
/// ~0.5 s, and any chanop toggling +k/-k could trigger one.  The key is bound
/// to the salt it was derived with (`salt || key`), which every later write
/// reuses under a fresh IV.  A process has one password (the startup one), so
/// nothing else invalidates it; mlock'd like that password, wiped by
/// `key_forget` at shutdown (and on drop).
static CFG_KEY: std::sync::Mutex<Option<Locked<{ SALT_SIZE + 32 }>>> = std::sync::Mutex::new(None);

fn cfg_key_keep(salt: &[u8], key: &[u8; 32]) {
    let mut sk = Zeroizing::new([0u8; SALT_SIZE + 32]);
    sk[..SALT_SIZE].copy_from_slice(salt);
    sk[SALT_SIZE..].copy_from_slice(key);
    if let Ok(mut g) = CFG_KEY.lock() {
        g.get_or_insert_with(Locked::new).set(&sk);
    }
}

/// The cached (salt, key), if a load or write has derived one.
fn cfg_key_cached() -> Option<([u8; SALT_SIZE], Key32)> {
    let g = CFG_KEY.lock().ok()?;
    let sk = g.as_ref()?.get();
    let mut salt = [0u8; SALT_SIZE];
    salt.copy_from_slice(&sk[..SALT_SIZE]);
    let mut key = Key32::new([0u8; 32]);
    key.copy_from_slice(&sk[SALT_SIZE..]);
    Some((salt, key))
}

pub fn key_forget() {
    if let Ok(mut g) = CFG_KEY.lock() {
        *g = None;
    }
}

/// Set by `-selftest`: load() must not rewrite the file the running build
/// owns, whatever migration it would otherwise do.
pub static READ_ONLY: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);

/// config_load(): false when the file is missing, does not decrypt, or lacks
/// a nick, server or ident.
pub fn load(state: &mut BotState, password: &str, filename: &str) -> bool {
    if let Ok(md) = fs::metadata(filename) {
        let mode = md.permissions().mode();
        if mode & 0o177 != 0 {
            logm!(
                state,
                L_INFO,
                "[CFG] WARN: {} has insecure permissions {:04o} — should be 0600\n",
                filename,
                mode & 0o777
            );
        }
    }
    let Some(plaintext) = decrypt_file(state, password, filename) else {
        return false;
    };
    let text = Zeroizing::new(String::from_utf8_lossy(&plaintext).into_owned());
    drop(plaintext);

    for raw in text.split('\n') {
        let line = raw.strip_suffix('\r').unwrap_or(raw);
        let line = crate::cstr::until_nul(line);
        // uf| / uc|: admin flags and oper channel bindings (access.rs);
        // users load first in this file, records of a user that never loads
        // go with access::prune below
        if let Some(body) = line
            .strip_prefix("uf|")
            .or_else(|| line.strip_prefix("uc|"))
        {
            if access::ingest(state, line.as_bytes()[1] as char, body, false).is_none() {
                logm!(
                    state,
                    L_INFO,
                    "[CFG] Ignoring invalid {}| line\n",
                    &line[..2]
                );
            }
            continue;
        }
        if line.len() < 2 || line.starts_with('#') || line.as_bytes()[1] != b'|' {
            continue;
        }
        let typ = line.as_bytes()[0];
        let data = &line[2..];
        match typ {
            b'n' => state.target_nick = trunc_string(data, MAX_NICK),
            b's' => {
                if state.server_list.len() < MAX_SERVERS {
                    state.server_list.push(data.to_string());
                }
            }
            b'c' => {
                if let Some((chan, key, op, ts)) = parse_cfg_chan(data) {
                    // Channel names match regardless of ASCII case (D39): a
                    // file that holds both "#Chan" and "#chan" merges into
                    // one entry, the newest stamp winning (the first
                    // writer's spelling is kept).
                    let is_add = op != "del";
                    let eff_ts = if ts > 0 { ts } else { now() };
                    if let Some(ci) = channel::find(state, &chan) {
                        let c = &mut state.chans[ci];
                        // timestamp 0 = a C| line got here first (held
                        // unmanaged)
                        if c.timestamp == 0
                            || lww_accepts(eff_ts, is_add, c.timestamp, c.is_managed)
                        {
                            c.ckey = trunc_string(&key, MAX_KEY);
                            c.is_managed = is_add;
                            c.timestamp = eff_ts;
                            if !c.is_managed {
                                c.status = ChanStatus::Out;
                                channel::learned_forget(c);
                            }
                            channel::key_refresh(c);
                        }
                    } else if let Some(ci) = channel::add(state, &chan) {
                        let c = &mut state.chans[ci];
                        if !key.is_empty() {
                            c.ckey = trunc_string(&key, MAX_KEY);
                        }
                        c.is_managed = is_add;
                        c.timestamp = eff_ts;
                        channel::key_refresh(c);
                        // Don't join deleted channels
                        if !c.is_managed {
                            c.status = ChanStatus::Out;
                        }
                    }
                }
            }
            b'C' => {
                chancfg::apply_c_line(state, data);
            }
            // K|#chan|key|modes|ts: learned on IRC, after its c| line
            b'K' => {
                channel::learned_ingest(state, data);
            }
            b'B' => {
                chancfg::apply_b_line(state, data);
            }
            b'm' => load_mask_line(state, data),
            b'a' | b'o' => {
                if state.user_records.len() >= MAX_USER_RECORDS {
                    continue;
                }
                let Some(ul) = parse_user_line(data) else {
                    logm!(
                        state,
                        L_INFO,
                        "[CFG] Malformed {}| record ignored.\n",
                        typ as char
                    );
                    continue;
                };
                state.user_records.push(UserRecord {
                    uuid: ul.uuid,
                    name: ul.name,
                    pubkey_b64: ul.pubkey_b64,
                    has_pubkey: ul.has_pubkey,
                    typ: typ as char,
                    is_active: ul.is_active,
                    last_seen: ul.last_seen,
                    timestamp: ul.timestamp,
                    last_auth_reply: 0,
                    act_pending: 0,
                });
            }
            b'b' => {
                if state.trusted_bots.len() < MAX_TRUSTED_BOTS {
                    match parse_bot_line(data) {
                        Some(tb) => state.trusted_bots.push(tb),
                        None => logm!(
                            state,
                            L_INFO,
                            "[CFG] Malformed or oversized b| line ignored.\n"
                        ),
                    }
                }
            }
            b'l' => state.log.level = crate::cstr::atoi(data) as u32,
            b'L' => {
                let cap = data.trim().parse::<u64>().unwrap_or(0);
                state.log.max_size = cap.clamp(BOT_LOG_SIZE_MIN, BOT_LOG_SIZE_MAX);
            }
            b'u' => state.user = trunc_string(data, 64),
            b'g' => state.gecos = trunc_string(data, 128),
            b'v' => state.vhost = trunc_string(data, 128),
            b'h' => load_hub_line(state, data),
            b'k' => match crypto::b64_decode(data) {
                Some(dec) if dec.len() == HUB_KEY_RAW_LEN => {
                    *state.hub_key = trunc_string(data, MAX_HUB_KEY_SIZE);
                    let mut raw = [0u8; HUB_KEY_RAW_LEN];
                    raw.copy_from_slice(&dec);
                    state.hub_key_raw.set(&raw);
                    crypto::wipe(&mut raw);
                }
                _ => logm!(
                    state,
                    L_INFO,
                    "[CFG] Bot key in config is not a valid 64-byte Curve25519 key. Re-run 'ircbot -setup' to regenerate the bot's identity.\n"
                ),
            },
            b'i' => state.bot_uuid = trunc_string(data, 64),
            // D|1: user/mask changes made while the hub was unreachable are
            // still to be pushed (admin_delta_pending).  A D| line with
            // fields (D|<modes>|<settings>|<ts>) is the network defaults
            // record; the two never share a shape.
            b'D' => {
                if !data.contains('|') {
                    state.admin_delta_pending = data == "1";
                } else {
                    chancfg::apply_d_line(state, data);
                }
            }
            b'O' => {
                if let Some((flags, ts)) = parse_opt_line(data) {
                    state.opt_flags = flags;
                    state.opt_flags_ts = if ts > 0 { ts } else { now() };
                }
            }
            _ => {}
        }
    }
    drop(text);

    // Identity key: a standalone config from before bots had keys gets one
    // minted here.  A hub-managed bot without one must re-run -setup.
    let mut identity_minted = false;
    if state.hub_key.is_empty() && state.hubs.is_empty() {
        match crypto::generate_combined_keypair() {
            Some((priv_key, _)) => {
                *state.hub_key = crypto::b64_encode(priv_key.as_ref());
                state.hub_key_raw.set(&priv_key);
                identity_minted = true;
            }
            None => logm!(state, L_INFO, "[CFG] Could not generate an identity key.\n"),
        }
    }
    if state.bot_uuid.is_empty()
        && state.hubs.is_empty()
        && let Some(u) = crypto::gen_uuid_v4()
    {
        state.bot_uuid = u;
        identity_minted = true;
    }
    if !hub_client::self_pub_refresh(state) {
        logm!(
            state,
            L_INFO,
            "[CFG] No usable identity key (k|): admin commands and bot-to-bot messages cannot be decrypted. Re-run -setup.\n"
        );
    } else if identity_minted {
        let fp = crypto::key_fingerprint(&state.self_pub);
        eprintln!(
            "[CFG] Generated this bot's identity key. Public key: {} (fp {})",
            crypto::b64_encode(&state.self_pub),
            fp
        );
        logm!(state, L_INFO, "[CFG] Generated identity key, fp {}\n", fp);
    }

    for i in 0..state.user_records.len() {
        let u = &state.user_records[i];
        if u.is_active && !u.has_pubkey {
            logm!(
                state,
                L_INFO,
                "[CFG] {} '{}' has no public key and cannot authenticate until given one (chkey, or the hub console's 'userkey' command).\n",
                if u.typ == 'a' { "Admin" } else { "Oper" },
                u.name
            );
        }
    }
    // Flags / bindings: drop those with no user, then give every user that
    // has none what they could do before flags (admins +a, opers *).
    let access_before = state.uflag_records.len() + state.uchan_records.len();
    access::prune(state);
    let mut access_changed = state.uflag_records.len() + state.uchan_records.len() != access_before;
    access_changed |= access::migrate(state) > 0;

    // Rewrite once if anything above changed the on-disk shape — never from
    // `-selftest`, which only asks whether this build could read it.
    if !READ_ONLY.load(std::sync::atomic::Ordering::Relaxed) && (identity_minted || access_changed)
    {
        write(state, password);
    }

    if state.target_nick.is_empty() || state.server_list.is_empty() || state.user.is_empty() {
        logm!(
            state,
            L_INFO,
            "[CFG] Config file is missing required fields (Nick, Server, or Ident).\n"
        );
        return false;
    }
    true
}

/// m| line: uuid|mask|add/del|last_used|ts.
fn load_mask_line(state: &mut BotState, data: &str) {
    if state.mask_records.len() >= MAX_USER_MASKS {
        return;
    }
    let f = split_fields(data, 5);
    if f.len() < 5 || !is_uuid(f[0]) || f[1].is_empty() || f[1].len() >= MAX_MASK_LEN {
        return;
    }
    state.mask_records.push(MaskRecord {
        uuid: f[0].to_string(),
        mask: f[1].to_string(),
        is_active: f[2] == "add",
        last_used: atoll(f[3]),
        timestamp: atoll(f[4]),
        act_pending: 0,
    });
}

/// h|<host:port>[|<pubkey_b64>]: the pin is the hub's Ed25519 key, 44-char
/// (32 raw bytes) or 88-char (combined key; first 32 bytes).
fn load_hub_line(state: &mut BotState, data: &str) {
    if state.hubs.len() >= MAX_SERVERS {
        return;
    }
    let mut he = HubEntry::default();
    match data.find('|') {
        Some(bar) => {
            he.addr = trunc_string(&data[..bar], 256);
            match crypto::b64_decode(&data[bar + 1..]) {
                Some(dec) if dec.len() == 32 || dec.len() == HUB_KEY_RAW_LEN => {
                    he.ed_pub.copy_from_slice(&dec[..32]);
                    he.ed_pub_set = true;
                }
                _ => logm!(
                    state,
                    L_INFO,
                    "[CFG] Hub '{}' pubkey is not a valid Ed25519/Curve25519 key — re-add with '+hub {} <pubkey>'.\n",
                    he.addr,
                    he.addr
                ),
            }
        }
        None => he.addr = trunc_string(data, 256),
    }
    state.hubs.push(he);
}

/// Serialize the state.  None if the result would exceed MAX_CONFIG_SIZE
/// (a truncated write would silently drop records).
fn serialize(state: &BotState) -> Option<Zeroizing<String>> {
    let mut out = Zeroizing::new(String::with_capacity(4096));
    let mut push = |s: &str| out.push_str(s);
    push(&format!("n|{}\n", state.target_nick));
    for s in &state.server_list {
        push(&format!("s|{s}\n"));
    }
    for c in &state.chans {
        // A channel known only from its C| line (no c| yet) has no record of
        // its own to write.
        if c.timestamp == 0 && !c.is_managed {
            continue;
        }
        push(&format!(
            "c|{}|{}|{}|{}\n",
            c.name,
            c.ckey,
            if c.is_managed { "add" } else { "del" },
            c.timestamp
        ));
    }
    // K|: what this bot saw on IRC, after every c| it needs at load.
    for c in state.chans.iter().filter(|c| c.is_managed && c.l_ts > 0) {
        push(&channel::format_k(c));
    }
    // modes.md records: per-channel settings, network defaults, bans.  Raw
    // settings text goes back out unchanged, unknown names included.
    for c in &state.chans {
        push(&chancfg::format_c_line(c)?);
    }
    push(&chancfg::format_d_line(state)?);
    for b in &state.cfg_bans {
        push(&chancfg::format_b_line(b)?);
    }
    for u in &state.user_records {
        let l = format_user_line(u);
        if l.len() >= CFG_USER_LINE_MAX {
            return None;
        }
        push(&l);
    }
    for m in &state.mask_records {
        push(&format_mask_line(m));
    }
    // admin flags and oper channel bindings, after the users they name
    for r in &state.uflag_records {
        push(&access::format_uflag(r));
    }
    for r in &state.uchan_records {
        push(&access::format_uchan(r));
    }
    for tb in &state.trusted_bots {
        let l = format_bot_line(tb);
        if l.len() >= CFG_BLINE_MAX {
            return None;
        }
        push(&l);
    }
    if state.log.level != DEFAULT_LOG_LEVEL {
        push(&format!("l|{}\n", state.log.level as i32));
    }
    if state.log.max_size != BOT_LOG_FILE_SIZE {
        push(&format!("L|{}\n", state.log.max_size));
    }
    push(&format!("u|{}\n", state.user));
    push(&format!("g|{}\n", state.gecos));
    if !state.vhost.is_empty() {
        push(&format!("v|{}\n", state.vhost));
    }
    // Per-hub pins.
    for h in &state.hubs {
        if h.ed_pub_set {
            push(&format!("h|{}|{}\n", h.addr, crypto::b64_encode(&h.ed_pub)));
        } else {
            push(&format!("h|{}\n", h.addr));
        }
    }
    if !state.hub_key.is_empty() {
        let mut k = Zeroizing::new(String::from("k|"));
        k.push_str(&state.hub_key);
        k.push('\n');
        push(&k);
    }
    if !state.bot_uuid.is_empty() {
        push(&format!("i|{}\n", state.bot_uuid));
    }
    // Written with a timestamp even when empty, so a clear survives restart.
    if !state.opt_flags.is_empty() || state.opt_flags_ts > 0 {
        push(&format!("O|{}|{}\n", state.opt_flags, state.opt_flags_ts));
    }
    if state.admin_delta_pending {
        push("D|1\n");
    }
    (out.len() < MAX_CONFIG_SIZE).then_some(out)
}

/// Serialize and encrypt to CONFIG_FILE through a 0600 temp file and a
/// rename.  Does NOT push to the hub.
fn write_file(state: &BotState, password: &str) {
    if state.retired {
        return; // wiped on the hub's order: stays gone
    }
    if password.len() >= MAX_PASS {
        return;
    }
    let Some(plaintext) = serialize(state) else {
        eprintln!("[CFG] Config exceeds {MAX_CONFIG_SIZE} bytes; NOT written (old config kept).");
        return;
    };
    if plaintext.is_empty() {
        let _ = fs::remove_file(CONFIG_FILE);
        return;
    }
    let (salt, key) = match cfg_key_cached() {
        Some(sk) => sk,
        None => {
            let mut salt = [0u8; SALT_SIZE];
            if !crypto::random_bytes(&mut salt) {
                eprintln!("[CFG] RNG/KDF failure; aborting config write.");
                return;
            }
            let key = crypto::derive_config_key(password.as_bytes(), &salt, PBKDF2_ITERATIONS);
            cfg_key_keep(&salt, &key);
            (salt, key)
        }
    };
    let mut iv = [0u8; GCM_IV_LEN];
    if !crypto::random_bytes(&mut iv) {
        eprintln!("[CFG] RNG/KDF failure; aborting config write.");
        return;
    }
    let Some((ct, tag)) =
        crypto::gcm_encrypt_detached(key.as_ref(), &iv, &[], plaintext.as_bytes())
    else {
        return;
    };
    drop(plaintext);

    let temp_file = format!("{CONFIG_FILE}.tmp");
    let mut f = match OpenOptions::new()
        .write(true)
        .create(true)
        .truncate(true)
        .mode(0o600)
        .open(&temp_file)
    {
        Ok(f) => f,
        Err(e) => {
            eprintln!("[CFG] Failed to open {temp_file} for writing: {e}");
            return;
        }
    };
    let ok = f.write_all(&salt).is_ok()
        && f.write_all(&iv).is_ok()
        && f.write_all(&tag).is_ok()
        && f.write_all(&ct).is_ok()
        && f.flush().is_ok()
        && f.sync_all().is_ok();
    drop(f);
    if !ok {
        eprintln!("[CFG] Failed to write config, keeping old config intact");
        let _ = fs::remove_file(&temp_file);
        return;
    }
    if let Err(e) = fs::rename(&temp_file, CONFIG_FILE) {
        eprintln!("[CFG] Failed to rename {temp_file} to {CONFIG_FILE}: {e}");
        let _ = fs::remove_file(&temp_file);
    }
}

/// config_write(): save, then push to the hub when authenticated.
pub fn write(state: &mut BotState, password: &str) {
    write_file(state, password);
    if !state.hubs.is_empty() && state.hub_authenticated {
        hub_client::push_config(state);
    }
}

/// config_write_local(): save only -- for data received FROM the hub, which
/// must not be echoed back.
pub fn write_local(state: &BotState, password: &str) {
    write_file(state, password);
}

pub fn write_with_state_pass(state: &mut BotState) {
    let pass = state.startup_pass();
    write(state, &pass);
}

pub fn write_local_with_state_pass(state: &BotState) {
    let pass = state.startup_pass();
    write_local(state, &pass);
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn user_line_codec() {
        let (_, p) = crypto::generate_combined_keypair().unwrap();
        let k = crypto::b64_encode(&p);
        let uuid = "12345678-1234-4234-8234-123456789abc";
        let ul = parse_user_line(&format!("{uuid}|bob|{k}|add|5|6|")).unwrap();
        assert!(ul.has_pubkey && ul.is_active);
        assert_eq!((ul.last_seen, ul.timestamp), (5, 6));
        let ul = parse_user_line(&format!("{uuid}|bob||del|0|9|")).unwrap();
        assert!(!ul.has_pubkey && !ul.is_active);
        // the password-era shape (field 3 not a key) is refused
        assert!(parse_user_line(&format!("{uuid}|bob|secret|del|0|9|{k}")).is_none());
        assert!(parse_user_line("nope|bob|x|add|0|0").is_none());
    }

    #[test]
    fn bot_line_shapes() {
        // only mask|uuid|pubkey|ts: the bare and three-field shapes are gone
        assert!(parse_bot_line("n!u@h").is_none());
        assert!(parse_bot_line("n!u@h|uuid|42").is_none());
        let tb = parse_bot_line("n!u@h|uuid||42").unwrap();
        assert!(!tb.has_pub && tb.ts == 42);
        let (_, p) = crypto::generate_combined_keypair().unwrap();
        let tb = parse_bot_line(&format!("n!u@h|uuid|{}|7", crypto::b64_encode(&p))).unwrap();
        assert!(tb.has_pub && tb.ts == 7);
        assert_eq!(
            format_bot_line(&tb),
            format!("b|n!u@h|uuid|{}|7\n", crypto::b64_encode(&p))
        );
    }

    #[test]
    fn chan_and_opt_lines() {
        assert_eq!(
            parse_cfg_chan("#a|k|add|5"),
            Some(("#a".into(), "k".into(), "add".into(), 5))
        );
        assert_eq!(
            parse_cfg_chan("#a||del|7"),
            Some(("#a".into(), String::new(), "del".into(), 7))
        );
        assert_eq!(parse_opt_line("|12"), Some((String::new(), 12)));
        assert_eq!(parse_opt_line("h-x|3"), Some(("hx".into(), 3)));
    }
}
