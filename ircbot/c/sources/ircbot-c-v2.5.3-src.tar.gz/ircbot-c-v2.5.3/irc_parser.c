#include <stdlib.h>
#include <string.h>
#include <strings.h>

#include "bot.h"

// [UPDATED] Helper to handle mode changes securely + immediate Op Recovery.
// True when a managed channel's learned key / +k+i changed (K|, to be pushed).
static bool channel_handle_mode_change(bot_state_t *state, const char *channel,
                                       const char *modes, char *args) {
  chan_t *c = channel_find(state, channel);
  if (!c)
    return false;
  /* What this MODE shows of the key and +k/+i: learned (K|) at the end. */
  char seen_key[MAX_KEY];
  snprintf(seen_key, sizeof(seen_key), "%s", c->key);
  int seen_modes = (int)c->modes;
  /* Only a MODE that sets or clears k or i is something seen: anything else
   * would stamp this bot's own (possibly stale) copy of the key as learned. */
  bool touched = false;

  /* Live modes, key, limit, ban list and halfop/voice flags (chanlive.c) on
   * their own copy of the arguments: this function tokenises args in place. */
  if (!args || strlen(args) < 1024) {
    char live_args[1024];
    snprintf(live_args, sizeof(live_args), "%s", args ? args : "");
    chanlive_apply(state, c, modes, live_args, false);
  }

  bool adding = true; // Default direction
  /* modes.md §3.3: under +enforcemodes with a k in the stored modes the key
   * is the bots', so a key someone sets or clears is not learned. */
  const bool key_managed = chanenf_key_managed(state, c);
  char *saveptr;
  char no_args[1] = "";
  /* args is NULL when the MODE line carries no trailing parameters at all
   * (e.g. "+nt" - neither mode takes an argument). strtok_r() requires a
   * non-NULL string on its first call - passing NULL makes it read from an
   * uninitialized saveptr here, which is what crashed. Fall back to an
   * empty buffer so saveptr ends up validly initialized either way; every
   * later strtok_r(NULL, " ", &saveptr) continuation call below then just
   * keeps returning NULL, as intended when there are no more arguments. */
  char *current_arg = strtok_r(args ? args : no_args, " ", &saveptr);

  for (int i = 0; modes[i] != '\0'; i++) {
    char mode = modes[i];

    if (mode == '+') {
      adding = true;
      continue;
    }
    if (mode == '-') {
      adding = false;
      continue;
    }
    /* Which modes take an argument is the server's (005 PREFIX + CHANMODES,
     * defaults "ohv" / "beI,k,l"): a hardcoded list let a server's own
     * modes (+q, +j, +f...) shift every later argument, so "+qo a b" read
     * a as the opped nick (review 2026-10-25 #17). */
    bool has_arg = isupport_mode_has_arg(state, mode, adding);

    if (mode == 'o' && has_arg && current_arg) {
      // Check if it affects US
      if (strcasecmp(current_arg, state->current_nick) == 0) {
        c->i_am_opped = adding;
        for (int k = 0; k < c->roster_count; k++) {
          if (strcasecmp(c->roster[k].nick, state->current_nick) == 0) {
            c->roster[k].is_op = adding;
            break;
          }
        }
        if (adding) {
          c->enf_dirty = c->enf_ops_check = true; /* chanenf.c sweep */
          c->op_request_pending = false;
          c->op_request_retry_count = 0;
          log_message(L_INFO, state, "[INFO] I am now OP in %s\n", channel);
          hub_client_grant_held_ops(state, c);
        } else {
          /* Deopped: re-read the channel before choosing a helper.  While
           * we held ops the roster was never refreshed, so peers that left
           * or renamed may still be listed and peers that joined are not.
           * The 315 handler picks a trusted op from the fresh WHO and sends
           * the request, with the usual rate limit and retries.  Skipped
           * while a request is already pending; its timeout re-WHOs. */
          log_message(L_INFO, state,
                      "[INFO] I was DEOPPED in %s. Refreshing roster to "
                      "find a trusted op.\n",
                      channel);
          if (!c->op_request_pending) {
            c->roster_count = 0;
            irc_printf(state, "WHO %s\r\n", c->name);
            c->last_who_request = time(NULL);
          }
        }
      }
      // Check if it affects SOMEONE ELSE in our roster
      else {
        for (int k = 0; k < c->roster_count; k++) {
          if (strcasecmp(c->roster[k].nick, current_arg) == 0) {
            c->roster[k].is_op = adding;
            log_message(L_DEBUG, state,
                        "[DEBUG] Roster update: %s is_op=%d in %s\n",
                        current_arg, adding, channel);
            break;
          }
        }
      }
    } else if (mode == 'k') {
      if (key_managed) {
        /* the mode job puts the stored key back; learn nothing */
      } else if (adding && current_arg) {
        size_t klen = strlen(current_arg);
        if (klen >= MAX_KEY) klen = MAX_KEY - 1;
        memcpy(seen_key, current_arg, klen);
        seen_key[klen] = '\0';
        seen_modes |= M_K;
        touched = true;
      } else if (!adding) {
        /* -k clears the key regardless of arg */
        seen_key[0] = '\0';
        seen_modes &= ~M_K;
        touched = true;
      }
    } else if (mode == 'i') {
      touched = true;
      if (adding)
        seen_modes |= M_I;
      else
        seen_modes &= ~M_I;
    }
    if (has_arg && current_arg)
      current_arg = strtok_r(NULL, " ", &saveptr);
  }
  /* Learned, never existence: the c| stamp stays, so a delete this MODE
   * races is not undone (an unmanaged channel learns nothing). */
  bool learned = touched && c->is_managed && chan_learn(c, seen_key, seen_modes);
  secure_wipe(seen_key, sizeof(seen_key));
  return learned;
}

/* Record the bot's own hostmask.  Only two things may call this, and both hand
 * it a string the server itself presented to OTHER clients verbatim:
 *   - our own entry in a 352 (RPL_WHOREPLY) — the numeric peers parse into
 *     their rosters and store in trusted_bots[];
 *   - the prefix of our own JOIN echo — what the channel was shown.
 * Both were verified byte-identical against ngircd (2026-09-08).
 *
 * Nothing here parses a self-directed answer, resolves a name, or splices a
 * mask together.  The reason is that the server's choice of host form is per
 * session and outside our control: an ircd prints the resolved name only when
 * forward-confirmed rDNS succeeds within its timeout, and the raw IP otherwise
 * — the same box is legitimately `nick!~i@host.example.net` in one session and
 * `nick!~i@203.0.113.7` in the next.  So a remembered host re-spliced onto a
 * new nick, or an ident carried over from config, silently publishes a mask no
 * peer can match.  Events that can change the mask (001, 396 cloak, own NICK)
 * therefore only re-ask via request_own_hostmask().
 *
 * Idempotent: updates actual_hostname(+ts) and calls hub_client_sync_hostmask
 * only when the value actually changes, so repeated WHOs never re-push. */
static void update_own_hostmask(bot_state_t *state, const char *mask) {
  if (!mask || mask[0] == '\0')
    return;
  if (strcmp(state->actual_hostname, mask) == 0)
    return; // unchanged — nothing to push

  snprintf(state->actual_hostname, sizeof(state->actual_hostname), "%s", mask);
  state->actual_hostname_ts = time(NULL);
  log_message(L_INFO, state, "[INFO] My hostmask is now: %s\n",
              state->actual_hostname);

  if (state->hub_connected && state->hub_authenticated)
    hub_client_sync_hostmask(state);
}

/* Ask the server for our own DISPLAYED hostmask.  `WHO <nick>` is answered by
 * every IRC network with a 352 carrying exactly the nick!ident@host other
 * clients are shown — the same numeric peers build their rosters from — and it
 * works without joining a channel (the reply's channel field is "*").
 * USERHOST is not used: its answer is addressed to us alone, so nothing
 * guarantees it is the string the network puts in front of anyone else, and we
 * have no reason to publish a form no peer will ever match against.  Sent on
 * connect, on a cloak change, and after a settled nick change, so it adds no
 * sustained traffic. */
static void request_own_hostmask(bot_state_t *state) {
  if (state->current_nick[0] != '\0')
    irc_printf(state, "WHO %s\r\n", state->current_nick);
}

/* The trailing parameter ("... :text"), or all of params if there is none. */
static const char *irc_trailing(const char *params) {
  if (params[0] == ':') return params + 1;
  const char *t = strstr(params, " :");
  return t ? t + 2 : params;
}

void parser_handle_line(bot_state_t *state, char *line) {
  if (strncmp(line, "PING :", 6) == 0) {
    irc_printf(state, "PONG :%s\r\n", line + 6);
    state->last_pong_time = time(NULL);
    state->pong_pending = false;
    return;
  }

  char line_copy[MAX_BUFFER];
  snprintf(line_copy, sizeof(line_copy), "%s", line);

  char *prefix = NULL, *command = NULL, *params = NULL;
  char *p = line_copy;

  if (*p == ':') {
    prefix = p + 1;
    p = strchr(p, ' ');
    if (!p)
      return;
    *p++ = '\0';
  }

  command = p;
  p = strchr(p, ' ');
  if (p) {
    *p++ = '\0';
    params = p;
  } else {
    return;
  }

  char *saveptr_irc;

  if (strcmp(command, "PONG") == 0) {
    state->last_pong_time = time(NULL);
    state->pong_pending = false;
    return;
  }
  /* "PING token" (no colon) and ":server PING :token" (a prefix): the fast
   * path above only knows "PING :token", and an unanswered ping times out */
  if (strcmp(command, "PING") == 0) {
    irc_printf(state, "PONG :%s\r\n", irc_trailing(params));
    state->last_pong_time = time(NULL);
    state->pong_pending = false;
    return;
  }
  if (strcmp(command, "004") == 0) {
    char *server_name = strtok_r(params, " ", &saveptr_irc);
    server_name = strtok_r(NULL, " ", &saveptr_irc);
    if (server_name) {
      snprintf(state->actual_server_name, sizeof(state->actual_server_name),
               "%s", server_name);
    }
  }
  if (strcmp(command, "001") == 0) {
    state->status |= S_AUTHED;
    irc_note_registered(state); /* server accepted us: drop any ban hold */
    /* 001's first parameter is the nick the server actually registered us
     * under, which is not always the one we asked for (length truncation,
     * collision handling, a services rename).  Self-recognition in the 352
     * and 302 handlers is a strcasecmp against current_nick, so a stale value
     * here silently disables every self-mask capture and the bot goes on
     * publishing whatever the 001 welcome line happened to say. */
    {
      const char *sp = strchr(params, ' ');
      size_t nlen = sp ? (size_t)(sp - params) : strlen(params);
      if (nlen >= sizeof(state->current_nick)) {
        char long_nick[MAX_MEMBER_NICK];
        snprintf(long_nick, sizeof(long_nick), "%.*s", (int)nlen, params);
        irc_nick_overlong(state, long_nick);
      } else if (nlen > 0) {
        state->overlong_nick[0] = '\0';
        state->overlong_since = 0;
        char srv_nick[MAX_NICK];
        memcpy(srv_nick, params, nlen);
        srv_nick[nlen] = '\0';
        /* Registered under anything but the target nick is news for the
         * hub even when current_nick already says so: a 433 during
         * registration switches current_nick to the fallback without a push,
         * and a hub link that came up before that has only the target. */
        bool renamed = strcmp(state->current_nick, srv_nick) != 0;
        if (renamed || strcasecmp(srv_nick, state->target_nick) != 0) {
          if (renamed)
            log_message(L_INFO, state,
                        "[INFO] Server registered me as %s (was %s)\n",
                        srv_nick,
                        state->current_nick[0] ? state->current_nick : "unset");
          snprintf(state->current_nick, sizeof(state->current_nick), "%s",
                   srv_nick);
          state->current_nick_ts = time(NULL);
          if (state->hub_connected && state->hub_authenticated)
            hub_client_push_delta(state, "n", state->current_nick,
                                  state->current_nick_ts);
        }
      }
    }
    /* The mask embedded in the 001 welcome text is deliberately NOT used:
     * it is a self-directed greeting, and networks fill it with the real
     * (pre-resolution / pre-cloak) host that no other client is ever shown.
     * Ask instead, and take the answer only from the 352. */
    request_own_hostmask(state);
  } else if (strcmp(command, "433") == 0 || strcmp(command, "432") == 0 ||
             strcmp(command, "437") == 0) {
    /* A NICK was refused: 433 in use, 437 held (nick delay, jupe), 432
     * erroneous -- this server's rules are narrower than RFC 2812 (a shorter
     * NICKLEN, reserved names).  "<me> <nick> :<reason>"; a 437 can name a
     * channel instead, which is not ours to handle here. */
    strtok_r(params, " ", &saveptr_irc);
    char *refused = strtok_r(NULL, " ", &saveptr_irc);
    if (!refused || (*refused != '#' && *refused != '&')) {
      state->nick_change_pending = false;
      /* 432 is final for that nick on this server: stop re-sending it every
       * NICK_RETRY_TIME (the server keeps our current nick) until the target
       * changes or the bot reconnects. */
      if (refused && strcmp(command, "432") == 0 &&
          strcasecmp(refused, state->target_nick) == 0 &&
          strcasecmp(state->nick_refused, refused) != 0) {
        snprintf(state->nick_refused, sizeof(state->nick_refused), "%s",
                 state->target_nick);
        log_message(L_INFO, state,
                    "[INFO] Server refuses nick '%s' (432: %s); not retrying "
                    "it here. Pick another with chnick.\n",
                    state->target_nick, irc_trailing(saveptr_irc ? saveptr_irc
                                                                 : ""));
      }
      /* Not registered yet: without an accepted nick there is no 001.  Under
       * a nick over 9 bytes (10b), the target refused: take an alternate. */
      if (!(state->status & S_AUTHED) || state->overlong_nick[0])
        irc_generate_new_nick(state);
    }
  } else if (strcmp(command, "465") == 0 || strcmp(command, "463") == 0) {
    /* ERR_YOUREBANNEDCREEP / ERR_NOPERMFORHOST: this server is refusing us.
     * Only recorded here; irc_disconnect() classifies it and holds the server
     * when the link drops.  (474 below is a channel ban, not a server one.) */
    irc_note_refusal(state, irc_trailing(params), true);
  } else if (strcmp(command, "ERROR") == 0) {
    /* The server's last words before closing the link -- "Closing Link: ...
     * (K-Lined)", "(Throttled: ...)", "(Ping timeout)".  Classified at
     * disconnect alongside any 465/463. */
    irc_note_refusal(state, irc_trailing(params), false);
  } else if (strcmp(command, "474") == 0) {
    /* ERR_BANNEDFROMCHAN: ask the mesh to lift the ban that matches us.  The
     * hub supplies our hostmask, and the servicing bot removes only the ban
     * masks that actually match it. */
    strtok_r(params, " ", &saveptr_irc);
    char *chan_name = strtok_r(NULL, " ", &saveptr_irc);
    if (chan_name) {
      chan_t *c = channel_find(state, chan_name);
      if (c) {
        c->status = C_OUT;
        if (c->is_managed) {
          log_message(L_INFO, state,
                      "[474] Banned from %s, requesting unban\n", chan_name);
          chan_access_request(state, c, CHAN_REQ_UNBAN);
        }
      }
    }
  } else if (strcmp(command, "475") == 0) {
    /* ERR_BADCHANNELKEY: our stored key is stale.  Only a bot sitting in the
     * channel has the current one -- the hub's c| copy went stale with ours. */
    strtok_r(params, " ", &saveptr_irc);
    char *chan_name = strtok_r(NULL, " ", &saveptr_irc);
    if (chan_name) {
      chan_t *c = channel_find(state, chan_name);
      if (c) {
        c->status = C_OUT;
        if (c->is_managed) {
          log_message(L_INFO, state,
                      "[475] Bad key for %s, requesting current key\n",
                      chan_name);
          chan_access_request(state, c, CHAN_REQ_KEY);
        }
      }
    }
  } else if (strcmp(command, "005") == 0) {
    /* RPL_ISUPPORT: MODES, MAXLIST, PREFIX, CHANMODES for the send queue and
     * the mode parser.  Parsed on a copy; strtok_r works in place. */
    char isup[1024];
    if (strlen(params) < sizeof(isup)) {
      memcpy(isup, params, strlen(params) + 1);
      isupport_parse(state, isup);
    }
  } else if (strcmp(command, "324") == 0 || strcmp(command, "329") == 0) {
    /* RPL_CHANNELMODEIS / RPL_CREATIONTIME: live state only. */
    chanlive_numeric(state, command, params);
  } else if (strcmp(command, "367") == 0) {
    chanlive_numeric(state, command, params); /* our own ban list copy */
    /* RPL_BANLIST: "<me> <channel> <mask> [setter ts]" -- only of interest
     * while we are walking a list on another bot's behalf. */
    strtok_r(params, " ", &saveptr_irc);
    char *chan_name = strtok_r(NULL, " ", &saveptr_irc);
    char *ban_mask = strtok_r(NULL, " ", &saveptr_irc);
    if (chan_name && ban_mask)
      chan_unban_note_ban(state, chan_name, ban_mask);
  } else if (strcmp(command, "368") == 0) {
    chanlive_numeric(state, command, params);
    /* RPL_ENDOFBANLIST: closes the walk. */
    strtok_r(params, " ", &saveptr_irc);
    char *chan_name = strtok_r(NULL, " ", &saveptr_irc);
    if (chan_name)
      chan_unban_finish(state, chan_name);
  } else if (strcmp(command, "405") == 0) {
    /* ERR_TOOMANYCHANNELS: server channel limit reached; stop retrying this channel */
    strtok_r(params, " ", &saveptr_irc);
    char *chan_name = strtok_r(NULL, " ", &saveptr_irc);
    if (chan_name) {
      chan_t *c = channel_find(state, chan_name);
      if (c) {
        c->join_disabled = true;
        log_message(L_INFO, state,
                    "[405] Channel limit reached, disabling join retry: %s\n",
                    chan_name);
      }
    }
  } else if (strcmp(command, "473") == 0) {
    /* ERR_INVITEONLYCHAN: need invite to join managed channel */
    strtok_r(params, " ", &saveptr_irc);
    char *chan_name = strtok_r(NULL, " ", &saveptr_irc);
    if (chan_name) {
      chan_t *c = channel_find(state, chan_name);
      if (c && c->is_managed) {
        log_message(L_INFO, state,
                    "[473] Channel %s is invite-only, requesting invite\n",
                    chan_name);
        chan_access_request(state, c, CHAN_REQ_INVITE);
      }
    }
  }
  // [MODIFIED] Robust MODE Parsing + Immediate Op Recovery
  else if (strcmp(command, "MODE") == 0 && params) {
    char params_copy[MAX_BUFFER];
    snprintf(params_copy, sizeof(params_copy), "%s", params);

    char *target = strtok_r(params_copy, " ", &saveptr_irc);
    char *modes = strtok_r(NULL, " ", &saveptr_irc);
    char *args = strtok_r(NULL, "", &saveptr_irc);

    if (target && modes && (target[0] == '#' || target[0] == '&')) {
      /* channel_handle_mode_change tokenises args in place; the enforcement
       * pass gets its own copy.  An oversized one is skipped (fail closed). */
      char enf_args[1024];
      bool enf_ok = !args || strlen(args) < sizeof(enf_args);
      snprintf(enf_args, sizeof(enf_args), "%s", args ? args : "");
      bool learned = channel_handle_mode_change(state, target, modes, args);
      if (enf_ok)
        chanenf_on_mode(state, target, prefix, modes, enf_args);
      /* Push key/invite-only changes to hub (K|), and to our own config: with
       * no hub to echo them back, a key we learned and saved must not outlive
       * a -k. */
      if (learned) {
        chan_t *mc = channel_find(state, target);
        if (mc) {
          mc->enf_pending = true; /* cleared once a hub has it (D43) */
          hub_client_push_channel(state, mc);
          config_write_with_state_pass(state);
        }
      }
    }
  } else if (strcmp(command, "352") == 0) {
    strtok_r(params, " ", &saveptr_irc);
    char *chan_name = strtok_r(NULL, " ", &saveptr_irc);
    char *ident = strtok_r(NULL, " ", &saveptr_irc);
    char *host = strtok_r(NULL, " ", &saveptr_irc);
    strtok_r(NULL, " ", &saveptr_irc);
    char *nick = strtok_r(NULL, " ", &saveptr_irc);
    char *modes = strtok_r(NULL, " ", &saveptr_irc);

    if (!nick || !ident || !host || !modes)
      return;

    bool is_op = (strstr(modes, "@") != NULL);
    /* PREFIX (005) names the halfop / voice symbols this server uses. */
    bool is_halfop = false, is_voice = false;
    {
      const char *hp = strchr(state->isup.prefix_modes, 'h');
      const char *vp = strchr(state->isup.prefix_modes, 'v');
      if (hp)
        is_halfop = strchr(modes, state->isup.prefix_syms[hp - state->isup.prefix_modes]) != NULL;
      if (vp)
        is_voice = strchr(modes, state->isup.prefix_syms[vp - state->isup.prefix_modes]) != NULL;
    }

    /* Self-mask capture, ahead of the channel lookup on purpose: the reply to
     * `WHO <nick>` (request_own_hostmask) carries "*" as the channel, so
     * gating this on channel_find would discard the one authoritative,
     * channel-independent source of our displayed mask.  This is the same
     * nick!ident@host every peer stores in trusted_bots[]. */
    if (strcasecmp(nick, state->current_nick) == 0) {
      char self_mask[MAX_MASK_LEN];
      snprintf(self_mask, sizeof(self_mask), "%s!%s@%s", nick, ident, host);
      update_own_hostmask(state, self_mask);
    }

    chan_t *c = channel_find(state, chan_name);
    if (!c)
      return;

    /* Always update own op status even when the roster array is full.
     * Without this, the bot's own 352 entry can be silently dropped in
     * large channels (>MAX_ROSTER_SIZE users), leaving i_am_opped = false
     * and triggering spurious OP-REQs on the next 315. */
    if (strcasecmp(nick, state->current_nick) == 0)
      c->i_am_opped = is_op;

    {
      /* add, or replace the entry a JOIN already made (chanenf.c keeps the
       * roster current between WHOs) */
      char who[MAX_MASK_LEN];
      if (snprintf(who, sizeof(who), "%s!%s@%s", nick, ident, host) <
          (int)sizeof(who))
        chanenf_roster_set(c, nick, who, is_op, is_halfop, is_voice);
    }
  } else if (strcmp(command, "396") == 0) {
    char *hostname = strtok_r(params, " ", &saveptr_irc); // Nick
    hostname = strtok_r(NULL, " ", &saveptr_irc);         // Host

    if (hostname) {
      /* 396 gives only the host half, and a cloak can change the ident too.
       * Rather than splice a mask together — a guess about a string only the
       * server defines — treat it purely as a signal that our mask moved and
       * re-ask.  The 352 reply supplies the exact new value. */
      log_message(L_INFO, state, "[INFO] Displayed host changed to %s; "
                                 "re-checking my mask\n", hostname);
      request_own_hostmask(state);
    }
  } else if (strcmp(command, "315") == 0) {
    strtok_r(params, " ", &saveptr_irc);
    char *chan_name = strtok_r(NULL, " ", &saveptr_irc);
    if (!chan_name)
      return;

    chan_t *c = channel_find(state, chan_name);
    if (!c)
      return;

    log_message(L_INFO, state, "[INFO] Roster for %s updated with %d users.\n",
                c->name, c->roster_count);
    c->enf_dirty = c->enf_ops_check = true; /* chanenf.c sweep */
    c->who_done = true;                     /* the member list is complete */

    if (c->i_am_opped) {
      c->op_request_pending = false;
      c->op_request_retry_count = 0;
      return;
    }

    // Debug: only logged when we actually need op
    log_message(L_DEBUG, state, "[OP-REQ] trusted_bot_count=%d\n",
                state->trusted_bot_count);
    for (int i = 0; i < state->trusted_bot_count; i++) {
      log_message(L_DEBUG, state, "[OP-REQ] trusted_bots[%d]: %s|%s%s\n", i,
                  state->trusted_bots[i].mask, state->trusted_bots[i].uuid,
                  state->trusted_bots[i].has_pub ? "" : " (no key)");
    }

    time_t now = time(NULL);
    if (c->op_request_pending && (now - c->last_op_request_time < 60)) {
      return;
    }
    // Reset retry counter after 5 minutes of no attempts
    if (c->op_request_retry_count >= 5 &&
        (now - c->last_op_request_time > 300)) {
      log_message(L_INFO, state,
                  "[INFO] Resetting retry counter for %s after timeout.\n",
                  c->name);
      c->op_request_retry_count = 0;
    }
    if (c->op_request_retry_count >= 5) {
      log_message(L_INFO, state,
                  "[INFO] Gave up requesting ops in %s after %d attempts.\n",
                  c->name, c->op_request_retry_count);
      return;
    }

    // Standard Polling Logic (runs if roster refresh happened naturally)
    roster_entry_t *helpers[MAX_ROSTER_SIZE];
    int helper_count = 0;

    log_message(L_DEBUG, state, "[OP-REQ] Scanning %d roster entries for trusted ops\n",
                c->roster_count);
    for (int i = 0; i < c->roster_count; i++) {
      roster_entry_t *entry = &c->roster[i];
      bool is_trusted = auth_is_trusted_bot(state, entry->hostmask, NULL, 0);
      log_message(L_DEBUG, state, "[OP-REQ] Roster[%d]: nick=%s hostmask=%s is_op=%d is_trusted=%d\n",
                  i, entry->nick, entry->hostmask, entry->is_op, is_trusted);
      if (entry->is_op && is_trusted) {
        if (helper_count < MAX_ROSTER_SIZE) {
          helpers[helper_count++] = entry;
        }
      }
    }

    if (helper_count > 0) {
      int random_index = rand() % helper_count;
      roster_entry_t *chosen_helper = helpers[random_index];

      log_message(L_INFO, state,
                  "[INFO] Found %d trusted ops. Randomly selected: %s. "
                  "Sending OPME request (attempt %d).\n",
                  helper_count, chosen_helper->nick,
                  c->op_request_retry_count + 1);

      c->last_op_request_time = now;
      c->op_request_pending = true;

      if (now - state->last_op_request_sent >= OP_REQUEST_MIN_INTERVAL) {
        // Try hub first - look up UUID for this helper
        bool sent_via_hub = false;
        log_message(L_DEBUG, state,
                    "[OP-REQ] Looking up UUID for helper: nick=%s hostmask=%s\n",
                    chosen_helper->nick, chosen_helper->hostmask);
        {
          /* the trusted entry that matched this helper (auth.c: an exact
           * mask before a wildcard) names the bot to ask */
          char uuid[64];
          if (auth_is_trusted_bot(state, chosen_helper->hostmask, uuid, sizeof(uuid)) &&
              uuid[0]) {
            log_message(L_DEBUG, state, "[OP-REQ] Found UUID, trying hub request\n");
            sent_via_hub = hub_client_request_op(state, uuid, c->name);
            log_message(L_DEBUG, state,
                        "[OP-REQ] hub_client_request_op returned: %d\n", sent_via_hub);
          }
        }

        // Fallback to PRIVMSG if hub unavailable
        if (!sent_via_hub) {
          log_message(L_DEBUG, state,
                      "[OP-REQ] Hub unavailable or no UUID match, falling back to PRIVMSG\n");
          bot_comms_send_to_host(state, chosen_helper->hostmask,
                                 chosen_helper->nick, "OPME %s", c->name);
        }
        state->last_op_request_sent = now;
        c->op_request_retry_count++;
      } else {
        /* Another channel just asked.  Book the next free slot instead of
         * sitting out the 60 s pending timeout: back-date the request so
         * channel_manager's timeout re-WHOs this channel the moment its slot
         * opens.  Slots are MIN_INTERVAL + 1 apart so the WHO round trip
         * cannot land a request inside the previous one's window. */
        time_t slot = state->last_op_request_sent + OP_REQUEST_MIN_INTERVAL;
        if (state->op_request_next_slot > slot)
          slot = state->op_request_next_slot;
        state->op_request_next_slot = slot + OP_REQUEST_MIN_INTERVAL + 1;
        c->last_op_request_time = slot - 61;
        log_message(L_DEBUG, state,
                    "[OP-REQ] Rate limited in %s; retry in %llds (attempt %d pending)\n",
                    c->name, (long long)(slot - now),
                    c->op_request_retry_count + 1);
      }
    } else {
      log_message(L_DEBUG, state,
                  "[OP-REQ] No trusted ops in roster. "
                  "trusted_bot_count=%d, roster_count=%d\n",
                  state->trusted_bot_count, c->roster_count);
      // Don't burn retry_count — no helper present yet isn't a failed attempt.
      // Set pending with a 30-second back-date so channel_manager retries
      // via WHO in ~30 seconds (the 60-second timeout fires after 30 more).
      c->op_request_pending = true;
      c->last_op_request_time = now - 30;
    }
  } else if (strcmp(command, "PRIVMSG") == 0 && prefix) {
    char *nick = strtok_r(prefix, "!", &saveptr_irc);
    char *user = strtok_r(NULL, "@", &saveptr_irc);
    char *host = strtok_r(NULL, "", &saveptr_irc);
    char *dest = strtok_r(params, " ", &saveptr_irc);
    char *message = strtok_r(NULL, "", &saveptr_irc);
    if (message && *message == ':')
      message++;

    if (nick && dest && message && (dest[0] == '#' || dest[0] == '&')) {
      /* text to a channel: only the flood counters look at it */
      if (user && host)
        chanflood_on_text(state, dest, nick, user, host, message);
    } else if (nick && dest && message) {
      size_t msg_len = strlen(message);
      char src_nuh[MAX_MASK_LEN];
      src_nuh[0] = '\0';
      if (user && host &&
          snprintf(src_nuh, sizeof(src_nuh), "%s!%s@%s", nick, user, host) >=
              (int)sizeof(src_nuh))
        src_nuh[0] = '\0';
      if (msg_len >= 2 && message[0] == '\001' && message[msg_len - 1] == '\001') {
        log_message(L_CTCP, state, "[CTCP] (%s) %s\n", nick, message);
        /* ctcp flood (§9.1): an ignored host, or quiet mode, gets no answer */
        if (src_nuh[0] && botflood_ctcp(state, src_nuh) != BF_OK)
          return;

        message[msg_len - 1] = '\0';
        char *ctcp_command = message + 1;

        if (strncasecmp(ctcp_command, "DCC ", 4) == 0) {
          /* Only ever the reply to this bot's own passive offer (dcc.c). */
          if (user && host && strcasecmp(dest, state->current_nick) == 0)
            dcc_handle_ctcp(state, src_nuh, ctcp_command);
        } else if (strcasecmp(ctcp_command, "VERSION") == 0) {
          irc_printf(state, "NOTICE %s :\001VERSION %s\001\r\n", nick,
                     VERSION_RESPONSE);
        } else if (strncasecmp(ctcp_command, "PING ", 5) == 0) {
          irc_printf(state, "NOTICE %s :\001%s\001\r\n", nick, ctcp_command);
        }
      } else {
        commands_handle_private_message(state, nick, user, host, dest, message);
      }
    }
  } else if (strcmp(command, "NOTICE") == 0 && prefix && strchr(prefix, '!')) {
    /* NOTICEs were never read; now they only feed the flood counters. */
    char *nick = strtok_r(prefix, "!", &saveptr_irc);
    char *user = strtok_r(NULL, "@", &saveptr_irc);
    char *host = strtok_r(NULL, "", &saveptr_irc);
    char *dest = strtok_r(params, " ", &saveptr_irc);
    char *message = strtok_r(NULL, "", &saveptr_irc);
    if (message && *message == ':')
      message++;
    if (nick && user && host && dest && message) {
      if (dest[0] == '#' || dest[0] == '&') {
        chanflood_on_text(state, dest, nick, user, host, message);
      } else if (strcasecmp(dest, state->current_nick) == 0 &&
                 message[0] != '\001') {
        char src_nuh[MAX_MASK_LEN];
        /* services (NickServ, ChanServ, ...) answer every command with a
         * NOTICE: that is not a flood from a host (servers carry no '!') */
        size_t nl = strlen(nick);
        bool services = nl >= 4 && strcasecmp(nick + nl - 4, "Serv") == 0;
        if (!services &&
            snprintf(src_nuh, sizeof(src_nuh), "%s!%s@%s", nick, user, host) <
                (int)sizeof(src_nuh))
          botflood_msg(state, src_nuh);
      }
    }
  } else if (strcmp(command, "JOIN") == 0 && prefix) {
    /* Our own JOIN echo carries, as its prefix, the server presenting our mask
     * to the channel — the identical string every other client in that channel
     * receives, and byte-for-byte the same as our 352 entry (verified against
     * ngircd, 2026-09-08).  Copy it before strtok_r splits prefix in place.
     * This is the earliest exact value available: it lands before the channel
     * WHO we are about to send comes back. */
    char join_mask[MAX_MASK_LEN];
    size_t prefix_len = strlen(prefix);
    /* Explicit length test, not a bounded copy: a prefix that does not fit a
     * mask buffer is not a mask we may store — publishing a truncated one is
     * worse than publishing none, and the 352 is still coming. */
    bool join_mask_ok = (prefix_len > 0 && prefix_len < sizeof(join_mask));
    if (join_mask_ok) {
      memcpy(join_mask, prefix, prefix_len);
      join_mask[prefix_len] = '\0';
    }

    char *nick = strtok_r(prefix, "!", &saveptr_irc);
    if (join_mask_ok && nick && strcasecmp(nick, state->current_nick) == 0 &&
        strchr(join_mask, '!') && strchr(join_mask, '@'))
      update_own_hostmask(state, join_mask);

    /* Our own JOIN: current_nick is what the server knows us as (001, NICK).
     * Whoever holds target_nick while we run on a fallback is someone else. */
    if (nick && strcasecmp(nick, state->current_nick) == 0) {
      /* the channel is the first word (extended-join adds account and
       * realname after it) */
      char *chan_name = (*params == ':') ? params + 1 : params;
      chan_name[strcspn(chan_name, " ")] = '\0';
      chan_t *c = channel_find(state, chan_name);
      if (c && !c->is_managed) {
        /* Removed while this JOIN was on its way (a hub batch can carry the
         * add and its remove together, before the server answers): the
         * newest command wins, so leave again. */
        log_message(L_INFO, state, "[INFO] %s was removed while joining; "
                                   "parting\n", c->name);
        irc_printf(state, "PART %s :Channel removed\r\n", c->name);
        c->status = C_OUT;
      } else if (c) {
        c->status = C_IN;
        c->roster_count = 0;
        c->i_am_opped = false;
        channel_live_reset(c);
        snprintf(state->who_request_channel, sizeof(state->who_request_channel),
                 "%s", c->name);
        c->last_who_request = time(NULL);
        irc_printf(state, "WHO %s\r\n", c->name);
        chanlive_request(state, c); /* 324 modes and the 367 ban list */
      }
    } else if (nick && join_mask_ok) {
      /* someone else joined: keep the roster (and the enforcement) current */
      char jchan[MAX_CHAN];
      const char *jc = (*params == ':') ? params + 1 : params;
      size_t jl = strcspn(jc, " ");
      if (jl > 0 && jl < sizeof(jchan)) {
        memcpy(jchan, jc, jl);
        jchan[jl] = '\0';
        chanenf_on_join(state, jchan, join_mask);
      }
    }
  } else if (strcmp(command, "PART") == 0 && prefix) {
    char *nick = strtok_r(prefix, "!", &saveptr_irc);
    if (nick && strcasecmp(nick, state->current_nick) != 0) {
      char pchan[MAX_CHAN];
      const char *pc = (*params == ':') ? params + 1 : params;
      size_t pl = strcspn(pc, " ");
      if (pl > 0 && pl < sizeof(pchan)) {
        memcpy(pchan, pc, pl);
        pchan[pl] = '\0';
        chanenf_on_part(state, pchan, nick);
      }
    }
    /* our own PART only (see JOIN) */
    if (nick && strcasecmp(nick, state->current_nick) == 0) {
      // Extract channel name (may have : prefix or trailing reason)
      char *chan_name = (*params == ':') ? params + 1 : params;
      char *space = strchr(chan_name, ' ');
      if (space) *space = '\0';  // Remove part reason if present
      chan_t *c = channel_find(state, chan_name);
      if (c) {
        c->status = C_OUT;
        c->roster_count = 0;
        c->i_am_opped = false;
        channel_live_reset(c);
        log_message(L_DEBUG, state, "[IRC] Parted channel %s\n", chan_name);
      }
    }
  } else if (strcmp(command, "KICK") == 0 && params) {
    char params_copy[MAX_BUFFER];
    snprintf(params_copy, sizeof(params_copy), "%s", params);

    char *chan_name = strtok_r(params_copy, " ", &saveptr_irc);
    char *kicked_nick = strtok_r(NULL, " ", &saveptr_irc);
    if (chan_name && kicked_nick)
      chanenf_on_kick(state, chan_name, prefix, kicked_nick);
    if (chan_name && kicked_nick &&
        strcasecmp(kicked_nick, state->current_nick) == 0) {
      chan_t *c = channel_find(state, chan_name);
      if (c) {
        c->status = C_OUT;
        c->i_am_opped = false;
        channel_live_reset(c);
      }
    }
  } else if (strcmp(command, "QUIT") == 0 && prefix) {
    char *qnick = strtok_r(prefix, "!", &saveptr_irc);
    if (qnick)
      chanenf_on_quit(state, qnick);
  } else if (strcmp(command, "NICK") == 0 && prefix) {
    char *old_nick = strtok_r(prefix, "!", &saveptr_irc);
    char *new_nick = (*params == ':') ? params + 1 : params;
    if (old_nick && new_nick)
      chanenf_on_nick(state, old_nick, new_nick);
    bool me = old_nick && new_nick &&
              (strcasecmp(old_nick, state->current_nick) == 0 ||
               (state->overlong_nick[0] && strcasecmp(old_nick, state->overlong_nick) == 0));
    if (me && strlen(new_nick) >= sizeof(state->current_nick)) {
      irc_nick_overlong(state, new_nick); /* 10b: never clipped */
    } else if (me) {
      state->overlong_nick[0] = '\0';
      state->overlong_since = 0;
      snprintf(state->current_nick, sizeof(state->current_nick), "%s", new_nick);
      state->current_nick_ts = time(NULL);

      /* Push nick change as a targeted delta immediately. */
      if (state->hub_connected && state->hub_authenticated) {
        hub_client_push_delta(state, "n", state->current_nick,
                              state->current_nick_ts);
      }

      /* Our mask just changed in its nick half, and some networks reassign
       * host/cloak on a nick change too.  No local re-splice: ask, and let the
       * 352 supply the exact string.  Until it arrives actual_hostname briefly
       * holds the previous nick — a stale-but-real mask the server did once
       * present, which is strictly safer to publish than a guessed one.  One
       * WHO per nick change is not sustained traffic. */
      request_own_hostmask(state);

      state->nick_change_pending = false;
      if (strcasecmp(state->current_nick, state->target_nick) == 0) {
        state->nick_generation_attempt = 0;
      }
    }
  }
}
