#define _POSIX_C_SOURCE 200809L
#include "bot.h"
#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <netdb.h>
#include <openssl/err.h>
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

static hub_auth_state_t auth_state = HUB_AUTH_NONE;

/* Review 15b: the hub link is read without blocking into g_hub_rx, and
 * every whole frame in it is handled.  The blocking reads waited for a whole
 * frame, so a hub (or anything on the path) that stopped mid-frame froze the
 * bot until the 120 s watchdog -- IRC pings unanswered.  A frame left half
 * there now just waits; the watchdog still drops a link that never finishes
 * one.  g_hub_rx_gen moves on every reset, so a frame whose handling drops
 * or redials the link ends the pass over the old buffer. */
static unsigned char *g_hub_rx;
static size_t g_hub_rx_len;
static unsigned g_hub_rx_gen;
#define HUB_RX_CAP ((size_t)4 + MAX_HUB_FRAME)

static void hub_rx_reset(void) {
  if (g_hub_rx) secure_wipe(g_hub_rx, g_hub_rx_len);
  g_hub_rx_len = 0;
  g_hub_rx_gen++;
}

static time_t last_pong_sent = 0;

void hub_client_init(bot_state_t *state) {
  state->hub_fd = -1;
  state->hub_connected = false;
  state->hub_connecting = false;
  state->hub_authenticated = false;
  state->last_hub_connect_attempt = 0;
  state->last_hub_ping_time = 0;
  state->last_hub_activity = 0;
  state->hub_connect_time = 0;
  memset(state->hub_session_key, 0, 32);
  auth_state = HUB_AUTH_NONE;
  last_pong_sent = 0;
}

/* Review 16: the hub dial in flight.  hub_client_connect resolves the hub
 * and starts a non-blocking connect to each address in turn; its socket is
 * state->hub_fd, not yet hub_connected, and the main loop watches it for
 * writability (hub_client_dial_ready).  An address that does not answer in
 * HUB_DIAL_TIMEOUT is given up for the next, as the blocking dial did. */
#define HUB_DIAL_TIMEOUT 10
static struct addrinfo *g_dial_res, *g_dial_ai;
static time_t g_dial_started;
static int g_dial_flags;
static char g_dial_hub[256];

static void hub_dial_free(void) {
  if (g_dial_res) freeaddrinfo(g_dial_res);
  g_dial_res = g_dial_ai = NULL;
}

static void hub_dial_up(bot_state_t *state, int sockfd);

/* Start a connect to g_dial_ai or the next address that takes one. */
static void hub_dial_next(bot_state_t *state) {
  for (; g_dial_ai; g_dial_ai = g_dial_ai->ai_next) {
    int sockfd = socket(g_dial_ai->ai_family, g_dial_ai->ai_socktype, g_dial_ai->ai_protocol);
    if (sockfd < 0) continue;
    g_dial_flags = fcntl(sockfd, F_GETFL, 0);
    if (g_dial_flags < 0 || fcntl(sockfd, F_SETFL, g_dial_flags | O_NONBLOCK) < 0) {
      close(sockfd);
      continue;
    }
    if (connect(sockfd, g_dial_ai->ai_addr, g_dial_ai->ai_addrlen) == 0) {
      hub_dial_up(state, sockfd);
      return;
    }
    if (errno == EINPROGRESS) {
      state->hub_fd = sockfd;
      g_dial_started = time(NULL);
      return;
    }
    close(sockfd);
  }
  log_message(L_INFO, state, "[HUB] Failed to connect to %s\n", g_dial_hub);
  hub_dial_free();
  state->hub_connecting = false;
}

/* The address in flight failed or timed out: on to the next. */
static void hub_dial_failed(bot_state_t *state) {
  close(state->hub_fd);
  state->hub_fd = -1;
  if (g_dial_ai) g_dial_ai = g_dial_ai->ai_next;
  hub_dial_next(state);
}

/* The main loop saw the dial's socket writable: the connect is done. */
void hub_client_dial_ready(bot_state_t *state) {
  if (state->hub_fd == -1 || state->hub_connected || !g_dial_ai) return;
  int err = 0;
  socklen_t el = sizeof(err);
  if (getsockopt(state->hub_fd, SOL_SOCKET, SO_ERROR, &err, &el) != 0) err = errno;
  if (err == 0)
    hub_dial_up(state, state->hub_fd);
  else
    hub_dial_failed(state);
}

/* Copy the raw key halves from the pre-decoded, mlock'd hub_key_raw buffer.
 * Avoids repeated base64 decoding and keeps the key out of new heap regions.
 * This is the bot's single identity key: hub handshake, ~A2/~A2K admin
 * transport and ~B2 bot-to-bot all use it.  Callers wipe the outputs. */
bool bot_key_decode(bot_state_t *state, unsigned char ed_priv[32],
                    unsigned char x_priv[32]) {
  /* Zero check: if hub_key_raw was never populated, fall back to base64 decode
   * (handles the first handshake before a config reload sets hub_key_raw). */
  bool raw_set = false;
  for (int i = 0; i < HUB_KEY_RAW_LEN; i++) {
    if (state->hub_key_raw[i]) { raw_set = true; break; }
  }
  if (raw_set) {
    memcpy(ed_priv, state->hub_key_raw,      32);
    memcpy(x_priv,  state->hub_key_raw + 32, 32);
    return true;
  }
  /* Fallback: first-run wizard path where config hasn't been saved yet. */
  int dec_len = 0;
  unsigned char *dec = base64_decode(state->hub_key, &dec_len);
  if (!dec || dec_len != HUB_KEY_RAW_LEN) {
    log_message(L_INFO, state, "[HUB] hub_key is not a valid 64-byte Curve25519 key\n");
    /* the decoded length (base64_decode allocates strlen(input)) */
    if (dec) { if (dec_len > 0) secure_wipe(dec, (size_t)dec_len); free(dec); }
    return false;
  }
  memcpy(ed_priv, dec,      32);
  memcpy(x_priv,  dec + 32, 32);
  /* Cache into hub_key_raw for subsequent calls. */
  memcpy(state->hub_key_raw, dec, HUB_KEY_RAW_LEN);
  secure_wipe(dec, HUB_KEY_RAW_LEN);
  free(dec);
  return true;
}

bool bot_self_pub_refresh(bot_state_t *state) {
  unsigned char priv[HUB_KEY_RAW_LEN];
  state->self_pub_set = false;
  memset(state->self_pub, 0, sizeof(state->self_pub));
  if (state->hub_key[0] == '\0') {
    bool raw_set = false;
    for (int i = 0; i < HUB_KEY_RAW_LEN; i++)
      if (state->hub_key_raw[i]) { raw_set = true; break; }
    if (!raw_set) return false;
  }
  if (!bot_key_decode(state, priv, priv + 32)) return false;
  state->self_pub_set = crypto_combined_pub_from_priv(priv, state->self_pub);
  secure_wipe(priv, sizeof(priv));
  return state->self_pub_set;
}

/* Encrypt one [cmd][len][payload] frame under the hub session key and send
 * it, authenticated or not (CMD_BOT_RETIRE_ACK answers mid-handshake).
 * Returns false (after disconnecting on a send error) if it could not. */
/* Review 6: the AAD of frame number `ctr` sent with direction byte `dir`. */
static void link_aad(char dir, uint64_t ctr, unsigned char out[HUB_LINK_AAD_LEN]) {
  memcpy(out, "LNK1", 4);
  out[4] = (unsigned char)dir;
  for (int i = 0; i < 8; i++) out[5 + i] = (unsigned char)(ctr >> (56 - 8 * i));
}

/* Every frame to the hub after the handshake is sealed here, in the order it
 * goes out: a sequenced link counts them (review 6). */
static bool hub_seal_frame(bot_state_t *state, int cmd, const char *payload,
                           int pay_len) {
  if (state->hub_fd == -1) return false;
  if (pay_len < 0 || pay_len > MAX_BUFFER - 64) return false;
  unsigned char plain[MAX_BUFFER];
  plain[0] = (unsigned char)cmd;
  uint32_t inner_len = htonl((uint32_t)pay_len);
  memcpy(&plain[1], &inner_len, 4);
  if (pay_len) memcpy(&plain[5], payload, (size_t)pay_len);

  unsigned char cipher[MAX_BUFFER], tag[GCM_TAG_LEN];
  unsigned char aad[HUB_LINK_AAD_LEN];
  bool seq = state->hub_link_tx_seq;
  if (seq) link_aad('B', state->hub_link_tx_ctr, aad);
  int cipher_len = crypto_aes_gcm_encrypt_aad(
      plain, 5 + pay_len, seq ? aad : NULL, seq ? HUB_LINK_AAD_LEN : 0,
      state->hub_session_key, cipher + 4, tag);
  secure_wipe(plain, (size_t)(5 + pay_len));
  if (cipher_len <= 0) return false;
  if (seq)
    state->hub_link_tx_ctr++;
  else if (cmd == CMD_LINK_SEQ && pay_len == 2 && memcmp(payload, "go", 2) == 0)
    state->hub_link_tx_seq = true; /* every frame after our go */
  memcpy(cipher + 4 + cipher_len, tag, GCM_TAG_LEN);
  uint32_t net_len = htonl((uint32_t)(cipher_len + GCM_TAG_LEN));
  memcpy(cipher, &net_len, 4);
  int total = 4 + cipher_len + GCM_TAG_LEN;
  if (send(state->hub_fd, cipher, (size_t)total, 0) != total) {
    hub_client_disconnect(state);
    return false;
  }
  return true;
}

static bool hub_send_frame(bot_state_t *state, int cmd, const char *payload,
                           int pay_len) {
  if (!state->hub_authenticated) return false;
  return hub_seal_frame(state, cmd, payload, pay_len);
}

/* Overwrite a file with zeros, flush it and unlink it.  True when it is gone
 * (or never existed).  O_NOFOLLOW: a symlink planted in the bot's directory
 * never gets another file zeroed. */
static bool retire_wipe_file(const char *path) {
  int fd = open(path, O_WRONLY | O_NOFOLLOW | O_CLOEXEC);
  if (fd < 0) return errno == ENOENT || unlink(path) == 0 || errno == ENOENT;
  struct stat st;
  bool ok = fstat(fd, &st) == 0 && S_ISREG(st.st_mode);
  if (ok) {
    static const unsigned char zero[4096];
    off_t left = st.st_size;
    while (ok && left > 0) {
      size_t n = left > (off_t)sizeof(zero) ? sizeof(zero) : (size_t)left;
      ssize_t w = write(fd, zero, n);
      if (w <= 0) ok = false;
      else left -= w;
    }
    if (ok && fsync(fd) != 0) ok = false;
  }
  close(fd);
  if (unlink(path) != 0 && errno != ENOENT) ok = false;
  return ok;
}

/* CMD_BOT_RETIRE: this bot was deleted on the hub (bot del).  Wipe every
 * config file (keys, hubs, channels), tell the hub, leave IRC and exit.  A
 * cron restart then finds no config and stops at once. */
static void hub_client_retire(bot_state_t *state) {
  log_message(L_INFO, state, "[HUB] This bot was deleted on the hub: wiping its config "
                             "and exiting\n");
  state->retired = true;
  int cron = updater_cron_drop(state->executable_path);
  if (cron == 10)
    log_message(L_INFO, state, "[HUB] A hand-written crontab line still runs this binary\n");
  else if (cron != 0)
    log_message(L_INFO, state, "[HUB] Could not remove this bot's crontab lines\n");
  bool ok = retire_wipe_file(CONFIG_FILE);
  ok = retire_wipe_file(CONFIG_FILE ".tmp") && ok;
  ok = retire_wipe_file(CONFIG_FILE UPGRADE_PREV_SUFFIX) && ok;
  ok = retire_wipe_file(PASS_FILE) && ok;
  if (!ok)
    log_message(L_INFO, state, "[HUB] Could not wipe every config file; exiting anyway\n");
  hub_seal_frame(state, CMD_BOT_RETIRE_ACK, ok ? "1" : "0", 1);
  if (state->server_fd != -1) irc_printf(state, "QUIT :Removed from the botnet\r\n");
  state->status |= S_DIE;
  hub_client_disconnect(state);
}

/* Sign a domain-separated challenge with the Ed25519 private key.
 * msg = "irchub-bot-challenge-v1|UUID|" + hub_eph_pub(32) + challenge(32)
 * sig_out is 64 bytes. */
static bool ed25519_sign_challenge(bot_state_t *state,
                                   const unsigned char *challenge,
                                   const unsigned char *hub_eph_pub,
                                   unsigned char sig_out[64]) {
  unsigned char ed_priv[32], x_priv[32];
  if (!bot_key_decode(state, ed_priv, x_priv)) return false;
  secure_wipe(x_priv, 32);

  EVP_PKEY *pk = EVP_PKEY_new_raw_private_key(EVP_PKEY_ED25519, NULL, ed_priv, 32);
  secure_wipe(ed_priv, 32);
  if (!pk) {
    log_message(L_INFO, state, "[HUB] Failed to load Ed25519 private key\n");
    return false;
  }

  /* Build: "irchub-bot-challenge-v1|UUID|" + hub_eph_pub(32) + challenge(32) */
  size_t uuid_len = strlen(state->bot_uuid);
  size_t prefix_len = 24 + uuid_len + 1;  /* "irchub-bot-challenge-v1|" + uuid + "|" */
  size_t msg_len = prefix_len + 32 + 32;
  unsigned char *msg = malloc(msg_len);
  if (!msg) {
    EVP_PKEY_free(pk);
    log_message(L_INFO, state, "[HUB] OOM building challenge transcript\n");
    return false;
  }
  size_t off = 0;
  memcpy(msg + off, "irchub-bot-challenge-v1|", 24); off += 24;
  memcpy(msg + off, state->bot_uuid, uuid_len);       off += uuid_len;
  msg[off++] = '|';
  memcpy(msg + off, hub_eph_pub, 32);                 off += 32;
  memcpy(msg + off, challenge, 32);                   off += 32;

  EVP_MD_CTX *md = EVP_MD_CTX_new();
  bool ok = false;
  size_t siglen = 64;
  if (md && EVP_DigestSignInit(md, NULL, NULL, NULL, pk) == 1
         && EVP_DigestSign(md, sig_out, &siglen, msg, msg_len) == 1
         && siglen == 64)
    ok = true;
  if (md) EVP_MD_CTX_free(md);
  EVP_PKEY_free(pk);
  secure_wipe(msg, msg_len);
  free(msg);
  if (!ok) log_message(L_INFO, state, "[HUB] Ed25519 signing failed\n");
  return ok;
}

// Derive session key: X25519(bot_x_priv, hub_eph_pub) → HKDF → session_key
static bool x25519_derive_session_key(bot_state_t *state,
                                      const unsigned char hub_eph_pub[32],
                                      const unsigned char challenge[32],
                                      unsigned char session_key_out[32]) {
  unsigned char ed_priv[32], x_priv[32];
  if (!bot_key_decode(state, ed_priv, x_priv)) return false;
  secure_wipe(ed_priv, 32);

  // X25519 ECDH (rejects a low-order hub_eph_pub)
  unsigned char shared[32];
  bool ok = crypto_x25519_derive(x_priv, hub_eph_pub, shared);
  secure_wipe(x_priv, 32);
  if (!ok) {
    log_message(L_INFO, state, "[HUB] X25519 derive failed\n");
    return false;
  }

  // HKDF-SHA256: ikm=shared, salt=challenge, info="irchub-bot-session-v1|UUID"
  unsigned char info[96];
  int info_len = snprintf((char *)info, sizeof(info),
                          "irchub-bot-session-v1|%s", state->bot_uuid);
  int rc = crypto_hkdf_sha256(shared, 32, challenge, 32,
                               info, (size_t)info_len,
                               session_key_out, 32);
  secure_wipe(shared, 32);
  if (rc != 0) {
    log_message(L_INFO, state, "[HUB] HKDF failed\n");
    return false;
  }
  return true;
}

void hub_client_disconnect(bot_state_t *state) {
  if (state->hub_fd != -1) {
    shutdown(state->hub_fd, SHUT_RDWR);
    close(state->hub_fd);
    state->hub_fd = -1;
  }
  state->hub_connected = false;
  state->hub_authenticated = false;
  state->hub_connecting = false;
  state->hub_connect_time = 0;
  auth_state = HUB_AUTH_NONE;
  hub_rx_reset();
  hub_dial_free();
  secure_wipe(state->hub_session_key, 32);
  state->hub_link_offered = state->hub_link_tx_seq = state->hub_link_rx_seq = false;
  state->hub_link_tx_ctr = state->hub_link_rx_ctr = 0;
  state->current_hub[0] = '\0'; // Clear current hub tracking
  state->last_hub_connect_attempt = time(NULL);
  last_pong_sent = 0;
  /* The tree came from the hub we just lost; keep the rows so 'bots' can
   * still answer, but clear the presence we believe the hub holds so the next
   * authentication re-reports unconditionally. */
  state->presence_server[0] = '\0';
  state->last_presence_sent = 0;
}

/* Bytes from the hub not read yet.  The handshake timeout leaves such a link
 * alone: a blocking IRC connect can hold the loop past HUB_AUTH_TIMEOUT while
 * the hub's challenge sits in the socket. */
bool hub_client_data_waiting(bot_state_t *state) {
  if (state->hub_fd == -1) return false;
  /* A whole frame read but not handled yet; part of one only waits for the
   * rest, and a hub that never sends it is what the timeout is for. */
  if (g_hub_rx_len >= 4) {
    uint32_t nl;
    memcpy(&nl, g_hub_rx, 4);
    if (g_hub_rx_len - 4 >= ntohl(nl)) return true;
  }
  char b;
  return recv(state->hub_fd, &b, 1, MSG_PEEK | MSG_DONTWAIT) > 0;
}

void hub_client_heartbeat(bot_state_t *state) {
  if (state->hub_count == 0 || !state->hub_connected ||
      !state->hub_authenticated || state->hub_fd == -1)
    return;
  time_t now = time(NULL);
  /* Presence is cheap and self-throttling, so it rides the same tick as the
   * keepalive rather than needing a timer of its own. */
  hub_client_send_presence(state, false);
  if (now - state->last_hub_ping_time < 30)
    return;
  state->last_hub_ping_time = now;
  hub_seal_frame(state, CMD_PING, NULL, 0);
}

void hub_client_sync_hostmask(bot_state_t *state) {
  if (state->actual_hostname[0] == '\0') return;
  if (state->hub_count == 0 || state->hub_fd == -1 ||
      !state->hub_authenticated) return;
  log_message(L_DEBUG, state, "[DEBUG] Syncing hostmask via delta: %s\n",
              state->actual_hostname);
  hub_client_push_delta(state, "h", state->actual_hostname,
                        state->actual_hostname_ts);
}

/* Phase 4 (presence v2 J): the bot's link-order counter.  Read from
 * LINK_ORD_FILE, and bumped+persisted once per hub link (hub_client_link_ord_bump),
 * so a bot that moves hubs carries a strictly larger value to its new hub than
 * the stale one its old hub still gossips.  Persisted so a restart (also a new
 * link) keeps climbing and never loses to a sighting that predates it. */
static uint64_t hub_client_link_ord_read(bot_state_t *state) {
  FILE *f = fopen(LINK_ORD_FILE, "r");
  if (!f) return 0;
  char buf[32] = "";
  bool got = fgets(buf, sizeof(buf), f) != NULL;
  fclose(f);
  buf[strcspn(buf, "\r\n")] = '\0';
  char *end = NULL;
  errno = 0;
  unsigned long long v = strtoull(buf, &end, 10);
  if (!got || errno || !end || *end || end == buf) {
    /* Restarting from 1 loses moved-bot ordering until it climbs past the
     * old value; the hubs' clocks decide meanwhile. */
    log_message(L_INFO, state, "[HUB] %s unreadable: link-order counter restarts\n",
                LINK_ORD_FILE);
    return 0;
  }
  return (uint64_t)v;
}

static void hub_client_link_ord_bump(bot_state_t *state) {
  /* Above both the file and this process's own value, so a counter that could
   * not be saved still rises for this process. */
  uint64_t v = hub_client_link_ord_read(state);
  if (state->link_ord > v) v = state->link_ord;
  v++;
  char tmp[64], buf[32];
  snprintf(tmp, sizeof(tmp), "%s.tmp", LINK_ORD_FILE);
  int n = snprintf(buf, sizeof(buf), "%llu\n", (unsigned long long)v);
  int fd = open(tmp, O_WRONLY | O_CREAT | O_TRUNC, 0600);
  bool ok = fd >= 0;
  if (ok) {
    ok = write(fd, buf, (size_t)n) == (ssize_t)n && fsync(fd) == 0;
    ok = close(fd) == 0 && ok;
  }
  if (ok) ok = rename(tmp, LINK_ORD_FILE) == 0;
  if (!ok) {
    /* The worst case is a restart that reuses a value, which the clock
     * fallback then settles. */
    log_message(L_INFO, state, "[HUB] cannot write %s: %s\n", LINK_ORD_FILE,
                strerror(errno));
    unlink(tmp);
  }
  state->link_ord = v;
}

/* Tell the hub what we are running: version, the IRC server we are actually
 * on, and when this process started.  Volatile on both sides -- it feeds the
 * 'bots' tree and nothing else, and is never written to either config.
 *
 * Sent when it changes (a jump to another server, a reconnect) and refreshed
 * on a slow timer so a hub that restarted relearns us without waiting for the
 * bot to do anything.  force re-sends even when nothing changed. */
void hub_client_send_presence(bot_state_t *state, bool force) {
  if (state->hub_count == 0 || state->hub_fd == -1 ||
      !state->hub_authenticated) return;

  /* Prefer the server name the link actually reported over the configured
   * entry: after a redirect they differ, and the tree should show the truth. */
  char server[TREE_SERVER_MAX + 1] = "";
  if (state->status & S_CONNECTED) {
    const char *cfg = (state->current_server_index >= 0 &&
                       state->current_server_index < state->server_count)
                          ? state->server_list[state->current_server_index]
                          : NULL;
    /* Explicit precision: a server name longer than the presence field is
     * truncated on purpose, not an oversight. */
    if (state->actual_server_name[0])
      snprintf(server, sizeof(server), "%.*s", (int)sizeof(server) - 1,
               state->actual_server_name);
    else if (cfg)
      snprintf(server, sizeof(server), "%.*s", (int)sizeof(server) - 1, cfg);
  }

  time_t now = time(NULL);
  bool changed = strcmp(server, state->presence_server) != 0;
  if (!force && !changed && state->last_presence_sent &&
      now - state->last_presence_sent < BOT_PRESENCE_REPORT_INTERVAL)
    return;

  /* The variant rides last: a hub that predates it reads the start time
   * with atoll(), which stops at the '|', so older hubs are unaffected. */
  char payload[TREE_VERSION_MAX + TREE_SERVER_MAX + TREE_VARIANT_MAX + 128];
  int pay_len = snprintf(payload, sizeof(payload), "%s|%s|%lld|%s|%s|%llu",
                         BOT_VERSION, server, (long long)state->bot_start_time,
                         BOT_UPDATE_VARIANT, updater_cron_status(),
                         (unsigned long long)state->link_ord);
  if (pay_len <= 0 || pay_len >= (int)sizeof(payload)) return;

  if (hub_send_frame(state, CMD_BOT_PRESENCE, payload, pay_len)) {
    snprintf(state->presence_server, sizeof(state->presence_server), "%s",
             server);
    state->last_presence_sent = now;
    if (changed)
      log_message(L_DEBUG, state, "[HUB] Presence: %s on %s\n", BOT_VERSION,
                  server[0] ? server : "(no server)");
  }
}

/* ---- Network upgrade (hub-orchestrated rolling upgrade) ------------------
 * The bot is a follower here.  It answers CMD_UPGRADE_PREPARE with what it is
 * and whether it could take the target build, touches nothing until
 * CMD_UPGRADE_COMMIT names the same upgrade, and restores the retained build
 * on CMD_UPGRADE_ABORT.  None of this is reachable from IRC or DCC: the
 * frames only arrive on the authenticated hub link, which is the whole point
 * of the standalone-only gate on the 'update' command. */

/* Copy src into a '|'-free, control-byte-free field.  Reasons carry text that
 * originated in a manifest, and the wire format splits on '|'. */
static void upgrade_field(char *dst, size_t dst_size, const char *src) {
  if (!dst || dst_size == 0) return;
  size_t o = 0;
  for (const char *p = src ? src : ""; *p && o + 1 < dst_size; p++) {
    unsigned char c = (unsigned char)*p;
    if (c == '|') c = '/';
    if (c < 0x20 || c == 0x7f) c = ' ';
    dst[o++] = (char)c;
  }
  dst[o] = '\0';
}

/* id|uuid|cur_ver|variant|arch|libc|ready|reason */
/* id|uuid|phase|code|note */
static void hub_client_send_upgrade_progress(bot_state_t *state, const char *id,
                                             const char *status) {
  char payload[MAX_BUFFER / 8];
  int n = snprintf(payload, sizeof(payload), "%s|%s|%s", id, state->bot_uuid, status);
  if (n > 0 && n < (int)sizeof(payload)) hub_send_frame(state, CMD_UPGRADE_PROGRESS, payload, n);
}

void hub_client_stage_tick(bot_state_t *state) {
  char id[64], status[256];
  if (!updater_stage_tick(id, sizeof(id), status, sizeof(status))) return;
  /* No link: keep it owed, so the hub hears it once the link is back. */
  if (!state->hub_authenticated) {
    updater_stage_unsaid();
    return;
  }
  log_message(L_DEBUG, state, "[UPGRADE] Stage of %s: %s\n", id, status);
  hub_client_send_upgrade_progress(state, id, status);
}

static void hub_client_send_upgrade_ready(bot_state_t *state, const char *id,
                                          bool ready, const char *reason) {
  char arch[32], libc[16], clean_reason[192];
  updater_host_arch(arch, sizeof(arch));
  updater_host_libc(libc, sizeof(libc));
  upgrade_field(clean_reason, sizeof(clean_reason), reason);

  char payload[MAX_BUFFER / 8];
  int n = snprintf(payload, sizeof(payload), "%s|%s|%s|%s|%s|%s|%d|%s", id,
                   state->bot_uuid, BOT_VERSION, updater_host_variant(), arch,
                   libc, ready ? 1 : 0, clean_reason);
  if (n <= 0 || n >= (int)sizeof(payload)) return;
  hub_send_frame(state, CMD_UPGRADE_READY, payload, n);
  log_message(L_INFO, state, "[UPGRADE] %s upgrade %s%s%s\n",
              ready ? "Ready for" : "Cannot take", id,
              clean_reason[0] ? ": " : "", clean_reason);
}

/* id|uuid|status|new_ver */
void hub_client_send_upgrade_result(bot_state_t *state, const char *id,
                                    const char *status, const char *detail) {
  char clean_detail[192];
  upgrade_field(clean_detail, sizeof(clean_detail), detail);
  char payload[MAX_BUFFER / 8];
  int n = snprintf(payload, sizeof(payload), "%s|%s|%s|%s|%s", id,
                   state->bot_uuid, status, BOT_VERSION, clean_detail);
  if (n <= 0 || n >= (int)sizeof(payload)) return;
  hub_send_frame(state, CMD_UPGRADE_RESULT, payload, n);
}

/* Called once per authenticated link.  If this process is the product of a
 * hub-driven upgrade, the marker left behind by updater_hub_commit() says
 * which run it belongs to; report whether we came up on the version that run
 * was aiming at.  The hub also infers success from the presence frame, so a
 * lost RESULT costs nothing. */
void hub_client_report_upgrade_result(bot_state_t *state) {
  char id[64], want[64], want_variant[16], ops[UPGRADE_OPS_MAX];
  if (!updater_take_pending_upgrade(id, sizeof(id), want, sizeof(want),
                                    want_variant, sizeof(want_variant), ops,
                                    sizeof(ops)))
    return;
  bool ok = updater_version_cmp(BOT_VERSION, want) == 0 &&
            (!want_variant[0] ||
             strcmp(want_variant, updater_host_variant()) == 0);
  snprintf(state->upgrade_installed_id, sizeof(state->upgrade_installed_id),
           "%s", id);
  char wanted[96];
  snprintf(wanted, sizeof(wanted), "%s%s%s", want, want_variant[0] ? "/" : "",
           want_variant);
  log_message(L_INFO, state,
              "[UPGRADE] Restarted after %s: running %s/%s (wanted %s)\n", id,
              BOT_VERSION, updater_host_variant(), wanted);
  if (!ok) {
    char detail[192];
    if (!updater_failback_note(detail, sizeof(detail)))
      snprintf(detail, sizeof(detail), "wanted %s", wanted);
    hub_client_send_upgrade_result(state, id, "version-mismatch", detail);
    return;
  }
  /* On the right build — but not "done" until back where it was: on IRC and
   * re-opped in every channel it held ops in before (the marker's ops line).
   * The hub refills its wave only on done, so reporting now would let the
   * next bot leave a channel before this one holds ops in it again. */
  snprintf(state->upgrade_report_id, sizeof(state->upgrade_report_id), "%s", id);
  snprintf(state->upgrade_report_ops, sizeof(state->upgrade_report_ops), "%s", ops);
  state->upgrade_report_since = time(NULL);
  log_message(L_INFO, state, "[UPGRADE] Reporting done once back%s%s\n",
              ops[0] ? " and re-opped in " : " on IRC", ops);
  hub_client_upgrade_report_tick(state);
}

/* The channels of `ops` (space-separated) this bot is not yet back in with
 * ops, written to `missing`; true when there are none.  Channels come and go
 * from the config between runs, so one no longer configured is not waited
 * for — it can never be joined. */
static bool upgrade_ops_back(const bot_state_t *state, const char *ops,
                             char *missing, size_t missing_size) {
  missing[0] = '\0';
  char work[UPGRADE_OPS_MAX];
  snprintf(work, sizeof(work), "%s", ops);
  char *save = NULL;
  for (char *ch = strtok_r(work, " ", &save); ch; ch = strtok_r(NULL, " ", &save)) {
    const chan_t *c = state->chanlist;
    while (c && strcasecmp(c->name, ch) != 0) c = c->next;
    if (!c) continue;
    if (c->status == C_IN && c->i_am_opped) continue;
    size_t ml = strlen(missing);
    snprintf(missing + ml, missing_size - ml, "%s%s", ml ? " " : "", ch);
  }
  return missing[0] == '\0';
}

void hub_client_upgrade_report_tick(bot_state_t *state) {
  if (!state->upgrade_report_id[0] || !state->hub_authenticated) return;
  bool on_irc = (state->status & S_AUTHED) != 0;
  if (on_irc) updater_failback_confirm();
  char missing[UPGRADE_OPS_MAX];
  bool back = on_irc && upgrade_ops_back(state, state->upgrade_report_ops,
                                         missing, sizeof(missing));
  bool expired = time(NULL) - state->upgrade_report_since >= UPGRADE_OPS_WAIT;
  if (!back && !expired) return;
  char detail[UPGRADE_OPS_MAX + 64] = "";
  if (!back) {
    if (!on_irc)
      snprintf(detail, sizeof(detail), "back; IRC not reconnected");
    else
      snprintf(detail, sizeof(detail), "back; not re-opped in %s", missing);
  }
  log_message(L_INFO, state, "[UPGRADE] Reporting %s done%s%s\n",
              state->upgrade_report_id, detail[0] ? ": " : "", detail);
  hub_client_send_upgrade_result(state, state->upgrade_report_id, "ok", detail);
  state->upgrade_report_id[0] = '\0';
  state->upgrade_report_ops[0] = '\0';
}

/* id|target_ver|variant|kind|min_from|manifest_base — the hub is asking
 * whether we could move to target_ver.  Answer only; nothing is downloaded
 * and nothing on disk is touched until COMMIT. */
/* ==========================================================================
 * '|'-delimited wire fields
 *
 * sscanf's "%[^|]" cannot match an EMPTY field: the conversion fails there
 * and every field after it is left untouched.  An UPGRADE_PREPARE that names
 * neither a variant nor an artifact kind — "id|2.99.0|||*|file://…" — was
 * therefore read as two fields, silently dropping the manifest base and
 * sending the updater back to the compiled-in release URL.  These are the C
 * counterpart of split('|') in ircbot.rs, so both builds read a frame the
 * same way.
 * ========================================================================== */

/* Field `idx` of `s`, NUL-terminated into `dst`.  An over-long field is a
 * malformed frame, not something to truncate silently: false, `dst` empty. */
/* Send every pending activity report (auth_mark_used, chancfg_ban_mark_used)
 * to the hub, chunked
 * under MAX_BUFFER.  A record is cleared only once its frame went out; with
 * no hub link they wait for the next authentication. */
void hub_client_send_activity(bot_state_t *state) {
  if (!state->hub_authenticated || state->hub_fd == -1) return;
  const int cap = MAX_BUFFER - 64;
  char *buf = malloc((size_t)cap);
  if (!buf) return;
  const int nu = state->user_record_count, nm = state->mask_record_count;
  int len = 0, total = nu + nm + state->cfg_ban_count;
  int first = 0; /* first record index in the current chunk */
  for (int i = 0; i <= total; i++) {
    char line[MAX_MASK_LEN + MAX_CHAN + 96];
    int w = 0;
    if (i < nu) {
      const user_record_t *u = &state->user_records[i];
      if (u->act_pending > 0)
        w = snprintf(line, sizeof(line), "a|%s|%lld\n", u->uuid,
                     (long long)u->act_pending);
    } else if (i < nu + nm) {
      const mask_record_t *m = &state->mask_records[i - nu];
      if (m->act_pending > 0)
        w = snprintf(line, sizeof(line), "m|%s|%s|%lld\n", m->uuid, m->mask,
                     (long long)m->act_pending);
    } else if (i < total) {
      const cfg_ban_t *b = &state->cfg_bans[i - nu - nm];
      if (b->act_pending > 0)
        w = snprintf(line, sizeof(line), "B|%s|%s|%lld\n", b->chan, b->mask,
                     (long long)b->act_pending);
    }
    if (w >= (int)sizeof(line)) w = 0;
    /* Flush when the chunk is full or at the end. */
    if (len > 0 && (i == total || len + w > cap)) {
      if (!hub_send_frame(state, CMD_ACTIVITY, buf, len)) break;
      for (int j = first; j < i; j++) {
        if (j < nu)
          state->user_records[j].act_pending = 0;
        else if (j < nu + nm)
          state->mask_records[j - nu].act_pending = 0;
        else
          state->cfg_bans[j - nu - nm].act_pending = 0;
      }
      len = 0;
    }
    if (len == 0) first = i;
    if (w > 0) {
      memcpy(buf + len, line, (size_t)w);
      len += w;
    }
  }
  free(buf);
}

bool hub_client_send_activity_query(bot_state_t *state, const char *payload) {
  return hub_send_frame(state, CMD_ACTIVITY_QUERY, payload,
                        (int)strlen(payload));
}

static bool wire_field(const char *s, int idx, char *dst, size_t cap) {
  if (!dst || cap == 0) return false;
  dst[0] = '\0';
  if (!s) return false;
  for (int i = 0; i < idx; i++) {
    const char *bar = strchr(s, '|');
    if (!bar) return false;
    s = bar + 1;
  }
  const char *bar = strchr(s, '|');
  size_t len = bar ? (size_t)(bar - s) : strcspn(s, "\r\n");
  if (len >= cap) return false;
  memcpy(dst, s, len);
  dst[len] = '\0';
  return true;
}

/* Field `idx` and everything after it, minus any trailing CR/LF: the last
 * field of a frame is free text and may itself contain '|'.  Display text is
 * clamped to the buffer rather than rejected. */
static bool wire_tail(const char *s, int idx, char *dst, size_t cap) {
  if (!dst || cap == 0) return false;
  dst[0] = '\0';
  if (!s) return false;
  for (int i = 0; i < idx; i++) {
    const char *bar = strchr(s, '|');
    if (!bar) return false;
    s = bar + 1;
  }
  size_t len = strcspn(s, "\r\n");
  if (len >= cap) len = cap - 1;
  memcpy(dst, s, len);
  dst[len] = '\0';
  return true;
}

static void hub_client_handle_upgrade_prepare(bot_state_t *state,
                                              const char *payload) {
  char id[64] = "", ver[64] = "", variant[8] = "", kind[8] = "";
  char min_from[64] = "";
  if (!wire_field(payload, 0, id, sizeof(id)) ||
      !wire_field(payload, 1, ver, sizeof(ver)) || !id[0] || !ver[0]) {
    log_message(L_INFO, state, "[UPGRADE] Malformed UPGRADE_PREPARE\n");
    return;
  }
  wire_field(payload, 2, variant, sizeof(variant));
  wire_field(payload, 3, kind, sizeof(kind));
  wire_field(payload, 4, min_from, sizeof(min_from));
  /* Field 5 once carried a release base and is ignored: this bot reads only
   * its own root, the one its pinned key verifies. */

  /* Everything COMMIT will need is checked now — including the signed
   * manifest for the wanted build — so a "ready" answer is one COMMIT can
   * keep. */
  char reason[320];
  bool ready = updater_hub_prepare_check(state, ver, variant, min_from, reason,
                                         sizeof(reason));
  if (ready) {
    /* Remember the plan: COMMIT repeats only the id and the version. */
    snprintf(state->upgrade_id, sizeof(state->upgrade_id), "%s", id);
    snprintf(state->upgrade_target, sizeof(state->upgrade_target), "%s", ver);
    snprintf(state->upgrade_variant, sizeof(state->upgrade_variant), "%s",
             variant[0] ? variant : updater_host_variant());
    state->upgrade_prepared = time(NULL);
  }
  (void)kind; /* the artifact kind is chosen from the manifest at COMMIT */
  hub_client_send_upgrade_ready(state, id, ready, reason);
  /* A frame an older hub drops: this bot can get a build ready before COMMIT. */
  if (ready) hub_client_send_upgrade_progress(state, id, "ready|");
}

/* id: get the build ready.  Only a run we said ready to. */
static void hub_client_handle_upgrade_stage(bot_state_t *state, const char *payload) {
  char id[64] = "";
  wire_field(payload, 0, id, sizeof(id));
  if (!id[0] || !state->upgrade_id[0] || strcmp(state->upgrade_id, id) != 0) return;
  updater_stage_start(state->executable_path, id, state->upgrade_target, state->upgrade_variant);
}

/* id|target_ver|variant — go.  Only an id we acknowledged at PREPARE, and
 * only while that acknowledgement is still fresh, may commit. */
static void hub_client_handle_upgrade_commit(bot_state_t *state,
                                             const char *payload) {
  char id[64] = "", ver[64] = "", variant[8] = "";
  if (!wire_field(payload, 0, id, sizeof(id)) ||
      !wire_field(payload, 1, ver, sizeof(ver)) || !id[0] || !ver[0]) {
    log_message(L_INFO, state, "[UPGRADE] Malformed UPGRADE_COMMIT\n");
    return;
  }
  wire_field(payload, 2, variant, sizeof(variant));
  /* Every refusal here touched nothing, so it is answered "skip": this bot
   * stays healthy on its build and the driver takes it out of the run
   * instead of aborting everyone else's upgrade. */
  if (!state->upgrade_id[0] || strcmp(state->upgrade_id, id) != 0) {
    /* No run state (restarted since PREPARE?).  Already on that build means
     * the COMMIT's work is done. */
    bool there = updater_version_cmp(BOT_VERSION, ver) == 0 &&
                 (!variant[0] || strcmp(variant, updater_host_variant()) == 0);
    hub_client_send_upgrade_result(state, id, there ? "ok" : "skip",
                                   there ? "" : "no matching UPGRADE_PREPARE");
    return;
  }
  if (strcmp(state->upgrade_target, ver) != 0) {
    hub_client_send_upgrade_result(state, id, "skip",
                                   "commit version differs from prepare");
    return;
  }
  if (time(NULL) - state->upgrade_prepared > UPGRADE_PREPARE_TTL) {
    state->upgrade_id[0] = '\0';
    hub_client_send_upgrade_result(state, id, "skip", "prepare expired");
    return;
  }

  const char *err = NULL;
  if (!updater_hub_commit(state, id, ver,
                          variant[0] ? variant : state->upgrade_variant,
                          &err)) {
    /* Nothing was changed on disk; stay on this build and say why. */
    log_message(L_INFO, state, "[UPGRADE] Commit %s refused: %s\n", id,
                err ? err : "unknown error");
    /* A bad RELEASE (tampered, corrupt, the wrong product) is still "fail"
     * although nothing here changed: every node would hit the same artifact
     * and the run must stop.  Anything else is this bot's own refusal. */
    static const char *const marks[] = {
        "SHA-256 mismatch", "signature INVALID", "is not a ircbot release",
        "untrusted artifact URL"};
    bool integrity = false;
    for (size_t i = 0; err && i < sizeof(marks) / sizeof(marks[0]); i++)
      if (strstr(err, marks[i])) integrity = true;
    hub_client_send_upgrade_result(state, id, integrity ? "fail" : "skip",
                                   err ? err : "failed");
    state->upgrade_id[0] = '\0';
  }
  /* On success updater_hub_commit() does not return: the process is replaced
   * and hub_client_report_upgrade_result() reports in after the restart. */
}

/* id|reason — put the retained build back.  By the time this arrives the new
 * binary is usually already the running process, so undoing it is another
 * exec; a bot that has nothing retained just says so. */
static void hub_client_handle_upgrade_abort(bot_state_t *state,
                                            const char *payload) {
  char id[64] = "", reason[192] = "";
  wire_field(payload, 0, id, sizeof(id));
  wire_tail(payload, 1, reason, sizeof(reason));
  log_message(L_INFO, state, "[UPGRADE] Abort %s: %s\n",
              id[0] ? id : "(no id)", reason[0] ? reason : "no reason given");
  updater_stage_clear();
  state->upgrade_id[0] = '\0';
  state->upgrade_prepared = 0;
  /* Only the run that installed the build we are running may take it back.
   * A bot that refused the COMMIT (a bad hash, no .ircbot.pass) never moved,
   * and its <exe>.prev is the build from before an earlier, completed run:
   * rolling back to it would walk a healthy node off the version the rest of
   * the mesh is on. */
  if (!id[0] || strcmp(id, state->upgrade_installed_id) != 0) {
    log_message(L_INFO, state,
                "[UPGRADE] Abort %s: this bot is not running that run's build; "
                "nothing to roll back\n", id[0] ? id : "(no id)");
    hub_client_send_upgrade_result(state, id[0] ? id : "-", "aborted",
                                   "not moved by this run");
    return;
  }
  if (!updater_hub_rollback(state, reason[0] ? reason : "hub aborted the upgrade"))
    hub_client_send_upgrade_result(state, id[0] ? id : "-", "aborted",
                                   "nothing retained to roll back to");
  /* A successful rollback execs; the hub sees the old version reappear. */
}

/* Ingest a CMD_BOT_TREE push.  Every field is hub-supplied text that ends up
 * in an admin's IRC client, so each one is length-capped and stripped of
 * control bytes here rather than at render time.  A malformed row is skipped,
 * never partially applied. */
static void hub_client_process_tree(bot_state_t *state, char *payload,
                                    int payload_len) {
  if (!payload || payload_len <= 0) return;
  payload[payload_len] = '\0';

  /* Phase 5: keep the raw bytes before strtok_r mangles them, so a later
   * CMD_BOT_TREE_DELTA edits and re-hashes exactly what the hub hashed.  Too
   * large to hold (-1) means the delta fast-path is off: a delta pulls the
   * whole tree, and the keepalive hash is not checked (it could only pull the
   * same tree again every PING). */
  if (payload_len <= TREE_RAW_MAX) {
    memcpy(state->bot_tree_raw, payload, (size_t)payload_len);
    state->bot_tree_raw_len = payload_len;
  } else {
    state->bot_tree_raw_len = -1;
  }

  int count = 0;
  char *saveptr = NULL;
  for (char *line = strtok_r(payload, "\n", &saveptr);
       line && count < MAX_BOT_TREE_ROWS;
       line = strtok_r(NULL, "\n", &saveptr)) {
    if (line[0] == '\0' || line[1] != '|') continue;

    /* Split on '|' in place: the hub strips '|' from every value it forwards,
     * so a fixed field count is unambiguous. */
    char *f[8] = {0};
    int n = 0;
    char *cur = line + 2;
    while (n < 8) {
      f[n++] = cur;
      char *sep = strchr(cur, '|');
      if (!sep) break;
      *sep = '\0';
      cur = sep + 1;
    }

    bot_tree_row_t row;
    memset(&row, 0, sizeof(row));
    row.kind = (char)tolower((unsigned char)line[0]);

    if (row.kind == 'h' && n >= 5) {
      row.depth = atoi(f[0]);
      snprintf(row.name, sizeof(row.name), "%s", f[1]);
      snprintf(row.uuid, sizeof(row.uuid), "%s", f[2]);
      row.online = (atoi(f[3]) != 0);
      row.uptime = (time_t)atoll(f[4]);
      /* Version is the newest field on this row; a hub that does not send it
       * simply leaves the column blank. */
      if (n >= 6 && strcmp(f[5], "-") != 0)
        snprintf(row.version, sizeof(row.version), "%s", f[5]);
      /* The code base (c / rs) came after it; same rule, blank if absent. */
      if (n >= 7 && strcmp(f[6], "-") != 0)
        snprintf(row.variant, sizeof(row.variant), "%s", f[6]);
      /* Then the absolute start time, which replaces the uptime field. */
      if (n >= 8) {
        row.started = (time_t)atoll(f[7]);
        row.has_started = true;
      }
    } else if (row.kind == 'b' && n >= 6) {
      row.depth = atoi(f[0]);
      snprintf(row.name, sizeof(row.name), "%s", f[1]);
      snprintf(row.uuid, sizeof(row.uuid), "%s", f[2]);
      if (strcmp(f[3], "-") != 0)
        snprintf(row.version, sizeof(row.version), "%s", f[3]);
      if (strcmp(f[4], "-") != 0)
        snprintf(row.server, sizeof(row.server), "%s", f[4]);
      row.uptime = (time_t)atoll(f[5]);
      if (n >= 7 && strcmp(f[6], "-") != 0)
        snprintf(row.variant, sizeof(row.variant), "%s", f[6]);
      if (n >= 8) {
        row.started = (time_t)atoll(f[7]);
        row.has_started = true;
      }
      row.online = true;
    } else if (row.kind == 'd' && n >= 3) {
      snprintf(row.name, sizeof(row.name), "%s", f[0]);
      snprintf(row.uuid, sizeof(row.uuid), "%s", f[1]);
      row.uptime = (time_t)atoll(f[2]); /* last seen, not a duration */
      row.online = false;
    } else {
      continue;
    }
    if (strcmp(row.name, "-") == 0) row.name[0] = '\0';
    if (row.depth < 0) row.depth = 0;
    if (row.depth > MAX_TREE_DEPTH) row.depth = MAX_TREE_DEPTH;
    state->bot_tree[count++] = row;
  }

  state->bot_tree_count = count;
  state->bot_tree_ts = time(NULL);
 /* This logs excessively without much use; commented out for now. log_message(L_DEBUG, state, "[HUB] Bot tree updated (%d rows)\n", count); */
}

/* Phase 5: FNV-1a 64 over the raw tree, matching the hub's tree_fnv64. */
static uint64_t bot_tree_fnv64(const char *s, int n) {
  uint64_t h = 0xcbf29ce484222325ULL; /* FNV-1a 64 offset basis: both hubs and ircbot.rs must match */
  for (int i = 0; i < n; i++) {
    h ^= (unsigned char)s[i];
    h *= 1099511628211ULL;
  }
  return h;
}

/* uuid of a NUL-terminated row line, "" if malformed: field 3 of
 * KIND|depth|name|uuid|..., field 2 of an offline row D|nick|uuid|last_seen.
 * Must match the hubs' tree_row_uuid, which keys the delta ops. */
static void bot_row_uuid(const char *line, char *out, size_t cap) {
  out[0] = '\0';
  int bars = 0;
  int want = line[0] == 'D' ? 2 : 3;
  for (const char *p = line; *p; p++)
    if (*p == '|' && ++bars == want) {
      const char *q = p + 1;
      size_t o = 0;
      while (*q && *q != '|' && o + 1 < cap) out[o++] = *q++;
      out[o] = '\0';
      return;
    }
}

/* A pull should be rare (a delta always hashes right in order); log why at
 * debug so a pull rate in the hub stats can be traced to its cause. */
static void hub_client_request_tree_pull(bot_state_t *state, const char *why) {
  log_message(L_DEBUG, state, "[HUB] Tree delta not applied (%s); pulling the whole tree\n", why);
  hub_seal_frame(state, CMD_BOT_TREE_PULL, "", 0);
}

/* A hub keepalive's "t|<fnv64hex>": our tree hashing to it is a refresh (the
 * stale clock restarts, nothing is sent); anything else pulls the whole tree.
 * An empty or other payload (an older hub) is ignored. */
static void hub_client_check_tree_hash(bot_state_t *state, const char *p) {
  if (strncmp(p, "t|", 2) != 0) return;
  char *end = NULL;
  errno = 0;
  unsigned long long want = strtoull(p + 2, &end, 16);
  if (errno || !end || end == p + 2 || *end) return;
  int clen = state->bot_tree_raw_len;
  if (clen < 0) return; /* too large to hold: nothing to compare */
  if (clen == 0 || clen > TREE_RAW_MAX) {
    hub_client_request_tree_pull(state, "keepalive: no tree yet");
    return;
  }
  if (bot_tree_fnv64(state->bot_tree_raw, clen) != (uint64_t)want) {
    hub_client_request_tree_pull(state, "keepalive hash mismatch");
    return;
  }
  state->bot_tree_ts = time(NULL);
}

/* Ingest a CMD_BOT_TREE_DELTA: `<fnvhex>\n` then `-|uuid` / `+|anchor|row` ops.
 * Apply them to our raw tree, and accept only if the result hashes to <fnvhex>;
 * any divergence (a missed or mis-ordered row, no base tree yet, overflow)
 * pulls the whole tree instead.  Correctness never depends on the delta: the
 * hash is the gate, the pull the fallback. */
static void hub_client_process_tree_delta(bot_state_t *state, char *payload, int payload_len) {
  if (!payload || payload_len <= 0) return;
  payload[payload_len] = '\0';
  int clen = state->bot_tree_raw_len;
  if (clen <= 0 || clen > TREE_RAW_MAX) {
    hub_client_request_tree_pull(state, clen < 0 ? "tree too large to hold" : "no base tree");
    return;
  }
  char *saveptr = NULL;
  char *first = strtok_r(payload, "\n", &saveptr);
  char *end = NULL;
  errno = 0;
  unsigned long long want = first ? strtoull(first, &end, 16) : 0;
  if (!first || errno || !end || *end) {
    hub_client_request_tree_pull(state, "bad header");
    return;
  }

  static char cur[TREE_RAW_MAX + 1];
  memcpy(cur, state->bot_tree_raw, (size_t)clen);
  cur[clen] = '\0';
  /* The rows as the hub keys them (bot_row_uuid); every key is unique and
   * non-empty, or the hub sends the whole tree instead of a delta. */
  typedef struct {
    char *line;
    char  uuid[64];
  } drow_t;
  enum { DROWS_MAX = MAX_BOT_TREE_ROWS + 8 };
  static drow_t rows[DROWS_MAX];
  int nl = 0;
  bool overflow = false;
  char *sp = NULL;
  for (char *ln = strtok_r(cur, "\n", &sp); ln; ln = strtok_r(NULL, "\n", &sp)) {
    if (nl >= DROWS_MAX) {
      overflow = true; /* more rows than we track: pull rather than drop some */
      break;
    }
    rows[nl].line = ln;
    bot_row_uuid(ln, rows[nl].uuid, sizeof(rows[nl].uuid));
    nl++;
  }

  for (char *op = strtok_r(NULL, "\n", &saveptr); op && !overflow;
       op = strtok_r(NULL, "\n", &saveptr)) {
    char *u = NULL, *row = NULL, ru[64] = "";
    if (op[0] == '-' && op[1] == '|') {
      u = op + 2;
    } else if (op[0] == '+' && op[1] == '|') {
      char *bar = strchr(op + 2, '|');
      if (!bar) continue;
      *bar = '\0';
      row = bar + 1;
      bot_row_uuid(row, ru, sizeof(ru));
      if (!ru[0]) {
        overflow = true; /* a row with no key cannot be one the hub sent */
        break;
      }
      u = ru;
    } else {
      continue;
    }
    /* `-` removes the row; `+` replaces it, after its anchor (`^` = head). */
    for (int i = 0; i < nl; i++)
      if (strcmp(rows[i].uuid, u) == 0) {
        memmove(&rows[i], &rows[i + 1], (size_t)(nl - i - 1) * sizeof(rows[0]));
        nl--;
        break;
      }
    if (!row) continue;
    const char *anchor = op + 2;
    int pos = nl;
    if (strcmp(anchor, "^") == 0)
      pos = 0;
    else
      for (int i = 0; i < nl; i++)
        if (strcmp(rows[i].uuid, anchor) == 0) {
          pos = i + 1;
          break;
        }
    if (nl >= DROWS_MAX) {
      overflow = true;
      break;
    }
    memmove(&rows[pos + 1], &rows[pos], (size_t)(nl - pos) * sizeof(rows[0]));
    rows[pos].line = row;
    memcpy(rows[pos].uuid, ru, sizeof(ru));
    nl++;
  }

  static char nraw[TREE_RAW_MAX + 1];
  int o = 0;
  for (int i = 0; i < nl && !overflow; i++) {
    int w = snprintf(nraw + o, sizeof(nraw) - (size_t)o, "%s\n", rows[i].line);
    if (w < 0 || w >= (int)sizeof(nraw) - o)
      overflow = true;
    else
      o += w;
  }
  if (overflow || bot_tree_fnv64(nraw, o) != (uint64_t)want) {
    hub_client_request_tree_pull(state, "hash mismatch");
    return;
  }

  /* Accept: the applied tree matches the hub's.  Re-parse it for the renderer
   * (a separate copy; process_tree mangles what it parses). */
  if (o < 0 || o > TREE_RAW_MAX) {
    hub_client_request_tree_pull(state, "tree too large");
    return;
  }
  static char parsebuf[TREE_RAW_MAX + 1];
  memcpy(parsebuf, nraw, (size_t)o);
  hub_client_process_tree(state, parsebuf, o);
}

/* Push a single key=value change to the hub via CMD_BOT_DELTA.
 * This is a targeted update that the hub fans out as one DELTA per peer,
 * instead of the full config push which fans out ~50 lines.  Falls back to
 * hub_client_push_config if ts == 0 or key is empty. */
bool hub_client_push_delta(bot_state_t *state, const char *key,
                           const char *value, time_t ts) {
  if (!key || key[0] == '\0') return false;
  if (state->hub_count == 0 || state->hub_fd == -1 ||
      !state->hub_authenticated) return false;

  char payload[MAX_BUFFER];
  int pay_len = snprintf(payload, sizeof(payload), "%s|%s|%ld",
                         key, value ? value : "", (long)(ts ? ts : time(NULL)));
  /* The whole frame -- length, IV, [cmd][len:4], payload, tag -- must fit
   * plain[] / cipher[] and the hub's MAX_BUFFER receive cap; a payload just
   * under sizeof(payload) ran both buffers past their end. */
  if (pay_len <= 0 ||
      pay_len > MAX_BUFFER - (4 + GCM_IV_LEN + 5 + GCM_TAG_LEN)) return false;

  if (!hub_seal_frame(state, CMD_BOT_DELTA, payload, pay_len)) {
    log_message(L_INFO, state, "[HUB] Delta push failed, falling back\n");
    return false;
  }
  log_message(L_DEBUG, state, "[HUB] Delta pushed: %s=%s ts=%ld\n",
              key, value ? value : "", (long)ts);
  return true;
}

/* hl|<addr>/<fp>,...: the hubs this bot dials, so the hub console's hub del
 * can say which bots still list a hub.  <fp> is the first 8 bytes of SHA-256
 * over the hub's pinned Ed25519 key, in hex: never the key.  An address the
 * hub would refuse (over HL_ADDR_MAX, or a byte outside a host:port) goes out
 * empty.  The hub stamps the record itself.  0 when it does not fit. */
static int hub_client_hublist_line(const bot_state_t *state, char *out, size_t cap) {
  int w = snprintf(out, cap, "hl|");
  if (w < 0 || (size_t)w >= cap) return 0;
  size_t o = (size_t)w;
  int n = 0;
  for (int i = 0; i < state->hub_count && i < MAX_SERVERS; i++) {
    const hub_entry_t *he = &state->hubs[i];
    if (!he->ed_pub_set) continue;
    unsigned char md[EVP_MAX_MD_SIZE];
    unsigned int mdl = 0;
    if (EVP_Digest(he->ed_pub, sizeof(he->ed_pub), md, &mdl, EVP_sha256(), NULL) != 1 ||
        mdl < 8)
      continue;
    bool addr_ok = he->addr[0] && strlen(he->addr) <= HL_ADDR_MAX;
    for (const char *p = he->addr; addr_ok && *p; p++)
      addr_ok = isalnum((unsigned char)*p) || strchr(".:-_[]", *p);
    w = snprintf(out + o, cap - o, "%s%s/%02x%02x%02x%02x%02x%02x%02x%02x", n ? "," : "",
                 addr_ok ? he->addr : "", md[0], md[1], md[2], md[3], md[4], md[5], md[6],
                 md[7]);
    if (w < 0 || (size_t)w >= cap - o) return 0;
    o += (size_t)w;
    n++;
  }
  w = snprintf(out + o, cap - o, "\n");
  if (w < 0 || (size_t)w >= cap - o) return 0;
  return (int)(o + (size_t)w);
}

/**
 * Generate config payload for hub sync
 * Includes: c| (channels), h| (hostmask), n| (nick), v| (protocol version),
 * hl| (the hubs this bot dials)
 * Excludes: a|, o|, m| (hub-authoritative; pushed separately by
 * hub_client_push_admin_delta) and the local-only s|, u|, g|, l|, i|, k|
 * K| (what this bot saw on IRC) goes out for every managed channel, under
 * every opt (enforcement is never gated, D43).
 * Under opt 'h' (OPT_HUB_ONLY_MUTATIONS) c| is omitted, as are all but the
 * pending bot-written B| lines: the bot refuses join/part locally, so its
 * c| records can only be the hub's own copy,
 * and irchub's process_bot_config_push rejects them by type before any
 * timestamp compare — pushing them would just log one REJECTED line per
 * record on every connect.  (The retired bot password p| is never sent.)
 */
static void hub_client_generate_config_payload(bot_state_t *state, char *buffer,
                                               int max_len) {
  int offset = 0;
  int written;
  const bool hub_only = is_opt_set(state, OPT_HUB_ONLY_MUTATIONS);

  // Channels (c|: existence and the admin's key; none under opt 'h'), then
  // what this bot saw on IRC (K|, every opt: enforcement, D43).
  for (chan_t *c = state->chanlist; c != NULL && !hub_only; c = c->next) {
    if (c->timestamp == 0 && !c->is_managed)
      continue; /* known only from its C| line: no c| of its own yet */
    const char *op = c->is_managed ? "add" : "del";
    log_message(L_DEBUG, state, "[HUB-PUSH] Channel %s: is_managed=%d op=%s ts=%ld\n",
                c->name, c->is_managed, op, (long)c->timestamp);
    written = snprintf(buffer + offset, (size_t)(max_len - offset),
                       "c|%s|%s|%d|%s|%ld\n", c->name, c->ckey, (int)c->modes, op,
                       (long)c->timestamp);
    if (written < 0 || written >= max_len - offset)
      break;
    offset += written;
  }
  for (chan_t *c = state->chanlist; c != NULL; c = c->next) {
    if (!c->is_managed || c->l_ts == 0)
      continue;
    written = chan_format_l(c, buffer + offset, (size_t)(max_len - offset));
    if (written < 0)
      break;
    offset += written;
  }

  /* Bot-written bans (automatic bans) the hub has not got yet -- written
   * while the link was down.  Always pushed, whatever opt 'h' says (D43). */
  for (int i = 0; i < state->cfg_ban_count; i++) {
    const cfg_ban_t *b = &state->cfg_bans[i];
    if (!b->push_pending || !state->bot_uuid[0] ||
        strcmp(b->setter, state->bot_uuid) != 0)
      continue;
    char bl[B_LINE_MAX + 2];
    int n = chancfg_format_b_line(b, bl, sizeof(bl));
    if (n <= 0 || n >= max_len - offset)
      break;
    memcpy(buffer + offset, bl, (size_t)n);
    offset += n;
    buffer[offset] = '\0';
  }

  /* Admin/oper/mask records are hub-authoritative — bots receive them from hub,
   * they do NOT push them back. IRC admin commands (+admin, +usermask, etc.)
   * update local state and call hub_client_push_config, but only the bot-local
   * fields (channels, nick, hostmask) are included in the push payload.
   * The hub manages a|/o|/m| records via CMD_ADMIN_* commands only. */

  /* Protocol capability (passwordless.md §3.4), sent on every push and under
   * every opt.  The hub records it on this connection only and refuses a bot
   * below BOT_PROTO_USER_FLAGS.  (Bot->hub push namespace — unrelated to the
   * v| vhost line in the local config file.)  The timestamp field is unused. */
  written = snprintf(buffer + offset, (size_t)(max_len - offset), "v|%d|%d\n",
                     BOT_PROTO_VERSION, 1);
  if (written > 0 && written < max_len - offset) {
    offset += written;
  }

  // Hostmask — use the timestamp captured when actual_hostname last changed;
  // never use time(NULL) here or every push looks like new data to the hub.
  if (state->actual_hostname[0] != '\0' && state->actual_hostname_ts > 0) {
    written = snprintf(buffer + offset, (size_t)(max_len - offset), "h|%s|%ld\n",
                       state->actual_hostname, (long)state->actual_hostname_ts);
    if (written > 0 && written < max_len - offset) {
      offset += written;
    }
  }

  // Nick — same stable-timestamp rule.
  if (state->current_nick[0] != '\0' && state->current_nick_ts > 0) {
    written = snprintf(buffer + offset, (size_t)(max_len - offset), "n|%s|%ld\n",
                       state->current_nick, (long)state->current_nick_ts);
    if (written > 0 && written < max_len - offset) {
      offset += written;
    }
  }

  {
    char hl[HL_VALUE_MAX + 8];
    written = hub_client_hublist_line(state, hl, sizeof(hl));
    if (written > 0 && written < max_len - offset) {
      memcpy(buffer + offset, hl, (size_t)written);
      offset += written;
    }
  }

  buffer[offset] = '\0';
}

/* +bitch (D12) on CMD_OP_GRANT: the hub's op for a bot (OP_FORWARD) or an
 * old-style fan-out is refused for a nick that may not hold ops here, as
 * chan_elect_do refuses it.  A nick not in our roster is not vouched for
 * (fail closed). */
static bool op_grant_bitch_refuses(bot_state_t *state, chan_t *c, const char *nick) {
  if (!chancfg_get(state, c, CS_BITCH)) return false;
  bool found = false;
  bool auth = chan_member_authorised(state, c, nick, &found);
  if (found && auth) return false;
  log_message(L_INFO, state, "[HUB] Not granting ops to %s in %s: +bitch and %s\n",
              nick, c->name, found ? "not authorised" : "not in my roster");
  return true;
}

/**
 * Our own +o landed: grant the OP_GRANTs held while we had none, for nicks
 * still in the channel and not opped.  Older than OP_GRANT_HOLD_SECS: dropped.
 */
void hub_client_grant_held_ops(bot_state_t *state, chan_t *c) {
  time_t now = time(NULL);
  for (int i = 0; i < c->op_grant_held_count; i++) {
    if (now - c->op_grant_held[i].at > OP_GRANT_HOLD_SECS)
      continue;
    for (int k = 0; k < c->roster_count; k++) {
      if (strcasecmp(c->roster[k].nick, c->op_grant_held[i].nick) == 0) {
        if (!c->roster[k].is_op &&
            !op_grant_bitch_refuses(state, c, c->op_grant_held[i].nick)) {
          log_message(L_INFO, state,
                      "[HUB] Granting ops to %s in %s (held hub request)\n",
                      c->op_grant_held[i].nick, c->name);
          irc_printf(state, "MODE %s +o %s\r\n", c->name,
                     c->op_grant_held[i].nick);
        }
        break;
      }
    }
  }
  c->op_grant_held_count = 0;
}

/**
 * Send an op request via hub to another bot
 * Returns true if request was sent via hub, false to fallback to PRIVMSG
 */
bool hub_client_request_op(bot_state_t *state, const char *target_uuid,
                           const char *channel) {
  if (!state->hub_connected || !state->hub_authenticated ||
      state->hub_fd == -1) {
    return false; // Hub not available, use PRIVMSG fallback
  }

  // Don't request from ourselves
  if (strcmp(target_uuid, state->bot_uuid) == 0) {
    return false;
  }

  // Build payload: target_uuid|channel
  char payload[256];
  snprintf(payload, sizeof(payload), "%s|%s", target_uuid, channel);

  log_message(L_INFO, state,
              "[HUB] Requesting ops via hub: target=%s chan=%s\n",
              bot_who(state, 'b', target_uuid), channel);

  return hub_seal_frame(state, CMD_OP_REQUEST, payload, (int)strlen(payload));
}

/* Route a sealed bot command ("~B2 <b64>") to a specific bot by UUID via hub
 * relay.  The hub forwards it opaquely as "<sender_uuid>|~B2 <b64>".
 * Returns true if the frame was sent to the hub; false to fall back to PRIVMSG. */
bool hub_client_relay_bot_command(bot_state_t *state, const char *target_uuid,
                                  const char *frame_line) {
  if (!state->hub_connected || !state->hub_authenticated ||
      state->hub_fd == -1)
    return false;

  char payload[MAX_BUFFER];
  int pay_len = snprintf(payload, sizeof(payload), "%s|%s",
                         target_uuid, frame_line);
  if (pay_len <= 0 || pay_len >= (int)sizeof(payload)) return false;
  if (!hub_send_frame(state, CMD_BOT_RELAY, payload, pay_len)) return false;
  log_message(L_DEBUG, state,
              "[BOT-COMM] CMD_BOT_RELAY sent to hub for %s\n",
              bot_who(state, 'b', target_uuid));
  return true;
}

/* Ask the mesh to let us into a channel.  Only `kind|channel` goes on the
 * wire: the hub resolves our nick and hostmask from its own records, so this
 * frame cannot be used to ask for someone else's mask to be unbanned. */
bool hub_client_send_chan_request(bot_state_t *state, const char *kind,
                                  const char *channel) {
  if (!state->hub_connected || !state->hub_authenticated ||
      state->hub_fd == -1)
    return false;

  char payload[MAX_CHAN + 16];
  int pay_len = snprintf(payload, sizeof(payload), "%s|%s", kind, channel);
  if (pay_len <= 0 || pay_len >= (int)sizeof(payload))
    return false;
  if (!hub_send_frame(state, CMD_CHAN_REQUEST, payload, pay_len))
    return false;

  log_message(L_INFO, state, "[CHANREQ] Sent %s request for %s to hub\n", kind,
              channel);
  return true;
}

/* Answer one -- today only a `key`.  `data` carries the key, so the buffer is
 * wiped before returning rather than being left on the stack. */
bool hub_client_send_chan_reply(bot_state_t *state, const char *request_id,
                                const char *kind, const char *channel,
                                const char *status, const char *data) {
  if (!state->hub_connected || !state->hub_authenticated ||
      state->hub_fd == -1)
    return false;

  char payload[MAX_CHAN + MAX_KEY + 96];
  int pay_len = snprintf(payload, sizeof(payload), "%s|%s|%s|%s|%s", request_id,
                         kind, channel, status, data ? data : "");
  bool ok = false;
  if (pay_len > 0 && pay_len < (int)sizeof(payload))
    ok = hub_send_frame(state, CMD_CHAN_REPLY, payload, pay_len);
  secure_wipe(payload, sizeof(payload));
  return ok;
}

/* Push all user/mask records to hub via CMD_CONFIG_PUSH so the hub can store
 * and broadcast newly created or modified admin/oper/mask records.  The hub's
 * process_bot_config_push uses strict ts > stored_ts, so unchanged records
 * (same timestamp) are silently rejected — only new or modified ones land. */
void hub_client_push_admin_delta(bot_state_t *state) {
  if (!state->hub_authenticated || state->hub_fd == -1) {
    /* No hub link: send it after the next authentication (see
     * admin_delta_pending).  The flag is saved at once, so a restart before
     * then still pushes: the records carry their newer timestamps, and the
     * hub's LWW keeps whichever side changed last. */
    if (state->hub_count > 0 && !state->admin_delta_pending) {
      state->admin_delta_pending = true;
      config_write_local_with_state_pass(state);
    }
    return;
  }
  /* Cleared once every frame went out; either way the debounced flush saves
   * the flag's new value. */
  state->admin_delta_pending = true;
  state->config_dirty = true;

  /* Every record goes out: when the lines exceed one frame they are split
   * across several CMD_CONFIG_PUSH frames at line boundaries (the hub applies
   * each line independently, LWW by timestamp).  Users precede masks so a new
   * user always lands before its first mask. */
  const int chunk_cap = MAX_BUFFER - 64;
  char payload[MAX_BUFFER];
  int offset = 0, frames = 0;
  /* then the admin flags and oper channel bindings (uf| / uc|), after the
   * users they name */
  int nu = state->user_record_count, nm = state->mask_record_count;
  int nf = state->uflag_record_count;
  int total_lines = nu + nm + nf + state->uchan_record_count;

  for (int i = 0; i < total_lines; i++) {
    char line[CFG_MASK_LINE_MAX > CFG_USER_LINE_MAX ? CFG_MASK_LINE_MAX
                                                    : CFG_USER_LINE_MAX];
    int w;
    if (i < nu) {
      w = config_format_user_line(&state->user_records[i], line, sizeof(line));
    } else if (i < nu + nm) {
      const mask_record_t *m = &state->mask_records[i - nu];
      w = snprintf(line, sizeof(line), "m|%s|%s|%s|%ld|%ld\n", m->uuid,
                   m->mask, m->is_active ? "add" : "del", (long)m->last_used,
                   (long)m->timestamp);
    } else if (i < nu + nm + nf) {
      w = access_format_uflag(&state->uflag_records[i - nu - nm], line, sizeof(line));
    } else {
      w = access_format_uchan(&state->uchan_records[i - nu - nm - nf], line, sizeof(line));
    }
    if (w <= 0 || w >= (int)sizeof(line)) {
      log_message(L_INFO, state, "[HUB] Admin delta: record %d too long; "
                                 "skipped\n", i);
      continue;
    }
    if (offset + w > chunk_cap) {
      if (!hub_send_frame(state, CMD_CONFIG_PUSH, payload, offset)) return;
      frames++;
      offset = 0;
    }
    memcpy(payload + offset, line, (size_t)w);
    offset += w;
  }
  if (offset > 0) {
    if (!hub_send_frame(state, CMD_CONFIG_PUSH, payload, offset)) return;
    frames++;
  }
  state->admin_delta_pending = false;
  if (frames > 0)
    log_message(L_INFO, state,
                "[HUB] Admin delta pushed (%d user, %d mask records, %d "
                "frame%s)\n", state->user_record_count,
                state->mask_record_count, frames, frames == 1 ? "" : "s");
}

/**
 * Push full config to hub
 * Called: After authentication, after config changes
 */
void hub_client_push_config(bot_state_t *state) {
  if (state->hub_count == 0 || state->hub_fd == -1 ||
      !state->hub_authenticated) {
    log_message(L_DEBUG, state, "[HUB-PUSH] Skipped push: hub_count=%d hub_fd=%d auth=%d\n",
                state->hub_count, state->hub_fd, state->hub_authenticated);
    return; // Not hub-managed or not connected
  }

  char payload[MAX_BUFFER];
  hub_client_generate_config_payload(state, payload, sizeof(payload));

  if (strlen(payload) == 0) {
    log_message(L_DEBUG, state, "[HUB] No config to push\n");
    return;
  }

  log_message(L_DEBUG, state, "[HUB-SYNC] Pushing config to hub (%zu bytes)\n",
              strlen(payload));

  /* One seal path for every frame (review 6).  It also bounds the frame to
   * MAX_BUFFER: the inline copy here sealed a payload near sizeof(payload)
   * into cipher[MAX_BUFFER] with no room for the length, IV and tag. */
  int pay_len = (int)strlen(payload);
  if (hub_seal_frame(state, CMD_CONFIG_PUSH, payload, pay_len)) {
    for (int i = 0; i < state->cfg_ban_count; i++)
      state->cfg_bans[i].push_pending = false;
    log_message(L_INFO, state, "[HUB] Config pushed to hub\n");
  } else {
    log_message(L_INFO, state, "[HUB] Failed to push config (%d bytes)\n", pay_len);
  }
  secure_wipe(payload, sizeof(payload));
}

/* Push what this bot saw on a channel (K|) after a live MODE change or a
 * key another bot handed over.  Never c|: that would move the channel's
 * existence stamp, and a delete it races would be undone. */
void hub_client_push_channel(bot_state_t *state, chan_t *chan) {
  if (state->hub_count == 0 || state->hub_fd == -1 ||
      !state->hub_authenticated || !chan->is_managed || chan->l_ts == 0)
    return;
  char payload[MAX_CHAN + MAX_KEY + 48];
  int pay_len = chan_format_l(chan, payload, sizeof(payload));
  if (pay_len > 0 && hub_send_frame(state, CMD_CONFIG_PUSH, payload, pay_len)) {
    chan->enf_pending = false;
    log_message(L_INFO, state, "[HUB] Pushed channel %s modes=%d to hub\n",
                chan->name, (int)chan->modes);
  }
  secure_wipe(payload, sizeof(payload));
}

/* Complete record lines ("B|...\n") to the hub as one CMD_CONFIG_PUSH.  The
 * path a bot's own enforcement writes take: never gated by opt 'h' (D43). */
bool hub_client_push_lines(bot_state_t *state, const char *lines, size_t len) {
  if (state->hub_count == 0 || state->hub_fd == -1 ||
      !state->hub_authenticated || !lines || len == 0)
    return false;
  return hub_send_frame(state, CMD_CONFIG_PUSH, lines, (int)len);
}

/* ---- CMD_CHAN_EVENT emitter (D42) ---------------------------------------
 * One frame per enforcement action: "#chan|action|target|detail".  Limits,
 * all bot-side so a flood of events cannot become a flood to the hub:
 *   - the same (chan, action, target) at most once per CHAN_EVENT_DEDUPE_SECS;
 *   - at most CHAN_EVENT_WINDOW_MAX events per CHAN_EVENT_WINDOW_SECS;
 * excess is counted, and the count goes out once as "N events suppressed"
 * (target "*") as soon as an event is allowed again. */
static const char *const CHAN_EVENT_ACTIONS[] = {
  "deop", "reop", "kick", "ban", "unban", "moderevert", "limit", "floodtrip",
  "ignore", NULL
};

/* Copy src into dst (cap bytes incl. NUL) with control bytes and the record
 * delimiter flattened to spaces. */
static void event_clean(char *dst, size_t cap, const char *src) {
  size_t k = 0;
  for (; src && *src && k + 1 < cap; src++)
    dst[k++] = ((unsigned char)*src < 0x20 || *src == 0x7f || *src == '|')
                   ? ' ' : *src;
  dst[k] = '\0';
}

bool hub_client_chan_event(bot_state_t *state, const char *chan,
                           const char *action, const char *target,
                           const char *detail) {
  if (!chan || !action || !target)
    return false;
  if (chan[0] != '#' && chan[0] != '&')
    return false;
  bool known = false;
  for (int i = 0; CHAN_EVENT_ACTIONS[i]; i++)
    if (strcmp(action, CHAN_EVENT_ACTIONS[i]) == 0) { known = true; break; }
  if (!known || strlen(chan) >= MAX_CHAN)
    return false;
  if (state->hub_count == 0 || state->hub_fd == -1 || !state->hub_authenticated)
    return false;

  chan_event_lim_t *lim = &state->chan_event;
  time_t now = time(NULL);
  char tgt[CHAN_EVENT_TARGET_MAX + 1], det[CHAN_EVENT_DETAIL_MAX + 1];
  event_clean(tgt, sizeof(tgt), target);
  event_clean(det, sizeof(det), detail ? detail : "");
  if (tgt[0] == '\0')
    return false;

  /* Dedupe key: lower-cased "chan|action|target". */
  chan_event_seen_t *slot = NULL, *oldest = &lim->seen[0];
  char key[sizeof(lim->seen[0].key)];
  int kl = snprintf(key, sizeof(key), "%s|%s|%s", chan, action, tgt);
  if (kl <= 0 || kl >= (int)sizeof(key))
    return false;
  for (char *p = key; *p; p++)
    *p = (char)tolower((unsigned char)*p);
  for (int i = 0; i < CHAN_EVENT_TRACK; i++) {
    chan_event_seen_t *e = &lim->seen[i];
    if (e->when != 0 && strcmp(e->key, key) == 0) { slot = e; break; }
    if (e->when < oldest->when) oldest = e;
  }
  bool limited = slot && now - slot->when < CHAN_EVENT_DEDUPE_SECS;
  if (!limited) {
    time_t first = lim->window[lim->widx]; /* the oldest of the last N sends */
    limited = (first != 0 && now - first < CHAN_EVENT_WINDOW_SECS);
  }
  if (limited) {
    lim->suppressed++;
    snprintf(lim->sup_chan, sizeof(lim->sup_chan), "%s", chan);
    snprintf(lim->sup_action, sizeof(lim->sup_action), "%s", action);
    return false;
  }
  if (!slot) slot = oldest;
  snprintf(slot->key, sizeof(slot->key), "%s", key);
  slot->when = now;

  char out[MAX_CHAN + 16 + CHAN_EVENT_TARGET_MAX + CHAN_EVENT_DETAIL_MAX + 8];
  int n = snprintf(out, sizeof(out), "%s|%s|%s|%s", chan, action, tgt, det);
  if (n <= 0 || n >= (int)sizeof(out))
    return false;
  lim->window[lim->widx] = now;
  lim->widx = (lim->widx + 1) % CHAN_EVENT_WINDOW_MAX;
  bool sent = hub_send_frame(state, CMD_CHAN_EVENT, out, n);

  /* The summary of what the limiter held back, once, in its own slot of the
   * window (so a summary can never itself start a flood). */
  if (sent && lim->suppressed > 0) {
    time_t first = lim->window[lim->widx];
    if (first == 0 || now - first >= CHAN_EVENT_WINDOW_SECS) {
      char sd[48];
      snprintf(sd, sizeof(sd), "%u events suppressed", lim->suppressed);
      n = snprintf(out, sizeof(out), "%s|%s|*|%s", lim->sup_chan,
                   lim->sup_action, sd);
      if (n > 0 && n < (int)sizeof(out)) {
        lim->window[lim->widx] = now;
        lim->widx = (lim->widx + 1) % CHAN_EVENT_WINDOW_MAX;
        if (hub_send_frame(state, CMD_CHAN_EVENT, out, n))
          lim->suppressed = 0;
      }
    }
  }
  return sent;
}

/* PURGE|<cutoff>: drop tombstones (unmanaged channels, inactive user and
 * mask records) stamped before cutoff; 0 drops them all.  Orphans go at
 * every purge, as on the hubs: live bans and oper bindings of a channel no
 * one manages, masks whose user is gone (a channel's K| and C| live in its
 * chan_t and go with it).  The hub sends it as
 * its own CMD_CONFIG_DATA frame after the purged full config.  Channel
 * tombstones are merged, not replaced, by a config push, so only this line
 * removes them.  Returns the number of entries dropped (saved when > 0). */
static int hub_client_apply_purge(bot_state_t *state, const char *arg) {
  char *end = NULL;
  errno = 0;
  long long cutoff_val = strtoll(arg, &end, 10);
  if (errno || end == arg || *end != '\0' || cutoff_val < 0) {
    log_message(L_INFO, state, "[HUB] Rejected malformed PURGE line\n");
    return 0;
  }
  time_t cutoff = (time_t)cutoff_val;
  int purged = 0;

  chan_t *c = state->chanlist;
  while (c) {
    chan_t *next = c->next;
    if (!c->is_managed && (cutoff == 0 || c->timestamp < cutoff)) {
      channel_remove(state, c->name);
      purged++;
    }
    c = next;
  }

  for (int i = 0; i < state->user_record_count; i++) {
    if (!state->user_records[i].is_active &&
        (cutoff == 0 || state->user_records[i].timestamp < cutoff)) {
      memmove(&state->user_records[i], &state->user_records[i + 1],
              (size_t)(state->user_record_count - i - 1) * sizeof(user_record_t));
      state->user_record_count--;
      purged++;
      i--;
    }
  }

  for (int i = 0; i < state->mask_record_count; i++) {
    /* a mask whose user is gone is an orphan (irchub purge) */
    bool owned = false;
    for (int u = 0; u < state->user_record_count && !owned; u++)
      owned = strcmp(state->user_records[u].uuid, state->mask_records[i].uuid) == 0;
    if (!owned || (!state->mask_records[i].is_active &&
                   (cutoff == 0 || state->mask_records[i].timestamp < cutoff))) {
      memmove(&state->mask_records[i], &state->mask_records[i + 1],
              (size_t)(state->mask_record_count - i - 1) * sizeof(mask_record_t));
      state->mask_record_count--;
      purged++;
      i--;
    }
  }

  purged += chancfg_purge_bans(state, cutoff);
  /* binding tombstones, and flags / bindings whose user went above (a live
   * user's "*" del stays) */
  purged += access_purge(state, cutoff);

  if (purged > 0) {
    log_message(L_INFO, state, "[HUB] Purged %d tombstoned entries\n", purged);
    config_write_with_state_pass(state);
  }
  return purged;
}

/* A hub config replaces the user / mask / flag / binding tables wholesale;
 * these find a rebuilt record's twin in the copy taken before, so only a
 * real difference counts as an update (and costs a config write).  Every
 * full config re-sends every record: counting them all rewrote the .cnf
 * (a 600k-round KDF) on each push. */
static const user_record_t *saved_user_find(const user_record_t *saved, int n,
                                            const char *uuid) {
  for (int i = 0; i < n; i++)
    if (strcmp(saved[i].uuid, uuid) == 0) return &saved[i];
  return NULL;
}

/* Persisted fields only; last_seen is compared by the caller. */
static bool user_rec_same(const user_record_t *a, const user_record_t *b) {
  return strcmp(a->name, b->name) == 0 &&
         strcmp(a->pubkey_b64, b->pubkey_b64) == 0 &&
         a->has_pubkey == b->has_pubkey && a->type == b->type &&
         a->is_active == b->is_active && a->timestamp == b->timestamp;
}

static const mask_record_t *saved_mask_find(const mask_record_t *saved, int n,
                                            const char *uuid, const char *mask) {
  for (int i = 0; i < n; i++)
    if (strcmp(saved[i].uuid, uuid) == 0 && strcasecmp(saved[i].mask, mask) == 0)
      return &saved[i];
  return NULL;
}

/* Records that differ from (or are missing in) the saved table, plus saved
 * ones the rebuild dropped. */
static int user_table_changes(const bot_state_t *state, const user_record_t *saved,
                              int n) {
  int changes = 0, matched = 0;
  for (int i = 0; i < state->user_record_count; i++) {
    const user_record_t *u = &state->user_records[i];
    const user_record_t *w = saved_user_find(saved, n, u->uuid);
    if (w) matched++;
    if (!w || !user_rec_same(w, u) || w->last_seen != u->last_seen) changes++;
  }
  return changes + (n - matched);
}

static int mask_table_changes(const bot_state_t *state, const mask_record_t *saved,
                              int n) {
  int changes = 0, matched = 0;
  for (int i = 0; i < state->mask_record_count; i++) {
    const mask_record_t *m = &state->mask_records[i];
    const mask_record_t *w = saved_mask_find(saved, n, m->uuid, m->mask);
    if (w) matched++;
    if (!w || w->is_active != m->is_active || w->timestamp != m->timestamp ||
        w->last_used != m->last_used)
      changes++;
  }
  return changes + (n - matched);
}

static int access_table_changes(const bot_state_t *state,
                                const uflag_record_t *sf, int nf,
                                const uchan_record_t *sc, int nc) {
  int changes = 0, matched = 0;
  for (int i = 0; i < state->uflag_record_count; i++) {
    const uflag_record_t *f = &state->uflag_records[i];
    const uflag_record_t *w = NULL;
    for (int j = 0; j < nf && !w; j++)
      if (strcmp(sf[j].uuid, f->uuid) == 0) w = &sf[j];
    if (w) matched++;
    if (!w || strcmp(w->flags, f->flags) != 0 || w->timestamp != f->timestamp)
      changes++;
  }
  changes += nf - matched;
  matched = 0;
  for (int i = 0; i < state->uchan_record_count; i++) {
    const uchan_record_t *c = &state->uchan_records[i];
    const uchan_record_t *w = NULL;
    for (int j = 0; j < nc && !w; j++)
      if (strcmp(sc[j].uuid, c->uuid) == 0 && strcasecmp(sc[j].chan, c->chan) == 0)
        w = &sc[j];
    if (w) matched++;
    if (!w || w->is_active != c->is_active || w->timestamp != c->timestamp)
      changes++;
  }
  return changes + (nc - matched);
}

static void hub_client_process_config_data(bot_state_t *state, const char *payload) {
  log_message(L_DEBUG, state, "[HUB-SYNC] Processing config data from hub\n");

  /* Hub is authoritative for user/mask records. Replace rather than merge so
   * the bot always has exactly the hub's current set — no stale or duplicate
   * UUIDs from a previous sync can accumulate. Preserve last_seen/last_used
   * that were updated locally since the last hub push.
   *
   * Only wipe a table when this payload actually carries records of that kind.
   * A payload legitimately lacking a|/o| (or m|) lines — the hub has none, or a
   * partial/other push — must NOT silently empty the in-memory table (which,
   * combined with the updates>0 save-gate below, would diverge RAM from disk).
   * When such lines ARE present the "replace to drop stale UUIDs" semantics
   * still hold, because parsing rebuilds the whole set. */
  bool has_user_lines = false, has_mask_lines = false, has_trust_set = false;
  bool has_access_lines = false;
  for (const char *p = payload; p && *p; ) {
    if ((p[0] == 'a' || p[0] == 'o') && p[1] == '|') has_user_lines = true;
    else if (p[0] == 'm' && p[1] == '|') has_mask_lines = true;
    else if (p[0] == 'u' && (p[1] == 'f' || p[1] == 'c') && p[2] == '|') has_access_lines = true;
    else if (p[0] == 'T' && p[1] == '|') has_trust_set = true;
    const char *nl = strchr(p, '\n');
    if (!nl) break;
    p = nl + 1;
  }

  user_record_t saved_users[MAX_USER_RECORDS];
  mask_record_t saved_masks[MAX_USER_MASKS];
  int saved_user_count = state->user_record_count;
  int saved_mask_count = state->mask_record_count;
  memcpy(saved_users, state->user_records, sizeof(user_record_t) * (size_t)saved_user_count);
  memcpy(saved_masks, state->mask_records, sizeof(mask_record_t) * (size_t)saved_mask_count);
  /* Static like work_buf below: single-threaded, non-reentrant. */
  static uflag_record_t saved_uflags[MAX_USER_FLAGS];
  static uchan_record_t saved_uchans[MAX_CHAN_BINDS];
  int saved_uflag_count = state->uflag_record_count;
  int saved_uchan_count = state->uchan_record_count;
  memcpy(saved_uflags, state->uflag_records, sizeof(uflag_record_t) * (size_t)saved_uflag_count);
  memcpy(saved_uchans, state->uchan_records, sizeof(uchan_record_t) * (size_t)saved_uchan_count);
  if (has_user_lines) state->user_record_count = 0;
  if (has_mask_lines) state->mask_record_count = 0;
  /* uf| / uc| (user_flags plan): the hub's set replaces ours like a|/o|/m|. */
  if (has_access_lines) {
    state->uflag_record_count = 0;
    state->uchan_record_count = 0;
  }

  /* Change 5: static, sized to a full config payload so a large hub config is
   * parsed whole (no truncation).  Single-threaded, non-reentrant. */
  static char work_buf[MAX_CONFIG_PAYLOAD];
  size_t work_len = strnlen(payload, sizeof(work_buf) - 1);
  memcpy(work_buf, payload, work_len);
  work_buf[work_len] = '\0';

  /* UUIDs named by this payload's b| lines.  With a T| marker the hub is
   * saying "this is the whole trusted set", and every other trusted bot is
   * dropped after the parse (a deleted or purged bot must lose ~B2 and op
   * trust).  Static like work_buf: single-threaded, non-reentrant. */
  static char listed_uuids[MAX_TRUSTED_BOTS][37];
  int listed_count = 0;

  char *saveptr;
  char *line = strtok_r(work_buf, "\n", &saveptr);
  int updates = 0;

  while (line) {
    if (strlen(line) < 2 || line[0] == '#') {
      line = strtok_r(NULL, "\n", &saveptr);
      continue;
    }

    /* PURGE|<cutoff> is the one line whose type is a word, not a letter:
     * it has to be taken before the "X|" shape check below, which used to
     * drop it (bots never applied a hub purge). */
    if (strncmp(line, "PURGE|", 6) == 0) {
      hub_client_apply_purge(state, line + 6);
      line = strtok_r(NULL, "\n", &saveptr);
      continue;
    }

    /* uf| / uc|: admin flags and oper channel bindings (access.c) */
    if (line[0] == 'u' && (line[1] == 'f' || line[1] == 'c') && line[2] == '|') {
      /* counted against the saved tables after the parse */
      if (!access_ingest(state, line[1], line + 3, false, NULL))
        log_message(L_DEBUG, state, "[HUB-SYNC] Malformed %.2s| record ignored\n", line);
      line = strtok_r(NULL, "\n", &saveptr);
      continue;
    }

    // Parse: type|field1|field2|operation|timestamp
    char type = line[0];
    if (line[1] != '|') {
      line = strtok_r(NULL, "\n", &saveptr);
      continue;
    }

    char *data = line + 2; // Skip "type|"

    switch (type) {
    case 'c': // Channel
    {
      char chan[MAX_CHAN], key[MAX_KEY], op[8];
      long long ts = 0; /* the old 4-field form can match without one */
      int parsed;
      int modes_val = 0;

      /* Try new 5-field format: chan|key|modes|op|ts */
      parsed = sscanf(data, "%64[^|]|%30[^|]|%d|%7[^|]|%lld",
                      chan, key, &modes_val, op, &ts);
      if (parsed < 5) {
        /* Try new 5-field without key: chan||modes|op|ts */
        modes_val = 0;
        parsed = sscanf(data, "%64[^|]||%d|%7[^|]|%lld",
                        chan, &modes_val, op, &ts);
        if (parsed >= 4) {
          key[0] = '\0';
        } else {
          /* Fall back to old 4-field: chan|key|op|ts */
          modes_val = 0;
          parsed = sscanf(data, "%64[^|]|%30[^|]|%7[^|]|%lld",
                          chan, key, op, &ts);
          if (parsed < 3) {
            /* Old 4-field without key: chan||op|ts */
            parsed = sscanf(data, "%64[^|]||%7[^|]|%lld", chan, op, &ts);
            key[0] = '\0';
          }
        }
      }

      if (parsed >= 3) {
        bool is_add = (strcmp(op, "add") == 0);
        chan_t *c = channel_find(state, chan);

        log_message(L_DEBUG, state, "[HUB-SYNC] Channel %s: hub_ts=%lld local_ts=%ld op=%s\n",
                    chan, ts, c ? (long)c->timestamp : 0, op);

        if (!c && is_add) {
          // New channel from hub
          c = channel_add(state, chan);
          if (c) {
            /* c| is existence and the admin's key; its modes field is the
             * hub's copy of K| (the authority, applied when it arrives). */
            snprintf(c->ckey, sizeof(c->ckey), "%s", key);
            c->modes = (chan_mode_t)(modes_val & (M_K | M_I));
            c->is_managed = true;
            c->timestamp = ts;
            chan_key_refresh(c);
            updates++;
            log_message(L_INFO, state, "[HUB] Added channel: %s\n", chan);
          }
        } else if (c) {
          // Compare timestamps (a same-second del beats an add: lww_accepts)
          if (lww_accepts((time_t)ts, is_add, c->timestamp, c->is_managed)) {
            // Hub has newer data
            snprintf(c->ckey, sizeof(c->ckey), "%s", key);
            if (c->l_ts == 0) c->modes = (chan_mode_t)(modes_val & (M_K | M_I));
            bool was_managed = c->is_managed;
            c->is_managed = is_add;
            c->timestamp = ts;
            /* what the bots saw goes with a deleted channel (no tombstone) */
            if (!is_add) chan_learned_forget(c);
            chan_key_refresh(c);
            updates++;
            log_message(L_INFO, state, "[HUB] Updated channel: %s (%s)\n", chan,
                        op);
            /* a channel removed takes its oper bindings with it, at the
             * same stamp, as on every hub (user_flags plan U6) */
            if (!is_add) access_chan_cascade(state, chan, (time_t)ts);
            // If channel changed from managed to unmanaged, PART the channel
            if (was_managed && !is_add && c->status == C_IN) {
              log_message(L_INFO, state, "[HUB] Parting channel %s (synced del)\n", chan);
              irc_printf(state, "PART %s :Hub sync\r\n", chan);
              c->status = C_OUT;
            }
            // If channel changed from unmanaged to managed, JOIN the channel
            if (!was_managed && is_add && c->status != C_IN) {
              log_message(L_INFO, state, "[HUB] Joining channel %s (synced add)\n", chan);
              if (c->key[0] != '\0') {
                irc_printf(state, "JOIN %s %s\r\n", chan, c->key);
              } else {
                irc_printf(state, "JOIN %s\r\n", chan);
              }
            }
          } else {
            log_message(L_DEBUG, state, "[HUB-SYNC] Rejected channel %s: hub_ts=%lld local_ts=%ld (not newer)\n",
                        chan, ts, (long)c->timestamp);
          }
        } else if (!c && !is_add) {
          log_message(L_DEBUG, state, "[HUB-SYNC] Skipped del for non-existent channel: %s\n", chan);
        }
      }
    } break;

    case 'm': // Usermask record (new: uuid|mask|add/del|last_used|ts)
    {
      char first_m[40] = {0};
      char *pfm = strchr(data, '|');
      if (pfm) { size_t fl=(size_t)(pfm-data); if(fl<sizeof(first_m)){memcpy(first_m,data,fl);first_m[fl]=0;} }
      bool is_new_m = (strlen(first_m)==36 && first_m[8]=='-' && first_m[13]=='-' && first_m[18]=='-' && first_m[23]=='-');
      if (is_new_m) {
        char *p1=strchr(data,'|'), *p2=p1?strchr(p1+1,'|'):NULL;
        char *p3=p2?strchr(p2+1,'|'):NULL, *p4=p3?strchr(p3+1,'|'):NULL;
        if (p1&&p2&&p3&&p4) {
          char uuid[37], mask_s[MAX_MASK_LEN], act[8];
          long long last_used, ts;
          snprintf(uuid,   sizeof(uuid),   "%.*s",(int)(p1-data),data);
          snprintf(mask_s, sizeof(mask_s), "%.*s",(int)(p2-p1-1),p1+1);
          snprintf(act,    sizeof(act),    "%.*s",(int)(p3-p2-1),p2+1);
          last_used = atoll(p3+1); ts = atoll(p4+1);
          bool is_active = (strncmp(act,"add",3)==0);
          mask_record_t *found_m = NULL;
          for (int mi=0; mi<state->mask_record_count; mi++) {
            if (strcmp(state->mask_records[mi].uuid,uuid)==0 &&
                strcasecmp(state->mask_records[mi].mask,mask_s)==0) {
              found_m = &state->mask_records[mi]; break;
            }
          }
          if (!found_m && state->mask_record_count < MAX_USER_MASKS) {
            found_m = &state->mask_records[state->mask_record_count++];
            memset(found_m,0,sizeof(*found_m));
            snprintf(found_m->uuid,sizeof(found_m->uuid),"%s",uuid);
            snprintf(found_m->mask,sizeof(found_m->mask),"%s",mask_s);
          }
          if (found_m && lww_accepts((time_t)ts, is_active, found_m->timestamp,
                                     found_m->is_active)) {
            found_m->is_active = is_active;
            if (last_used > found_m->last_used) found_m->last_used = last_used;
            found_m->timestamp = ts;
            /* counted after the parse; logged only when it changed */
            const mask_record_t *was = saved_mask_find(saved_masks, saved_mask_count,
                                                       uuid, mask_s);
            if (!was || was->is_active != is_active || was->timestamp != ts)
              log_message(L_INFO, state, "[HUB] Synced mask %s (%s)\n", mask_s, act);
          }
        }
      }
    } break;

    case 'o': // Oper user record  } config_parse_user_line
    case 'a': // Admin user record }
    {
      user_line_t ul;
      if (!config_parse_user_line(data, &ul)) {
        log_message(L_DEBUG, state, "[HUB-SYNC] Malformed %c| record ignored\n",
                    type);
        break;
      }
      user_record_t *found_u = NULL;
      for (int ui = 0; ui < state->user_record_count; ui++) {
        if (strcmp(state->user_records[ui].uuid, ul.uuid) == 0) {
          found_u = &state->user_records[ui]; break;
        }
      }
      if (!found_u && state->user_record_count < MAX_USER_RECORDS) {
        found_u = &state->user_records[state->user_record_count++];
        memset(found_u, 0, sizeof(*found_u));
        memcpy(found_u->uuid, ul.uuid, sizeof(found_u->uuid));
      }
      if (found_u && lww_accepts(ul.timestamp, ul.is_active,
                                 found_u->timestamp, found_u->is_active)) {
        memcpy(found_u->name, ul.name, sizeof(found_u->name));
        /* The hub is authoritative for the key too: a record that arrives
         * keyless leaves the user keyless (cannot authenticate). */
        memcpy(found_u->pubkey_b64, ul.pubkey_b64, sizeof(found_u->pubkey_b64));
        found_u->has_pubkey = ul.has_pubkey;
        found_u->type      = type;
        found_u->is_active = ul.is_active;
        if (ul.last_seen > found_u->last_seen) found_u->last_seen = ul.last_seen;
        found_u->timestamp = ul.timestamp;
        /* counted after the parse; logged only when it changed */
        const user_record_t *was = saved_user_find(saved_users, saved_user_count,
                                                   ul.uuid);
        if (!was || !user_rec_same(was, found_u))
          log_message(L_INFO, state, "[HUB] Synced user %s (%c/%s%s)\n", ul.name,
                      type, ul.is_active ? "add" : "del",
                      ul.has_pubkey ? "" : ", no key");
      }
    } break;

    case 'O': /* Network opt flags pushed by hub: O|<letters>|<ts> */
    {
      char flags[MAX_OPT_FLAGS + 1] = {0};
      long long ts = 0;
      /* The hub sends "O||<ts>" when every flag is cleared.  %[^|] fails on
       * an empty field, so parse that form on its own or a clear never lands
       * and the bot keeps enforcing e.g. opt 'h' after the network dropped it. */
      bool ok = (data[0] == '|')
                    ? (sscanf(data + 1, "%lld", &ts) == 1)
                    : (sscanf(data, "%32[^|]|%lld", flags, &ts) >= 1);
      if (ok) {
        char clean[MAX_OPT_FLAGS + 1];
        int w = 0;
        for (int i = 0; flags[i] && w < MAX_OPT_FLAGS; i++) {
          char c = flags[i];
          if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
              (c >= '0' && c <= '9'))
            clean[w++] = c;
        }
        clean[w] = '\0';
        if (opt_accepts((time_t)ts, clean, state->opt_flags_ts,
                        state->opt_flags)) {
          memcpy(state->opt_flags, clean, (size_t)w + 1);
          state->opt_flags_ts = (ts > 0) ? (time_t)ts : time(NULL);
          log_message(L_INFO, state, "[HUB-SYNC] opt flags updated -> '%s'\n",
                      state->opt_flags);
          updates++;
        }
      }
    } break;

    /* K|: what the bots saw on IRC.  Never existence: chan_learned_ingest
     * takes it only for a channel managed here. */
    case 'K':
      if (chan_learned_ingest(state, data)) {
        updates++;
        log_message(L_DEBUG, state, "[HUB-SYNC] Learned channel state updated\n");
      }
      break;

    /* modes.md records.  Each is bounded and validated in chancfg.c; a line
     * that does not parse is dropped, one this build cannot use is kept. */
    case 'C':
      if (chancfg_apply_c_line(state, data)) {
        updates++;
        log_message(L_DEBUG, state, "[HUB-SYNC] Channel settings updated\n");
      }
      break;
    case 'D':
      if (chancfg_apply_d_line(state, data)) {
        updates++;
        log_message(L_DEBUG, state, "[HUB-SYNC] Network defaults updated\n");
      }
      break;
    case 'B':
      if (chancfg_apply_b_line(state, data)) {
        updates++;
        log_message(L_DEBUG, state, "[HUB-SYNC] Ban record updated\n");
      }
      break;

    case 'b': // Trusted bot: b|mask|uuid|pubkey|ts
    {
      trusted_bot_t in;
      if (!config_parse_bot_line(data, &in)) {
        /* A trust record is never stored truncated — a clipped mask or uuid
         * would silently mis-key every later match — so refuse instead. */
        log_message(L_INFO, state,
                    "[HUB] Rejected malformed/oversized trusted-bot line\n");
        break;
      }
      if (in.uuid[0] && listed_count < MAX_TRUSTED_BOTS)
        memcpy(listed_uuids[listed_count++], in.uuid, sizeof(listed_uuids[0]));

      // Find existing entry: prefer UUID match (handles nick/host changes),
      // fall back to hostmask match.  Also sweep out any duplicate entries
      // for the same UUID so stale masks from previous sessions don't linger.
      int existing_idx = -1;
      if (in.uuid[0] != '\0') {
        for (int i = 0; i < state->trusted_bot_count; i++) {
          if (strcmp(state->trusted_bots[i].uuid, in.uuid) != 0) continue;
          if (existing_idx == -1) {
            existing_idx = i; // keep first match
          } else {
            memmove(&state->trusted_bots[i], &state->trusted_bots[i + 1],
                    (size_t)(state->trusted_bot_count - i - 1) *
                        sizeof(trusted_bot_t));
            state->trusted_bot_count--;
            i--;
          }
        }
      }
      if (existing_idx == -1) {
        for (int i = 0; i < state->trusted_bot_count; i++) {
          if (strcmp(state->trusted_bots[i].mask, in.mask) == 0) {
            existing_idx = i;
            break;
          }
        }
      }

      if (existing_idx != -1) {
        trusted_bot_t *ex = &state->trusted_bots[existing_idx];
        bool key_is_new = in.has_pub &&
            (!ex->has_pub || memcmp(ex->pub, in.pub, HUB_KEY_RAW_LEN) != 0);
        /* ts = max(hostmask ts, key ts) on the hub, so a rekey alone bumps
         * it; the equal-ts case takes a key that arrived after a keyless line
         * under the same hostmask ts. */
        if (in.ts > ex->ts || (in.ts == ex->ts && key_is_new)) {
          if (!in.has_pub && ex->has_pub && strcmp(ex->uuid, in.uuid) == 0) {
            /* A keyless line for a bot whose key we hold: keep the key. */
            in.has_pub = true;
            memcpy(in.pub, ex->pub, HUB_KEY_RAW_LEN);
          }
          *ex = in;
          updates++;
          log_message(L_INFO, state, "[HUB] Updated trusted bot: %s%s\n",
                      in.mask, key_is_new ? " (new key)" : "");
        }
      } else if (state->trusted_bot_count < MAX_TRUSTED_BOTS) {
        state->trusted_bots[state->trusted_bot_count++] = in;
        updates++;
        log_message(L_INFO, state, "[HUB] Added trusted bot: %s%s\n", in.mask,
                    in.has_pub ? "" : " (no key yet)");
      }
    } break;

    case 'T': // T|<count>: end of the hub's complete trusted-bot list (swept below)
      break;

    default:
      log_message(L_DEBUG, state, "[HUB-SYNC] Unrecognized line type '%c': %s\n", type, line);
      break;
    }

    line = strtok_r(NULL, "\n", &saveptr);
  }

  if (has_trust_set) {
    for (int i = 0; i < state->trusted_bot_count;) {
      const trusted_bot_t *tb = &state->trusted_bots[i];
      bool listed = false;
      for (int j = 0; j < listed_count && !listed; j++)
        listed = tb->uuid[0] && strcmp(listed_uuids[j], tb->uuid) == 0;
      if (listed) {
        i++;
        continue;
      }
      log_message(L_INFO, state,
                  "[HUB] Revoked trusted bot: %s (%s) - no longer registered "
                  "on the hub\n", tb->mask, tb->uuid[0] ? tb->uuid : "no uuid");
      memmove(&state->trusted_bots[i], &state->trusted_bots[i + 1],
              (size_t)(state->trusted_bot_count - i - 1) * sizeof(trusted_bot_t));
      state->trusted_bot_count--;
      memset(&state->trusted_bots[state->trusted_bot_count], 0,
             sizeof(trusted_bot_t));
      updates++;
    }
  }

  /* Flags / bindings of users this payload dropped go; a user it brought
   * without any gets its default (access_migrate). */
  access_prune(state);
  access_migrate(state);

  /* Restore locally-updated last_seen / last_used timestamps that are newer
   * than what the hub sent (e.g. from recent auths not yet flushed to hub),
   * and the runtime-only fields the rebuild zeroed: an unsent CMD_ACTIVITY
   * time and the ~A2K rate limit. */
  for (int i = 0; i < state->user_record_count; i++) {
    user_record_t *u = &state->user_records[i];
    const user_record_t *w = saved_user_find(saved_users, saved_user_count, u->uuid);
    if (!w) continue;
    if (w->last_seen > u->last_seen) u->last_seen = w->last_seen;
    u->act_pending = w->act_pending;
    u->last_auth_reply = w->last_auth_reply;
  }
  for (int i = 0; i < state->mask_record_count; i++) {
    mask_record_t *m = &state->mask_records[i];
    const mask_record_t *w = saved_mask_find(saved_masks, saved_mask_count,
                                             m->uuid, m->mask);
    if (!w) continue;
    if (w->last_used > m->last_used) m->last_used = w->last_used;
    m->act_pending = w->act_pending;
  }

  /* Only what differs from before the replace is an update. */
  updates += user_table_changes(state, saved_users, saved_user_count);
  updates += mask_table_changes(state, saved_masks, saved_mask_count);
  updates += access_table_changes(state, saved_uflags, saved_uflag_count,
                                  saved_uchans, saved_uchan_count);

  if (updates > 0) {
    log_message(L_INFO, state, "[HUB] Applied %d config updates from hub\n",
                updates);
    /* Save locally only — do NOT push back to hub. Hub is authoritative for
     * a|/o|/m| records; echoing them back would create an infinite sync loop. */
    config_write_local_with_state_pass(state);
  } else {
    log_message(L_DEBUG, state, "[HUB-SYNC] No updates applied (all timestamps older or equal)\n");
  }
  /* static: the config it held (keys, hashes) would outlive the call */
  secure_wipe(work_buf, work_len + 1);
}

/* ---- Channel-request election (CMD_CHAN_PROBE / CMD_CHAN_DO) ----------- */

/* NULL when we could do `kind` in `channel` right now, else why not.  Only
 * our own state: in the channel and opped (op/invite/unban/mode/kick/ban), or in it and
 * holding its key (key). */
static const char *chan_elect_cannot(bot_state_t *state, const char *kind,
                                     const char *channel) {
  chan_t *c = channel_find(state, channel);
  if (!c || c->status != C_IN) return "not in channel";
  if (strcmp(kind, "key") == 0) return c->key[0] ? NULL : "no key";
  if (strcmp(kind, "op") == 0 || strcmp(kind, "invite") == 0 ||
      strcmp(kind, "unban") == 0 || strcmp(kind, "mode") == 0 ||
      strcmp(kind, "kick") == 0 || strcmp(kind, "ban") == 0)
    return c->i_am_opped ? NULL : "not opped";
  return "unknown request";
}

/* RFC 2812 nick characters, any length a network allows up to
 * CHAN_DO_NICK_MAX: the nick goes straight into a MODE / INVITE line. */
static bool chan_do_nick_ok(const char *n) {
  size_t len = strlen(n);
  if (len == 0 || len > CHAN_DO_NICK_MAX || isdigit((unsigned char)n[0]) || n[0] == '-')
    return false;
  for (size_t i = 0; i < len; i++) {
    unsigned char ch = (unsigned char)n[i];
    if (!isalnum(ch) && !strchr("[]\\`_^{}|-", ch)) return false;
  }
  return true;
}

static void chan_done_send(bot_state_t *state, const char *id, bool ok,
                           const char *detail) {
  char out[192];
  int n = snprintf(out, sizeof(out), "%s|%s|%s", id, ok ? "ok" : "fail", detail);
  if (n > 0 && n < (int)sizeof(out)) hub_send_frame(state, CMD_CHAN_DONE, out, n);
}

/* We were picked: eid|kind|channel|requester|nick|hostmask.  Re-check (the
 * channel may have changed since the probe), act once, report. */
static void chan_elect_do(bot_state_t *state, const char *payload) {
  char id[64] = "", kind[16] = "", chan[MAX_CHAN] = "", req[64] = "";
  char nick[CHAN_DO_NICK_MAX + 2] = "", mask[MAX_MASK_LEN] = "";
  int n = sscanf(payload, "%63[^|]|%15[^|]|%64[^|]|%63[^|]|%31[^|]|%255[^|\r\n]",
                 id, kind, chan, req, nick, mask);
  /* A `mode` job carries no requester / nick: eid|mode|channel is enough. */
  if (n < 3 || (n < 4 && strcmp(kind, "mode") != 0)) {
    log_message(L_INFO, state, "[CHANREQ] Malformed CHAN_DO\n");
    return;
  }
  const char *why = chan_elect_cannot(state, kind, chan);
  if (why) {
    chan_done_send(state, id, false, why);
    return;
  }
  if (strcmp(kind, "op") == 0 || strcmp(kind, "invite") == 0) {
    if (!chan_do_nick_ok(nick)) {
      chan_done_send(state, id, false, "not a valid nick");
      return;
    }
  }
  if (strcmp(kind, "mode") == 0) {
    /* `channel mode`: move the live modes to the stored C| modes + c| key,
     * once.  The MODE lines go through the send queue (packed, paced). */
    chan_t *mc = channel_find(state, chan);
    char note[64];
    if (!mc || chanmode_apply_stored(state, mc, note, sizeof(note)) < 0) {
      chan_done_send(state, id, false, mc ? note : "not in channel");
      return;
    }
    log_message(L_INFO, state, "[CHANREQ] Applied stored modes in %s: %s\n",
                chan, note);
    chan_done_send(state, id, true, state->current_nick);
    return;
  }
  if (strcmp(kind, "kick") == 0 || strcmp(kind, "ban") == 0) {
    /* an admin's channel kick (nick, the reason in the hostmask slot) or
     * ban (the mask in the hostmask slot): sent now, not dealt */
    char detail[96];
    bool ok = strcmp(kind, "kick") == 0
                  ? chanenf_admin_kick(state, chan, nick, mask, detail, sizeof(detail))
                  : mask[0] && chanenf_admin_ban(state, chan, mask, detail, sizeof(detail));
    if (!ok && strcmp(kind, "ban") == 0 && !mask[0]) snprintf(detail, sizeof(detail), "no mask");
    chan_done_send(state, id, ok, detail);
    return;
  }
  if (strcmp(kind, "op") == 0) {
    /* +bitch (D12): only an authorised member may hold ops.  The hub knows
     * the users but not the nick's hostmask -- this bot does.  A nick we
     * cannot find is not vouched for either (fail closed). */
    chan_t *bc = channel_find(state, chan);
    if (bc && chancfg_get(state, bc, CS_BITCH)) {
      bool found = false;
      bool auth = chan_member_authorised(state, bc, nick, &found);
      if (!found || !auth) {
        log_message(L_INFO, state,
                    "[CHANREQ] Not opping %s in %s: +bitch and %s\n", nick,
                    chan, found ? "not authorised" : "not in my roster");
        chan_done_send(state, id, false, "bitch");
        return;
      }
    }
    log_message(L_INFO, state, "[CHANREQ] Opping %s in %s (picked by the hub)\n",
                nick, chan);
    irc_printf(state, "MODE %s +o %s\r\n", chan, nick);
    chan_done_send(state, id, true, "MODE +o sent");
    return;
  }
  chan_req_kind_t k = chan_req_kind_from_token(kind);
  if (k >= CHAN_REQ_KIND_COUNT) {
    chan_done_send(state, id, false, "unknown request");
    return;
  }
  if (k == CHAN_REQ_UNBAN && mask[0] == '\0') {
    chan_done_send(state, id, false, "no hostmask to match");
    return;
  }
  chan_access_service(state, id, k, chan, req, nick, mask, NULL);
  chan_done_send(state, id, true,
                 k == CHAN_REQ_INVITE  ? "INVITE sent"
                 : k == CHAN_REQ_UNBAN ? "ban list check started"
                                       : "key sent");
}

/* ---- A person's channel request (irchub user_flags plan §5) ------------- */

/* Ask the hub to op / invite / unban a person this bot could not serve
 * itself.  false = no hub link (the caller asks its trusted bots directly). */
bool hub_client_send_user_chan_request(bot_state_t *state, const char *kind, const char *chan,
                                       const char *user_uuid, const char *nick,
                                       const char *mask) {
  if (!state->hub_connected || !state->hub_authenticated || state->hub_fd == -1)
    return false;
  unsigned char rnd[8];
  if (RAND_bytes(rnd, sizeof(rnd)) != 1) return false;
  char rid[USER_CHAN_RID_MAX + 1];
  for (size_t i = 0; i < sizeof(rnd); i++) snprintf(rid + 2 * i, 3, "%02x", rnd[i]);
  char payload[MAX_BUFFER];
  int n = snprintf(payload, sizeof(payload), "%s|%s|%s|%s|%s|%s", rid, kind, chan, user_uuid,
                   nick, mask);
  if (n <= 0 || n >= (int)sizeof(payload)) return false;
  /* the oldest slot goes if all are taken */
  user_chan_pending_t *slot = &state->user_chan_pending[0];
  for (int i = 0; i < USER_CHAN_PENDING; i++) {
    user_chan_pending_t *p = &state->user_chan_pending[i];
    if (!p->rid[0]) { slot = p; break; }
    if (p->sent < slot->sent) slot = p;
  }
  if (!hub_send_frame(state, CMD_USER_CHAN_REQUEST, payload, n)) return false;
  memset(slot, 0, sizeof(*slot));
  snprintf(slot->rid, sizeof(slot->rid), "%s", rid);
  snprintf(slot->kind, sizeof(slot->kind), "%s", kind);
  snprintf(slot->chan, sizeof(slot->chan), "%s", chan);
  snprintf(slot->nick, sizeof(slot->nick), "%s", nick);
  snprintf(slot->mask, sizeof(slot->mask), "%s", mask);
  slot->sent = time(NULL);
  log_message(L_INFO, state, "[CHANREQ] Asked the hub to %s %s on %s (rid %s)\n", kind, nick,
              chan, rid);
  return true;
}

/* CMD_USER_CHAN_RESULT: rid|ok|detail or rid|fail|detail -> tell the person. */
static void user_chan_result(bot_state_t *state, const char *payload) {
  char rid[USER_CHAN_RID_MAX + 1] = "", status[8] = "", detail[200] = "";
  if (!payload || sscanf(payload, "%32[^|]|%7[^|]|%199[^\r\n]", rid, status, detail) < 2) return;
  for (int i = 0; i < USER_CHAN_PENDING; i++) {
    user_chan_pending_t *p = &state->user_chan_pending[i];
    if (!p->rid[0] || strcmp(p->rid, rid) != 0) continue;
    bool ok = strcmp(status, "ok") == 0;
    /* the detail is the hub's text: no control bytes reach IRC */
    for (char *c = detail; *c; c++)
      if ((unsigned char)*c < 0x20 || *c == 0x7f) *c = ' ';
    irc_printf(state, "PRIVMSG %s :%s %s: %s%s%s%s\r\n", p->nick, p->kind, p->chan,
               ok ? "done" : "not done", detail[0] ? (ok ? " (" : " - ") : "", detail,
               detail[0] && ok ? ")" : "");
    log_message(L_INFO, state, "[CHANREQ] %s %s on %s: %s %s\n", p->kind, p->nick, p->chan,
                status, detail);
    memset(p, 0, sizeof(*p));
    return;
  }
}

/* Requests the hub never answered (the link dropped, or the elected bot
 * never reported): ask the trusted bots directly instead, once. */
void hub_client_user_chan_tick(bot_state_t *state) {
  time_t now = time(NULL);
  for (int i = 0; i < USER_CHAN_PENDING; i++) {
    user_chan_pending_t *p = &state->user_chan_pending[i];
    if (!p->rid[0] || now - p->sent < USER_CHAN_REPLY_WAIT) continue;
    log_message(L_INFO, state, "[CHANREQ] No answer from the hub for %s %s on %s; asking "
                               "the bots directly\n", p->kind, p->nick, p->chan);
    bot_comms_user_chan_fallback(state, p->kind, p->chan, p->nick, p->mask);
    memset(p, 0, sizeof(*p));
  }
}

static void hub_handle_response(bot_state_t *state, int cmd, char *payload,
                                int payload_len) {
  switch (cmd) {
  case CMD_USER_CHAN_RESULT:
    if (payload && payload_len > 0) {
      payload[payload_len] = '\0';
      user_chan_result(state, payload);
    }
    break;

  case CMD_PING:
    if (!HIDEPINGPONG)
      log_message(L_DEBUG, state, "[HUB] Received PING from hub\n");
    break;

  case CMD_BOT_TREE:
    hub_client_process_tree(state, payload, payload_len);
    break;

  case CMD_BOT_TREE_DELTA:
    hub_client_process_tree_delta(state, payload, payload_len);
    break;

  case CMD_UPGRADE_STAGE:
    hub_client_handle_upgrade_stage(state, payload);
    break;

  case CMD_CRON_SET:
    updater_cron_set(payload_len == 2 && memcmp(payload, "on", 2) == 0);
    break;

  case CMD_ACTIVITY_REPLY:
    if (payload && payload_len > 0) {
      payload[payload_len] = '\0';
      commands_activity_reply(state, payload);
    }
    break;

  case CMD_CONFIG_PULL:
    log_message(L_INFO, state, "[HUB] Hub requested config sync\n");
    break;

  case CMD_CONFIG_DATA:
    log_message(L_INFO, state, "[HUB] Received config from hub (%d bytes)\n",
                payload_len);
    if (payload && payload_len > 0) {
      hub_client_process_config_data(state, payload);
    }
    break;

  case CMD_UPDATE_PUBKEY:
    // Existing handler for hub-to-hub key updates (not used for bots)
    break;

  case CMD_BOT_KEY_UPDATE:
    /* v3: independent per-bot keys.  The bot's private key must never
     * arrive over the wire — reject any inbound "here's your new priv"
     * attempt from the hub.  Rekey is bot-local (see admin command 'rekey'). */
    log_message(L_INFO, state,
                "[HUB] Rejected CMD_BOT_KEY_UPDATE: per-bot independent keys; "
                "private keys do not cross the wire.\n");
    (void)payload; (void)payload_len;
    break;

  case CMD_OP_GRANT: {
    // Payload: requester_hostmask|channel
    // Example: bot3!~ident@47.217.20.145|#ircbot
    char hostmask[MAX_MASK_LEN];
    char channel[MAX_CHAN];

    if (sscanf(payload, "%255[^|]|%64s", hostmask, channel) == 2) {
      /* Nick from the hostmask (nick!user@host).  One that does not fit is
       * refused: cut to the buffer it named someone else, who got the +o. */
      char nick[MAX_MEMBER_NICK];
      char *bang = strchr(hostmask, '!');
      size_t nick_len = bang ? (size_t)(bang - hostmask) : strlen(hostmask);
      if (nick_len == 0 || nick_len >= sizeof(nick)) {
        log_message(L_INFO, state, "[HUB] OP_GRANT nick does not fit — ignored\n");
        break;
      }
      memcpy(nick, hostmask, nick_len);
      nick[nick_len] = '\0';

      // Check if we're in that channel and have ops
      chan_t *c = channel_find(state, channel);
      if (c && c->status == C_IN) {
        if (op_grant_bitch_refuses(state, c, nick)) {
          /* logged; not held either */
        } else if (c->i_am_opped) {
          log_message(L_INFO, state,
                      "[HUB] Granting ops to %s in %s (hub request)\n", nick,
                      channel);
          irc_printf(state, "MODE %s +o %s\r\n", channel, nick);
        } else {
          /* Asked before our own +o arrived: hold it for that +o. */
          time_t now = time(NULL);
          int k = 0;
          for (int i = 0; i < c->op_grant_held_count; i++)
            if (now - c->op_grant_held[i].at <= OP_GRANT_HOLD_SECS &&
                strcasecmp(c->op_grant_held[i].nick, nick) != 0)
              c->op_grant_held[k++] = c->op_grant_held[i];
          c->op_grant_held_count = k;
          if (k < OP_GRANT_HOLD_MAX) {
            snprintf(c->op_grant_held[k].nick, sizeof(c->op_grant_held[k].nick), "%s", nick);
            c->op_grant_held[k].at = now;
            c->op_grant_held_count++;
            log_message(L_INFO, state,
                        "[HUB] Not opped in %s yet; holding the op for %s "
                        "until I am\n",
                        channel, nick);
          } else {
            log_message(L_INFO, state,
                        "[HUB] Cannot grant ops to %s in %s - I'm not opped\n",
                        nick, channel);
          }
        }
      } else {
        log_message(L_INFO, state,
                    "[HUB] Cannot grant ops - not in channel %s\n", channel);
      }
    } else {
      log_message(L_INFO, state, "[HUB] Invalid OP_GRANT payload\n");
    }
  } break;

  case CMD_OP_FAILED:
    log_message(L_INFO, state, "[HUB] Op request failed: %s\n", payload);
    // Clear pending immediately so channel_manager retries in ~30 seconds
    for (chan_t *c = state->chanlist; c != NULL; c = c->next) {
      if (c->op_request_pending) {
        c->op_request_pending = false;
        c->last_op_request_time = time(NULL) - 30;
      }
    }
    break;

  case CMD_CHAN_ACTION:
    /* id|kind|channel|requester_uuid|nick|hostmask — another bot is locked
     * out of a channel and the hub is asking whoever can help.  Every field
     * past the kind was filled in by the hub from its own records. */
    if (payload && payload_len > 0) {
      char a_id[64], a_kind[16], a_chan[MAX_CHAN], a_uuid[64];
      char a_nick[MAX_MEMBER_NICK] = "", a_mask[MAX_MASK_LEN] = "";
      int n = sscanf(payload, "%63[^|]|%15[^|]|%64[^|]|%63[^|]|%31[^|]|%255[^|]",
                     a_id, a_kind, a_chan, a_uuid, a_nick, a_mask);
      /* a nick that does not fit is refused, never cut to someone else's */
      if (n >= 5 && !wire_field(payload, 4, a_nick, sizeof(a_nick))) n = 0;
      if (n >= 4) {
        chan_req_kind_t k = chan_req_kind_from_token(a_kind);
        if (k < CHAN_REQ_KIND_COUNT)
          chan_access_service(state, a_id, k, a_chan, a_uuid, a_nick, a_mask,
                              NULL);
        else
          log_message(L_DEBUG, state,
                      "[DEBUG] [CHANREQ] Unknown action kind '%s'\n", a_kind);
      } else {
        log_message(L_INFO, state, "[CHANREQ] Malformed CHAN_ACTION\n");
      }
    }
    break;

  case CMD_CHAN_PROBE:
    /* eid|kind|channel — could we do this right now?  Answered at once from
     * our own channel state; the hub hands the action to one bot that said
     * yes, so a bot that cannot must say no rather than stay quiet. */
    if (payload && payload_len > 0) {
      char p_id[64], p_kind[16], p_chan[MAX_CHAN];
      if (sscanf(payload, "%63[^|]|%15[^|]|%64[^|\r\n]", p_id, p_kind, p_chan) == 3) {
        const char *why = chan_elect_cannot(state, p_kind, p_chan);
        char ack[160];
        int n = snprintf(ack, sizeof(ack), "%s|%d|%s", p_id, why ? 0 : 1,
                         why ? why : "");
        if (n > 0 && n < (int)sizeof(ack))
          hub_send_frame(state, CMD_CHAN_PROBE_ACK, ack, n);
      }
    }
    break;

  case CMD_CHAN_DO:
    /* eid|kind|channel|requester|nick|hostmask — we were picked. */
    if (payload && payload_len > 0)
      chan_elect_do(state, payload);
    break;

  case CMD_CHAN_REPLY:
    /* id|kind|channel|status|data — the answer to something we asked for. */
    if (payload && payload_len > 0) {
      char r_id[64], r_kind[16], r_chan[MAX_CHAN], r_status[16];
      if (sscanf(payload, "%63[^|]|%15[^|]|%64[^|]|%15[^|]", r_id, r_kind,
                 r_chan, r_status) == 4) {
        /* The data field is whatever follows the 4th '|', never re-split: a
         * channel key may legitimately contain one. */
        const char *data = "";
        int bars = 0;
        for (const char *p = payload; *p; p++)
          if (*p == '|' && ++bars == 4) {
            data = p + 1;
            break;
          }
        if (chan_req_kind_from_token(r_kind) == CHAN_REQ_KEY &&
            strcmp(r_status, "ok") == 0)
          chan_access_accept_key(state, r_chan, data);
        else
          log_message(L_DEBUG, state,
                      "[DEBUG] [CHANREQ] Reply %s for %s: %s\n", r_kind, r_chan,
                      r_status);
      }
    }
    break;

  case CMD_BOT_MSG:
    if (payload && payload_len > 0) {
      log_message(L_DEBUG, state,
                  "[BOT-COMM] Received relayed bot command via hub (%d bytes)\n",
                  payload_len);
      bot_comms_process_payload(state, payload);
    }
    break;

  case CMD_UPGRADE_PREPARE:
    if (payload && payload_len > 0) hub_client_handle_upgrade_prepare(state, payload);
    break;

  case CMD_UPGRADE_COMMIT:
    if (payload && payload_len > 0) hub_client_handle_upgrade_commit(state, payload);
    break;

  case CMD_UPGRADE_ABORT:
    if (payload && payload_len > 0) hub_client_handle_upgrade_abort(state, payload);
    break;
  }
}

void hub_client_connect(bot_state_t *state) {
  if (state->hub_fd != -1 && !state->hub_connected && g_dial_ai) {
    if (time(NULL) - g_dial_started > HUB_DIAL_TIMEOUT) hub_dial_failed(state);
    return;
  }
  if (state->hub_count == 0 || state->hub_fd != -1 || state->hub_connecting)
    return;
  // Safety: Ensure hub_count is positive before rand() % state->hub_count
  if (state->hub_count <= 0)
    return;
  if (state->bot_uuid[0] == '\0') {
    log_message(L_INFO, state,
                "[HUB] Cannot connect: UUID not set (it is generated at bot "
                "creation — re-run 'ircbot -setup').\n");
    state->last_hub_connect_attempt =
        time(NULL) + 3600; // Don't retry for 1 hour
    return;
  }

  // Validate UUID format (36 chars, dashes in right places)
  if (strlen(state->bot_uuid) != 36 || state->bot_uuid[8] != '-' ||
      state->bot_uuid[13] != '-' || state->bot_uuid[18] != '-' ||
      state->bot_uuid[23] != '-') {
    log_message(L_INFO, state,
                "[HUB] Cannot connect: Invalid UUID format (%s). Re-run "
                "'ircbot -setup' to regenerate identity.\n",
                state->bot_uuid);
    state->last_hub_connect_attempt = time(NULL) + 3600;
    return;
  }

  // Check 2: Bot's own keypair must be present and the right length
  if (state->hub_key[0] == '\0') {
    log_message(
        L_INFO, state,
        "[HUB] Cannot connect: bot keypair not set (generated at creation — "
        "re-run 'ircbot -setup').\n");
    state->last_hub_connect_attempt = time(NULL) + 3600;
    return;
  }

  // Curve25519 combined key is exactly 88 chars base64
  size_t key_len = strlen(state->hub_key);
  if (key_len != COMBINED_KEY_B64) {
    log_message(L_INFO, state,
                "[HUB] Cannot connect: bot key length wrong (%zu chars, need "
                "%d). Re-run 'ircbot -setup' to regenerate identity.\n",
                key_len, COMBINED_KEY_B64);
    state->last_hub_connect_attempt = time(NULL) + 3600;
    return;
  }

  // Check 3: Hub list must have at least one entry
  if (state->hubs[0].addr[0] == '\0') {
    log_message(
        L_INFO, state,
        "[HUB] Cannot connect: No hubs configured. Use '+hub <host:port> "
        "<pubkey>'.\n");
    state->last_hub_connect_attempt = time(NULL) + 3600;
    return;
  }
  time_t now = time(NULL);
  if (now - state->last_hub_connect_attempt < HUB_RECONNECT_DELAY)
    return;
  static volatile int lock = 0;
  if (__sync_lock_test_and_set(&lock, 1))
    return;
  state->last_hub_connect_attempt = now;
  state->hub_connecting = true;
  char hub_tmp[256];
  char hub_original[256]; // Save original hub string for later
  int hub_idx = rand() % state->hub_count;
  snprintf(hub_tmp, sizeof(hub_tmp), "%s", state->hubs[hub_idx].addr);
  snprintf(hub_original, sizeof(hub_original), "%s", hub_tmp);

  /* Load this hub's pinned pubkey so the handshake-verification code (which
   * reads hub_remote_ed_pub) authenticates against the right per-hub key.
   * If the selected hub has no pinned key we refuse: the bot must be able to
   * verify the hub's signature. */
  if (state->hubs[hub_idx].ed_pub_set) {
    memcpy(state->hub_remote_ed_pub, state->hubs[hub_idx].ed_pub, 32);
    state->hub_remote_ed_pub_set = true;
  } else {
    state->hub_remote_ed_pub_set = false;
    log_message(L_INFO, state,
                "[HUB] Cannot connect to %s: no pinned pubkey. Re-add with "
                "'+hub %s <pubkey>'.\n", hub_tmp, hub_tmp);
    state->hub_connecting = false;
    __sync_lock_release(&lock);
    state->last_hub_connect_attempt = time(NULL) + 60;
    return;
  }
  char *p = strrchr(hub_tmp, ':');
  if (!p) {
    log_message(L_INFO, state, "[HUB] Invalid hub address (missing port): %s\n",
                hub_tmp);
    state->hub_connecting = false;
    __sync_lock_release(&lock);
    return;
  }
  *p = '\0';
  const char *host = hub_tmp;
  const char *port_str = p + 1;

  /* Accept either a literal IP (v4/v6) or a DNS name here: getaddrinfo()
   * handles both, so there's no need to special-case inet_pton() first. */
  struct addrinfo hints, *res = NULL;
  memset(&hints, 0, sizeof(hints));
  hints.ai_family = AF_UNSPEC;
  hints.ai_socktype = SOCK_STREAM;

  int gai_err = getaddrinfo(host, port_str, &hints, &res);
  if (gai_err != 0) {
    log_message(L_INFO, state, "[HUB] Cannot resolve hub address '%s': %s\n",
                host, gai_strerror(gai_err));
    state->hub_connecting = false;
    __sync_lock_release(&lock);
    return;
  }

  snprintf(g_dial_hub, sizeof(g_dial_hub), "%s", hub_original);
  hub_dial_free();
  g_dial_res = g_dial_ai = res;
  hub_dial_next(state);
  __sync_lock_release(&lock);
}

/* The dial is up: back to a blocking socket (the frame writes stay whole,
 * the reads are MSG_DONTWAIT) and the handshake begins. */
static void hub_dial_up(bot_state_t *state, int sockfd) {
  fcntl(sockfd, F_SETFL, g_dial_flags);
  hub_dial_free();

  state->hub_fd = sockfd;
  state->hub_connected = true;
  state->hub_authenticated = false;
  auth_state = HUB_AUTH_NONE;
  snprintf(state->current_hub, sizeof(state->current_hub), "%s", g_dial_hub);

  int uuid_len = (int)strlen(state->bot_uuid);
  uint32_t net_len = htonl((uint32_t)uuid_len);
  unsigned char uuid_frame[4 + 36];
  memcpy(uuid_frame, &net_len, 4);
  memcpy(uuid_frame + 4, state->bot_uuid, (size_t)uuid_len);
  if (send(state->hub_fd, uuid_frame, (size_t)(4 + uuid_len), 0) == 4 + uuid_len) {
    auth_state = HUB_AUTH_SENT_UUID;
    log_message(L_INFO, state, "[HUB] Connected to %s.\n", state->current_hub);
  } else {
    hub_client_disconnect(state);
  }
  state->hub_connecting = false;
}

static void hub_handle_frame(bot_state_t *state, unsigned char *packet_body,
                             int packet_len);

void hub_client_process(bot_state_t *state) {
  if (state->hub_count == 0 || state->hub_fd == -1 || !state->hub_connected)
    return;
  if (!g_hub_rx && !(g_hub_rx = malloc(HUB_RX_CAP))) {
    hub_client_disconnect(state);
    return;
  }
  while (g_hub_rx_len < HUB_RX_CAP) {
    ssize_t n = recv(state->hub_fd, g_hub_rx + g_hub_rx_len, HUB_RX_CAP - g_hub_rx_len,
                     MSG_DONTWAIT);
    if (n > 0) {
      g_hub_rx_len += (size_t)n;
      continue;
    }
    if (n < 0 && errno == EINTR) continue;
    if (n < 0 && IO_WOULD_BLOCK(errno)) break;
    hub_client_disconnect(state);
    return;
  }
  unsigned gen = g_hub_rx_gen;
  size_t off = 0;
  while (g_hub_rx_len - off >= 4) {
    uint32_t net_len;
    memcpy(&net_len, g_hub_rx + off, 4);
    uint32_t wire_len = ntohl(net_len);
    /* Change 5: a CMD_CONFIG_DATA frame from the hub can exceed MAX_BUFFER at
     * scale — bound by the config-frame ceiling instead of the small wire size. */
    if (wire_len == 0 || wire_len > MAX_HUB_FRAME) {
      hub_client_disconnect(state);
      return;
    }
    if (g_hub_rx_len - off - 4 < wire_len) break; /* the rest is still coming */
    unsigned char *packet_body = malloc(wire_len);
    if (!packet_body) {
      hub_client_disconnect(state);
      return;
    }
    memcpy(packet_body, g_hub_rx + off + 4, wire_len);
    off += 4 + wire_len;
    hub_handle_frame(state, packet_body, (int)wire_len); /* frees packet_body */
    if (gen != g_hub_rx_gen) return; /* the link dropped or was redialled */
  }
  if (off > 0) {
    memmove(g_hub_rx, g_hub_rx + off, g_hub_rx_len - off);
    g_hub_rx_len -= off;
    secure_wipe(g_hub_rx + g_hub_rx_len, off);
  }
}

static void hub_handle_frame(bot_state_t *state, unsigned char *packet_body,
                             int packet_len) {
  if (!state->hub_authenticated) {
    if (auth_state == HUB_AUTH_SENT_UUID) {
      /* v2 layout: challenge(32) || hub_eph_pub(32) || hub_sig(64)    (128 bytes)
       *
       * hub_sig = Ed25519_sign(hub_ed_priv,
       *   "irchub-hub-auth-v2|" || bot_uuid || "|" || challenge || eph_pub).
       * Verified against state->hub_remote_ed_pub (required — bot refuses to
       * connect if not set; see hub_client_connect precondition). */
      if (packet_len != 128) {
        log_message(L_INFO, state,
                    "[HUB] Expected 128-byte v2 challenge, got %d bytes\n",
                    packet_len);
        free(packet_body);
        hub_client_disconnect(state);
        return;
      }
      const unsigned char *challenge   = packet_body;
      const unsigned char *hub_eph_pub = packet_body + 32;

      if (state->hub_remote_ed_pub_set) {
        /* Verify the hub's signature before deriving the session key. */
        const unsigned char *hub_sig = packet_body + 64;

        size_t uuid_len = strlen(state->bot_uuid);
        size_t tlen = strlen("irchub-hub-auth-v2|") + uuid_len + 1 + 32 + 32;
        unsigned char *transcript = malloc(tlen);
        if (!transcript) {
          free(packet_body);
          hub_client_disconnect(state);
          return;
        }
        size_t off = 0;
        memcpy(transcript + off, "irchub-hub-auth-v2|", 19); off += 19;
        memcpy(transcript + off, state->bot_uuid, uuid_len); off += uuid_len;
        transcript[off++] = '|';
        memcpy(transcript + off, challenge, 32);   off += 32;
        memcpy(transcript + off, hub_eph_pub, 32); off += 32;

        EVP_PKEY *pk = EVP_PKEY_new_raw_public_key(
            EVP_PKEY_ED25519, NULL, state->hub_remote_ed_pub, 32);
        EVP_MD_CTX *md = pk ? EVP_MD_CTX_new() : NULL;
        bool sig_ok = false;
        if (md && EVP_DigestVerifyInit(md, NULL, NULL, NULL, pk) == 1 &&
            EVP_DigestVerify(md, hub_sig, 64, transcript, off) == 1) {
          sig_ok = true;
        }
        if (md) EVP_MD_CTX_free(md);
        if (pk) EVP_PKEY_free(pk);
        memset(transcript, 0, off);
        free(transcript);

        if (!sig_ok) {
          log_message(L_INFO, state,
                      "[HUB] v2 hub signature INVALID — possible MITM. "
                      "Disconnecting.\n");
          free(packet_body);
          hub_client_disconnect(state);
          return;
        }
        log_message(L_INFO, state, "[HUB] v2 hub signature verified.\n");
      } else {
        /* hub_remote_ed_pub_set is false — no pinned key for this hub.
         * (The connect path normally refuses earlier; this is defensive.)
         * Re-add the hub with its pubkey: '+hub <host:port> <pubkey>'. */
        log_message(L_INFO, state,
                    "[HUB] ERROR: hub pubkey not pinned. "
                    "Re-add with '+hub <host:port> <pubkey>' before "
                    "connecting.\n");
        free(packet_body);
        hub_client_disconnect(state);
        return;
      }

      // Derive session key from X25519 + HKDF before signing
      unsigned char session_key[32];
      if (!x25519_derive_session_key(state, hub_eph_pub, challenge, session_key)) {
        log_message(L_INFO, state, "[HUB] Failed to derive session key\n");
        free(packet_body);
        hub_client_disconnect(state);
        return;
      }
      memcpy(state->hub_session_key, session_key, 32);
      secure_wipe(session_key, 32);

      // Sign the domain-separated challenge with Ed25519
      unsigned char sig[64];
      if (!ed25519_sign_challenge(state, challenge, hub_eph_pub, sig)) {
        log_message(L_INFO, state, "[HUB] Failed to sign challenge\n");
        free(packet_body);
        hub_client_disconnect(state);
        return;
      }

      // Send 64-byte signature, length-framed
      unsigned char sig_frame[4 + 64];
      uint32_t sig_net_len = htonl(64);
      memcpy(sig_frame, &sig_net_len, 4);
      memcpy(sig_frame + 4, sig, 64);
      if (send(state->hub_fd, sig_frame, 4 + 64, 0) == 4 + 64) {
        auth_state = HUB_AUTH_SENT_SIGNATURE;
        log_message(L_INFO, state, "[HUB] Ed25519 signature sent.\n");
      } else {
        log_message(L_INFO, state, "[HUB] Failed to send signature\n");
        free(packet_body);
        hub_client_disconnect(state);
        return;
      }
    } else if (auth_state == HUB_AUTH_SENT_SIGNATURE) {
      /* The ACK is exactly one sealed byte; it decrypts into ack_pt[8], so a
       * longer frame is refused before decryption, never written past it. */
      if (packet_len == GCM_IV_LEN + 1 + GCM_TAG_LEN) {
        unsigned char ack_tag[GCM_TAG_LEN];
        unsigned char ack_pt[8] = {0};
        memcpy(ack_tag, packet_body + packet_len - GCM_TAG_LEN, GCM_TAG_LEN);
        int ack_pl = crypto_aes_gcm_decrypt(
            packet_body, packet_len - GCM_TAG_LEN,
            state->hub_session_key, ack_pt, ack_tag);
        if (ack_pl == 1 && ack_pt[0] == CMD_BOT_RETIRE) {
          /* Revoked: the hub proved itself (signed challenge, sealed ACK). */
          free(packet_body);
          hub_client_retire(state);
          return;
        }
        if (ack_pl == 1 && ack_pt[0] == 0x01) {
          state->hub_authenticated = true;
          auth_state = HUB_AUTH_COMPLETE;
          state->last_hub_activity = time(NULL);
          state->hub_connect_time = time(NULL);
          /* Phase 4: a new hub link — bump the persisted link-order counter
           * before the first presence carries it. */
          hub_client_link_ord_bump(state);
          log_message(L_INFO, state, "[HUB] Authenticated (Curve25519 v2)!\n");
          /* Review 6: first frame on the link; a 2.5.1 hub ignores it. */
          hub_seal_frame(state, CMD_LINK_SEQ, "offer", 5);
          hub_client_push_config(state);
          /* This hub has no presence for us yet, so report unconditionally
           * rather than waiting for the heartbeat's change check. */
          hub_client_send_presence(state, true);
          /* If this process is the product of a hub-driven upgrade, close
           * that run out now that there is a hub to tell. */
          hub_client_report_upgrade_result(state);
          /* Activity reports held while the hub was unreachable. */
          hub_client_send_activity(state);
          if (state->admin_delta_pending) {
            /* After the config push (so the hub already knows our v|).  LWW
             * on the hub: only records changed here since carry a newer
             * timestamp and win; the rest are no-ops. */
            log_message(L_INFO, state, "[HUB] Pushing user/mask changes made "
                                       "while the hub was unreachable\n");
            hub_client_push_admin_delta(state);
          }
        } else {
          log_message(L_INFO, state,
                      "[HUB] v2 ACK decrypt/parse failed (len=%d)\n", ack_pl);
          free(packet_body);
          hub_client_disconnect(state);
          return;
        }
      } else {
        log_message(L_INFO, state, "[HUB] Bad ACK from hub (len=%d)\n", packet_len);
        free(packet_body);
        hub_client_disconnect(state);
        return;
      }
    }
    free(packet_body);
    return;
  }
  state->last_hub_activity = time(NULL);
  /* Change 5: decrypt scratch sized to the largest inbound hub frame.  static
   * (not stack) — the bot is single-threaded and this path is non-reentrant, so
   * a ~200 KB frame needs no oversized stack allocation. */
  static unsigned char plain[MAX_HUB_FRAME];
  unsigned char tag[GCM_TAG_LEN];
  if (packet_len > (GCM_IV_LEN + GCM_TAG_LEN)) {
    memcpy(tag, packet_body + packet_len - GCM_TAG_LEN, GCM_TAG_LEN);
    /* Review 6: on a sequenced link the frame must be the next one. */
    unsigned char aad[HUB_LINK_AAD_LEN];
    bool seq = state->hub_link_rx_seq;
    if (seq) link_aad('H', state->hub_link_rx_ctr, aad);
    int plain_len = crypto_aes_gcm_decrypt_aad(
        packet_body, packet_len - GCM_TAG_LEN, seq ? aad : NULL,
        seq ? HUB_LINK_AAD_LEN : 0, state->hub_session_key, plain, tag);
    if (plain_len <= 0) {
      /* Not a frame of this session in this place: fail secure. */
      log_message(L_INFO, state, "[HUB] Frame from hub failed its tag%s: disconnecting\n",
                  seq ? " (replayed, reordered or forged)" : "");
      free(packet_body);
      hub_client_disconnect(state);
      return;
    }
    if (seq) state->hub_link_rx_ctr++;
    if (plain_len > 0) {
      unsigned char cmd = plain[0];

      if (cmd == CMD_LINK_SEQ) {
        /* The hub's "offer" is answered with our "go" (our frames after it
         * are sequenced); its "go" sequences every frame it sends after. */
        if (plain_len >= 5 + 5 && memcmp(plain + 5, "offer", 5) == 0 &&
            !state->hub_link_offered) {
          state->hub_link_offered = true;
          hub_seal_frame(state, CMD_LINK_SEQ, "go", 2);
        } else if (plain_len >= 5 + 2 && memcmp(plain + 5, "go", 2) == 0 &&
                   state->hub_link_offered && !state->hub_link_rx_seq) {
          state->hub_link_rx_seq = true;
          state->hub_link_rx_ctr = 0;
          log_message(L_DEBUG, state, "[HUB] Sequenced link framing on\n");
        }
        secure_wipe(plain, (size_t)plain_len);
        free(packet_body);
        return;
      } else if (cmd == CMD_BOT_RETIRE) {
        /* Empty payload: handled before the payload dispatch below. */
        free(packet_body);
        hub_client_retire(state);
        return;
      } else if (cmd == CMD_PING) {
        /* A hub keepalive may carry "t|<fnv64hex>", the tree we should hold:
         * the check that replaced the periodic whole-tree push. */
        if (plain_len > 5) {
          uint32_t pl_net;
          memcpy(&pl_net, &plain[1], 4);
          int pl = (int)ntohl(pl_net);
          if (pl > 0 && pl <= plain_len - 5 && pl < 64) {
            char tp[64];
            memcpy(tp, &plain[5], (size_t)pl);
            tp[pl] = '\0';
            hub_client_check_tree_hash(state, tp);
          }
        }
        // RATE LIMIT: Only respond to ping once per 5 seconds
        time_t now = time(NULL);
        if (now - last_pong_sent >= 5) {
          if (!hub_seal_frame(state, CMD_PING, NULL, 0)) {
            free(packet_body);
            return;
          }
          last_pong_sent = now;
        }
      } else {
        // Extract payload from plain[5...] and call handler
        if (plain_len > 5) {
          uint32_t payload_len_network;
          memcpy(&payload_len_network, &plain[1], 4);
          int payload_len = (int)ntohl(payload_len_network);

          if (payload_len > 0 && payload_len <= (plain_len - 5)) {
            /* Change 5: static, sized to the largest inbound frame (see plain
             * above). payload_len <= plain_len-5 <= MAX_HUB_FRAME-5. */
            static char payload_buf[MAX_HUB_FRAME];
            memcpy(payload_buf, &plain[5], (size_t)payload_len);
            payload_buf[payload_len] = '\0';

            hub_handle_response(state, cmd, payload_buf, payload_len);
            /* both static: wipe what this frame put there (review
             * 2026-10-25 L1) */
            secure_wipe(payload_buf, (size_t)payload_len + 1);
          }
        }
        secure_wipe(plain, (size_t)plain_len);
      }
    } else {
      free(packet_body);
      hub_client_disconnect(state);
      return;
    }
  }
  free(packet_body);
}
