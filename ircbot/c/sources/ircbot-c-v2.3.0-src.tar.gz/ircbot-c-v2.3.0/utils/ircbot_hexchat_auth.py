"""ircbot_hexchat_auth.py — v1 (~A1) admin-command client for ircbot, HexChat edition.

Wire format (must match commands.c exactly):
    PRIVMSG <bot> :~A1 <base64( salt[16] || iv[12] || ciphertext || tag[16] )>
    plaintext = "<unix_ts>:<nonce>:<command> [args...]"
    key       = PBKDF2-HMAC-SHA256(password, salt, 100000, 32)
    cipher    = AES-256-GCM, no AAD
Bot-side constraints: |now - ts| <= 30s, nonce unseen for 60s, and the sender's
hostmask must match an active admin/oper record.

Dependency:  pip install cryptography      (or: apt install python3-cryptography)

The crypto runs in-process: the password and derived key never reach a command
line, an environment variable, or a temp file.  Do not "simplify" this by
shelling out to `openssl enc -K <hex>` — argv is world-readable via ps(1).

Install:
    cp ircbot_hexchat_auth.py ~/.config/hexchat/addons/

Setup (either one), then reload the script:
    /BOTCMD passfile /home/you/.ircbot_admin_pass      (preferred, chmod 600)
    /BOTCMD password <your_admin_password>             (stored in hexchat prefs)

Usage:
    /BOTCMD <bot_nick> <command> [args...]
"""

import base64
import os
import stat
import time

import hexchat
# Imported defensively so a missing dependency shows one actionable line in the
# client instead of an ImportError traceback at load time.
try:
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    CRYPTO_OK = True
except ImportError:
    CRYPTO_OK = False

CRYPTO_HINT = ("bot_auth: the 'cryptography' module is not installed — this "
               "script cannot encrypt without it.  Install one of:  "
               "sudo apt install python3-cryptography  |  pip install cryptography")

__module_name__ = "ircbot_hexchat_auth"
__module_version__ = "5.0.0"
__module_description__ = "Sends ~A1 admin commands to ircbot (AES-256-GCM)"

PBKDF2_ITERATIONS = 100000
SALT_SIZE = 16
GCM_IV_LEN = 12
IRC_LINE_LIMIT = 512


def build_v1_payload(password, command_line):
    """Return the base64 ~A1 blob for one admin command."""
    salt = os.urandom(SALT_SIZE)
    iv = os.urandom(GCM_IV_LEN)

    key = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt,
                     iterations=PBKDF2_ITERATIONS).derive(
                         password.encode("utf-8"))

    # Positive decimal integer parsed bot-side with strtoull(); 62 bits keeps
    # it well inside an unsigned 64-bit value.
    nonce = int.from_bytes(os.urandom(8), "big") >> 2

    plaintext = "%d:%d:%s" % (int(time.time()), nonce, command_line)
    # AESGCM.encrypt returns ciphertext || tag, which is the layout the bot
    # expects after salt || iv.
    ct_and_tag = AESGCM(key).encrypt(iv, plaintext.encode("utf-8"), None)
    return base64.b64encode(salt + iv + ct_and_tag).decode("ascii")


def load_password():
    """(password, None) or (None, error).  Passfile wins over the stored pref."""
    path = hexchat.get_pluginpref("bot_auth_passfile")
    if path:
        try:
            st = os.stat(path)
        except OSError as exc:
            return None, "passfile '%s' is unreadable (%s)" % (path, exc)
        if not stat.S_ISREG(st.st_mode):
            return None, "passfile '%s' must be a regular file" % path
        if st.st_uid != os.getuid():
            return None, "passfile '%s' must be owned by you" % path
        if st.st_mode & 0o077:
            return None, ("passfile '%s' is mode %04o — chmod 600 it"
                          % (path, st.st_mode & 0o7777))
        try:
            with open(path, "r", encoding="utf-8") as handle:
                pw = handle.readline().rstrip("\r\n")
        except OSError as exc:
            return None, "cannot read passfile: %s" % exc
        if not pw:
            return None, "passfile '%s' is empty" % path
        return pw, None

    pw = hexchat.get_pluginpref("bot_auth_password")
    if not pw:
        return None, ("no password set — /BOTCMD passfile <file> (preferred) "
                      "or /BOTCMD password <pass>")
    return pw, None


def botcmd_cb(word, word_eol, userdata):
    if not CRYPTO_OK:
        hexchat.prnt(CRYPTO_HINT)
        return hexchat.EAT_ALL

    if len(word) < 3:
        hexchat.prnt("Usage: /BOTCMD <bot_nick> <command> [args...]")
        hexchat.prnt("       /BOTCMD passfile <path>   |   /BOTCMD password <pass>")
        return hexchat.EAT_ALL

    # Configuration subcommands.
    if word[1] == "passfile":
        hexchat.set_pluginpref("bot_auth_passfile", word_eol[2])
        hexchat.prnt("bot_auth: passfile set to %s" % word_eol[2])
        return hexchat.EAT_ALL
    if word[1] == "password":
        hexchat.set_pluginpref("bot_auth_password", word_eol[2])
        hexchat.prnt("bot_auth: password stored in hexchat prefs "
                     "(a chmod-600 passfile is preferable)")
        return hexchat.EAT_ALL

    bot_nick, command_line = word[1], word_eol[2]

    password, err = load_password()
    if err:
        hexchat.prnt("bot_auth: %s" % err)
        return hexchat.EAT_ALL

    try:
        b64 = build_v1_payload(password, command_line)
    except Exception as exc:                      # noqa: BLE001 - report to user
        hexchat.prnt("bot_auth: failed to build payload: %s" % exc)
        return hexchat.EAT_ALL

    # The server re-broadcasts our PRIVMSG prefixed with ":nick!user@host " and
    # the 512-byte limit counts that prefix plus CR-LF.  A blob clipped by the
    # server reaches the bot as a GCM tag failure — indistinguishable from a
    # wrong password — so refuse locally instead.
    line = "PRIVMSG %s :~A1 %s" % (bot_nick, b64)
    host = hexchat.get_info("host") or ""
    nick = hexchat.get_info("nick") or ""
    prefix = len(":%s!%s " % (nick, host)) if host else 100
    if prefix + len(line) + 2 > IRC_LINE_LIMIT:
        hexchat.prnt("bot_auth: '%s' is too long — the ~A1 blob would be "
                     "truncated on the wire (%d > %d bytes). Shorten the command."
                     % (command_line, prefix + len(line) + 2, IRC_LINE_LIMIT))
        return hexchat.EAT_ALL

    hexchat.command("QUOTE %s" % line)
    hexchat.prnt("bot_auth: sent (~A1) '%s' to %s." % (command_line, bot_nick))
    return hexchat.EAT_ALL


hexchat.hook_command("BOTCMD", botcmd_cb,
                     help="/BOTCMD <bot_nick> <command> [args...]")
hexchat.prnt("%s %s loaded (~A1 / AES-256-GCM)."
             % (__module_name__, __module_version__))
if not CRYPTO_OK:
    hexchat.prnt(CRYPTO_HINT)
    hexchat.prnt("/BOTCMD stays registered but will refuse to send until then.")
