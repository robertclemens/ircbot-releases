#include <ctype.h>
#include <math.h>
#include <openssl/bio.h>
#include <openssl/buffer.h>
#include <openssl/hmac.h>
#include <openssl/rand.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <time.h>
#include <unistd.h>

#include "bot.h"

/* Render an elapsed span as "0d 16h 31m 55s" for the status readout. */
static void status_fmt_elapsed(char *buf, size_t len, time_t since) {
  long d = (long)(time(NULL) - since);
  if (since <= 0 || d < 0) d = 0;
  snprintf(buf, len, "%ldd %ldh %ldm %lds", d / 86400, (d % 86400) / 3600,
           (d % 3600) / 60, d % 60);
}

/* CMD-log redaction.  `secret` flags the argument positions that carry a
 * password; those are logged as REDACT_MASK, never as typed.
 * This is an allowlist: a verb missing from the table is logged without its
 * name or arguments, because a mistyped command can put a password in any
 * position.  A new command belongs here, with its secret arguments flagged. */
#define REDACT_ARG1 1u
#define REDACT_ARG2 2u
#define REDACT_ARG3 4u
#define REDACT_MASK "********"

typedef struct {
  const char *name;
  unsigned secret;
} cmd_log_rule_t;

static const cmd_log_rule_t LOGGABLE_CMDS[] = {
  {"botpass", REDACT_ARG1}, /* botpass <password> */
  {"+admin",  REDACT_ARG2}, /* +admin <name> <password> <mask> */
  {"+oper",   REDACT_ARG2}, /* +oper <name> <password> <mask> */
  {"chpass",  REDACT_ARG2}, /* chpass <name> <newpassword> */
  {"die", 0},      {"jump", 0},     {"join", 0},      {"part", 0},
  {"op", 0},       {"invite", 0},   {"+bot", 0},      {"-bot", 0},
  {"status", 0},   {"givenick", 0}, {"chnick", 0},    {"saveconf", 0},
  {"setlog", 0},   {"getlog", 0},   {"admins", 0},    {"opers", 0},
  {"match", 0},    {"-admin", 0},   {"-oper", 0},     {"+usermask", 0},
  {"-usermask", 0}, {"+server", 0}, {"-server", 0},   {"update", 0},
  {"+hub", 0},     {"-hub", 0},     {"rekey", 0},     {"help", 0},
  {NULL, 0}
};

/* Append src to dst (current length *len, capacity cap), stopping at the cap.
 * No escaping here: log_message neutralizes control bytes in every line. */
static void cmd_log_append(char *dst, size_t cap, size_t *len,
                           const char *src) {
  for (; *src != '\0' && *len + 1 < cap; src++)
    dst[(*len)++] = *src;
  dst[*len] = '\0';
}

/* Log an authenticated admin/oper command to L_CMD as
 *   [CMD_ADMIN] <account> (<nick!user@host>): <command> <args>
 * with each secret argument replaced by REDACT_MASK.  The dispatcher reads
 * only arg1..arg3 and drops the rest of the line, so nothing past arg3 is
 * logged either. */
static void log_user_command(bot_state_t *state, const char *tag,
                             const user_record_t *who, const char *user_host,
                             const char *command, const char *arg1,
                             const char *arg2, const char *arg3) {
  const cmd_log_rule_t *rule = NULL;
  for (int i = 0; LOGGABLE_CMDS[i].name; i++) {
    if (strcasecmp(command, LOGGABLE_CMDS[i].name) == 0) {
      rule = &LOGGABLE_CMDS[i];
      break;
    }
  }

  char line[MAX_LOG_LINE_LEN];
  size_t len = 0;
  line[0] = '\0';
  cmd_log_append(line, sizeof(line), &len, who ? who->name : "?");
  cmd_log_append(line, sizeof(line), &len, " (");
  cmd_log_append(line, sizeof(line), &len, user_host);
  cmd_log_append(line, sizeof(line), &len, "): ");

  if (!rule) {
    cmd_log_append(line, sizeof(line), &len,
                   "unrecognized command (not logged)");
  } else {
    cmd_log_append(line, sizeof(line), &len, rule->name);
    const char *args[3] = {arg1, arg2, arg3};
    for (int i = 0; i < 3 && args[i]; i++) {
      cmd_log_append(line, sizeof(line), &len, " ");
      cmd_log_append(line, sizeof(line), &len,
                     (rule->secret & (1u << i)) ? REDACT_MASK : args[i]);
    }
  }
  log_message(L_CMD, state, "[%s] %s\n", tag, line);
}

static void dispatch_user_command(bot_state_t *state, const char *nick,
                                  user_record_t *auth_user, bool is_admin,
                                  bool is_op, char *command, char *arg1,
                                  char *arg2, char *arg3);

void commands_handle_private_message(bot_state_t *state, const char *nick,
                                     const char *user, const char *host,
                                     const char *dest, char *message) {
  if (strcasecmp(dest, state->current_nick) != 0)
    return;

  char user_host[256];
  snprintf(user_host, sizeof(user_host), "%s!%s@%s", nick, user, host);

  log_message(L_MSG, state, "[MSG] (%s): %s\n", user_host, message);

  /* --- Block 1: Trusted Bot Logic (Encrypted Communication) --- */

  char sender_bot_uuid[64];
  if (auth_is_trusted_bot(state, user_host, sender_bot_uuid,
                          sizeof(sender_bot_uuid))) {
    char message_copy_bot[MAX_BUFFER];
    snprintf(message_copy_bot, sizeof(message_copy_bot), "%s", message);

    char *saveptr_enc;
    char *encoded_ciphertext = strtok_r(message_copy_bot, ":", &saveptr_enc);
    char *encoded_tag = strtok_r(NULL, "", &saveptr_enc);

    if (encoded_ciphertext && encoded_tag) {
      unsigned char *decoded_data = NULL;
      unsigned char *tag = NULL;
      int decoded_len = 0;
      int tag_len = 0;

      decoded_data = base64_decode(encoded_ciphertext, &decoded_len);
      tag = base64_decode(encoded_tag, &tag_len);

      if (decoded_data && tag && decoded_len > (SALT_SIZE + GCM_IV_LEN) &&
          tag_len == GCM_TAG_LEN) {
        unsigned char salt[SALT_SIZE];
        memcpy(salt, decoded_data, SALT_SIZE);

        unsigned char key[32];
        if (!crypto_derive_config_key(state->bot_comm_pass, salt, key)) {
          if (decoded_data) free(decoded_data);
          if (tag) free(tag);
          return;
        }

        unsigned char *ciphertext_ptr = decoded_data + SALT_SIZE;
        int ciphertext_len = decoded_len - SALT_SIZE;

        unsigned char *decrypted_data = malloc(ciphertext_len + 1);
        if (decrypted_data) {
          /* Sender always binds its own UUID as GCM AAD (bot_comms.c
           * bot_comms_send_command); mirror that here with the UUID we
           * just resolved from trusted_bots[], or the tag never verifies. */
          int decrypted_len = crypto_aes_gcm_decrypt_aad(
              ciphertext_ptr, ciphertext_len,
              (const unsigned char *)sender_bot_uuid,
              (int)strlen(sender_bot_uuid),
              key, decrypted_data, tag);

          if (decrypted_len >= 0 &&
              has_control_bytes(decrypted_data, (size_t)decrypted_len)) {
            log_message(L_CMD, state,
                        "[BOT-COMMS] Control character in command from %s; "
                        "dropped\n", user_host);
          } else if (decrypted_len >= 0) {
            decrypted_data[decrypted_len] = '\0';

            char *saveptr_bot;
            char *received_timestamp_str =
                strtok_r((char *)decrypted_data, ":", &saveptr_bot);
            char *received_nonce_str = strtok_r(NULL, ":", &saveptr_bot);
            char *command_part = strtok_r(NULL, "", &saveptr_bot);

            if (received_timestamp_str && received_nonce_str && command_part) {
              time_t received_time = atoll(received_timestamp_str);
              uint64_t received_nonce = strtoull(received_nonce_str, NULL, 10);

              if (fabs(difftime(time(NULL), received_time)) <= 60) {
                bool nonce_is_reused = false;
                { time_t _now = time(NULL);
                  for (int i = 0; i < NONCE_CACHE_SIZE; i++) {
                    if (state->recent_nonces[i].nonce == received_nonce &&
                        _now - state->recent_nonces[i].ts <= NONCE_TTL_SECONDS)
                      { nonce_is_reused = true; break; }
                  }
                }
                if (!nonce_is_reused) {
                  state->recent_nonces[state->nonce_idx] = (nonce_entry_t){ received_nonce, time(NULL) };
                  state->nonce_idx = (state->nonce_idx + 1) % NONCE_CACHE_SIZE;

                  char *saveptr_cmd;
                  char *bot_command = strtok_r(command_part, " ", &saveptr_cmd);
                  char *bot_arg1 = strtok_r(NULL, " ", &saveptr_cmd);
                  if (bot_command && strcasecmp(bot_command, "OPME") == 0 &&
                      bot_arg1) {
                    irc_printf(state, "MODE %s +o %s\r\n", bot_arg1, nick);
                  } else if (bot_command &&
                             strcasecmp(bot_command, "SETNICK") == 0 &&
                             bot_arg1) {
                    if (is_valid_bot_nick(bot_arg1)) {
                      snprintf(state->target_nick, MAX_NICK, "%s", bot_arg1);
                      state->current_nick_ts = time(NULL);
                      hub_client_push_delta(state, "n", bot_arg1,
                                            state->current_nick_ts);
                      config_write_with_state_pass(state);
                    }
                  } else if (bot_command &&
                             strcasecmp(bot_command, "INVITE") == 0 &&
                             bot_arg1) {
                    char *bot_arg2 = strtok_r(NULL, " ", &saveptr_cmd);
                    if (bot_arg2) {
                      chan_t *ic = channel_find(state, bot_arg1);
                      if (ic && ic->status == C_IN && ic->i_am_opped) {
                        log_message(L_INFO, state,
                                    "[BOT-COMMS] Inviting %s to %s (bot req)\n",
                                    bot_arg2, bot_arg1);
                        irc_printf(state, "INVITE %s %s\r\n",
                                   bot_arg2, bot_arg1);
                      }
                    }
                  }
                }
              }
            }
          }
          secure_wipe(decrypted_data, (size_t)ciphertext_len + 1);
          free(decrypted_data);
        }
        secure_wipe(key, sizeof(key));
      }

      if (decoded_data)
        free(decoded_data);
      if (tag)
        free(tag);
    }
  }
  /* --- Block 2: Admin/Op Logic --- */
  /* Two accepted formats:
   *   v1   (default):      "~A1 <base64-blob>"
   *     blob = salt(16) || iv(12) || ciphertext(N) || tag(16)
   *     key  = PBKDF2-HMAC-SHA256(admin_password, salt, PBKDF2_ITERATIONS, 32)
   *     cipher = AES-256-GCM
   *
   *   v1c  (openssl-CLI friendly): "~A1c <base64-blob>"
   *     blob = salt(16) || iv(16) || ciphertext(N) || hmac(32)
   *     keys = PBKDF2-HMAC-SHA256(admin_password, salt, PBKDF2_ITERATIONS, 64)
   *     enc_key = keys[0..31], mac_key = keys[32..63]
   *     cipher = AES-256-CBC (PKCS#7 padded)
   *     hmac   = HMAC-SHA256(mac_key, salt || iv || ciphertext)
   *     Verification is encrypt-then-MAC: HMAC verified BEFORE decrypt.
   *     Exists so clients with no AES-GCM support (mIRC's $encode,
   *     OpenSSL's `enc` CLI, pure-Perl with Digest::SHA + openssl CLI)
   *     can still produce a valid frame.
   *
   * The pre-PBKDF2 "<nonce>:<hash> <command>" scheme was removed in
   * 0292ddb; anything without a ~A1/~A1c prefix is now unauthenticated and
   * falls straight through to the "Auth failed" path below.  Clients still
   * shipping it (the irssi script before v3.0.0, now utils/ircbot_irssi_auth.pl)
   * must be upgraded, not re-supported.
   *
   * Plaintext under both v1 and v1c is "<timestamp>:<nonce>:<command> [args]".
   * Both formats populate the same dispatch variables and fall through to
   * the existing command tree below. */

  char v1_plaintext[MAX_BUFFER];     /* v1 decrypted-payload working buffer */
  bool used_v1 = false;
  bool is_admin = false;
  bool is_op = false;
  user_record_t *auth_user = NULL;
  char *command = NULL, *arg1 = NULL, *arg2 = NULL, *arg3 = NULL;
  uint64_t nonce_val = 0;

  if (strncmp(message, "~A1c ", 5) == 0) {
    /* ---- v1c: AES-256-CBC + HMAC-SHA256 encrypt-then-MAC admin command ----
     * Exists for clients that can't produce AES-GCM (mIRC, openssl(1) CLI).
     * Security is equivalent to v1 — both achieve AEAD over the same key
     * derivation and the same nonce / timestamp envelope. */
    used_v1 = true;
    const char *b64 = message + 5;
    int blob_len = 0;
    unsigned char *blob = base64_decode(b64, &blob_len);
    const int min_len = SALT_SIZE + 16 + 16 + 32;  /* salt + iv + 1 AES block + hmac */
    if (!blob || blob_len < min_len) {
      if (blob) { secure_wipe(blob, (size_t)(blob_len > 0 ? blob_len : 0)); free(blob); }
      log_message(L_CMD, state,
                  "[CMD] v1c auth: malformed blob from %s\n", user_host);
      return;
    }
    int ct_len = blob_len - SALT_SIZE - 16 - 32;
    if (ct_len <= 0 || (ct_len % 16) != 0) {
      log_message(L_CMD, state,
                  "[CMD] v1c auth: ct_len %d not a multiple of 16\n", ct_len);
      secure_wipe(blob, (size_t)blob_len);
      free(blob);
      return;
    }

    unsigned char salt_v1c[SALT_SIZE], iv_v1c[16], hmac_v1c[32];
    memcpy(salt_v1c, blob,                                       SALT_SIZE);
    memcpy(iv_v1c,   blob + SALT_SIZE,                           16);
    memcpy(hmac_v1c, blob + blob_len - 32,                       32);

    time_t now_auth = time(NULL);
    user_record_t *candidate = auth_find_user(state, user_host, now_auth);
    if (!candidate || !candidate->is_active || candidate->password[0] == '\0') {
      log_message(L_CMD, state,
                  "[CMD] v1c auth: no matching active user for %s\n", user_host);
      secure_wipe(blob, (size_t)blob_len);
      free(blob);
      return;
    }

    /* Derive 64 bytes: enc_key(32) || mac_key(32) */
    unsigned char keys[64];
    if (PKCS5_PBKDF2_HMAC(candidate->password, (int)strlen(candidate->password),
                          salt_v1c, SALT_SIZE, PBKDF2_ITERATIONS,
                          EVP_sha256(), 64, keys) != 1) {
      log_message(L_CMD, state, "[CMD] v1c auth: PBKDF2 failed\n");
      secure_wipe(blob, (size_t)blob_len);
      free(blob);
      return;
    }

    /* Verify HMAC over salt || iv || ciphertext BEFORE decrypting. */
    unsigned int hmac_calc_len = 0;
    unsigned char hmac_calc[32];
    /* The first (blob_len - 32) bytes of `blob` are exactly salt||iv||ct. */
    if (!HMAC(EVP_sha256(), keys + 32, 32,
              blob, (size_t)(blob_len - 32),
              hmac_calc, &hmac_calc_len) ||
        hmac_calc_len != 32 ||
        CRYPTO_memcmp(hmac_calc, hmac_v1c, 32) != 0) {
      log_message(L_CMD, state,
                  "[CMD] v1c auth: HMAC FAILED for %s (wrong password?)\n",
                  user_host);
      secure_wipe(keys, sizeof(keys));
      secure_wipe(blob, (size_t)blob_len);
      free(blob);
      return;
    }

    /* HMAC ok — AES-CBC decrypt the ciphertext. */
    unsigned char *plain = malloc((size_t)ct_len + 1);
    if (!plain) {
      secure_wipe(keys, sizeof(keys));
      secure_wipe(blob, (size_t)blob_len);
      free(blob);
      return;
    }
    EVP_CIPHER_CTX *cctx = EVP_CIPHER_CTX_new();
    int plain_len = 0, final_len = 0;
    if (!cctx ||
        EVP_DecryptInit_ex(cctx, EVP_aes_256_cbc(), NULL, keys, iv_v1c) != 1 ||
        EVP_DecryptUpdate(cctx, plain, &plain_len,
                          blob + SALT_SIZE + 16, ct_len) != 1 ||
        EVP_DecryptFinal_ex(cctx, plain + plain_len, &final_len) != 1) {
      log_message(L_CMD, state, "[CMD] v1c auth: AES-CBC decrypt failed\n");
      if (cctx) EVP_CIPHER_CTX_free(cctx);
      secure_wipe(keys, sizeof(keys));
      secure_wipe(plain, (size_t)ct_len + 1);
      free(plain);
      secure_wipe(blob, (size_t)blob_len);
      free(blob);
      return;
    }
    EVP_CIPHER_CTX_free(cctx);
    plain_len += final_len;
    plain[plain_len] = '\0';
    secure_wipe(keys, sizeof(keys));
    secure_wipe(blob, (size_t)blob_len);
    free(blob);

    if ((size_t)plain_len >= sizeof(v1_plaintext)) {
      secure_wipe(plain, (size_t)plain_len);
      free(plain);
      return;
    }
    memcpy(v1_plaintext, plain, (size_t)plain_len);
    v1_plaintext[plain_len] = '\0';
    secure_wipe(plain, (size_t)plain_len);
    free(plain);

    /* Reject, don't repair: a CR/LF in an argument would reach irc_printf
     * and split into a second IRC command. */
    if (has_control_bytes(v1_plaintext, (size_t)plain_len)) {
      log_message(L_CMD, state,
                  "[CMD] v1c auth: control character in command from %s; "
                  "dropped\n", user_host);
      secure_wipe(v1_plaintext, sizeof(v1_plaintext));
      return;
    }

    /* Parse: <timestamp>:<nonce>:<command> [args] — same envelope as v1. */
    char *sp_v1c;
    char *ts_str    = strtok_r(v1_plaintext, ":", &sp_v1c);
    char *nonce_str = strtok_r(NULL,         ":", &sp_v1c);
    char *cmd_line  = strtok_r(NULL,         "",  &sp_v1c);
    if (!ts_str || !nonce_str || !cmd_line) {
      log_message(L_CMD, state, "[CMD] v1c auth: malformed plaintext\n");
      secure_wipe(v1_plaintext, sizeof(v1_plaintext));
      return;
    }
    time_t client_ts = (time_t)strtoll(ts_str, NULL, 10);
    if (llabs((long long)(now_auth - client_ts)) > 30) {
      log_message(L_CMD, state,
                  "[CMD] v1c auth: timestamp skew %lds (max 30) from %s\n",
                  (long)(now_auth - client_ts), user_host);
      secure_wipe(v1_plaintext, sizeof(v1_plaintext));
      return;
    }
    nonce_val = strtoull(nonce_str, NULL, 10);
    bool replay_v1c = false;
    { time_t _now = time(NULL);
      for (int _ri = 0; _ri < MAX_SEEN_HASHES; _ri++) {
        if (state->admin_nonces[_ri].nonce == nonce_val &&
            _now - state->admin_nonces[_ri].ts <= NONCE_TTL_SECONDS)
          { replay_v1c = true; break; }
      }
    }
    if (replay_v1c) {
      log_message(L_CMD, state,
                  "[CMD] v1c auth: replay (nonce=%llu) from %s\n",
                  (unsigned long long)nonce_val, user_host);
      secure_wipe(v1_plaintext, sizeof(v1_plaintext));
      return;
    }
    state->admin_nonces[state->admin_nonce_idx] = (nonce_entry_t){ nonce_val, time(NULL) };
    state->admin_nonce_idx = (state->admin_nonce_idx + 1) % MAX_SEEN_HASHES;

    char *sp_cmd;
    command = strtok_r(cmd_line, " ", &sp_cmd);
    arg1    = strtok_r(NULL,     " ", &sp_cmd);
    arg2    = strtok_r(NULL,     " ", &sp_cmd);
    arg3    = strtok_r(NULL,     " ", &sp_cmd);
    if (!command) {
      secure_wipe(v1_plaintext, sizeof(v1_plaintext));
      return;
    }
    auth_user = candidate;
    if (candidate->type == 'a') is_admin = true;
    if (candidate->type == 'o') is_op    = true;

    /* No command text here: log_user_command records it, redacted. */
    log_message(L_DEBUG, state,
                "[CMD_DEBUG] v1c frame verified: User='%s' Type=%c\n",
                candidate->name, candidate->type);
  } else if (strncmp(message, "~A1 ", 4) == 0) {
    /* ---- v1: AES-256-GCM-protected admin command ---- */
    used_v1 = true;
    const char *b64 = message + 4;
    int blob_len = 0;
    unsigned char *blob = base64_decode(b64, &blob_len);
    if (!blob || blob_len < (int)(SALT_SIZE + GCM_IV_LEN + GCM_TAG_LEN)) {
      if (blob) { secure_wipe(blob, (size_t)(blob_len > 0 ? blob_len : 0)); free(blob); }
      log_message(L_CMD, state,
                  "[CMD] v1 auth: malformed blob from %s\n", user_host);
      return;
    }
    int ct_len = blob_len - (int)SALT_SIZE - GCM_IV_LEN - GCM_TAG_LEN;
    if (ct_len <= 0) {
      secure_wipe(blob, (size_t)blob_len);
      free(blob);
      return;
    }

    unsigned char salt[SALT_SIZE], iv[GCM_IV_LEN], tag[GCM_TAG_LEN];
    memcpy(salt, blob, SALT_SIZE);
    memcpy(iv,   blob + SALT_SIZE, GCM_IV_LEN);
    memcpy(tag,  blob + blob_len - GCM_TAG_LEN, GCM_TAG_LEN);

    /* Identify the sender by hostmask BEFORE trusting any payload content.
     * auth_find_user updates last_seen/last_used and sets config_dirty even
     * on the v1 path, so both formats record activity identically.  The flush
     * is debounced and LOCAL (main.c, CONFIG_WRITE_DEBOUNCE_S) -- these
     * timestamps are this bot's own view and are deliberately not pushed to
     * the hub; that would mean mesh traffic per admin command. */
    time_t now_auth = time(NULL);
    user_record_t *candidate = auth_find_user(state, user_host, now_auth);
    if (!candidate || !candidate->is_active || candidate->password[0] == '\0') {
      log_message(L_CMD, state,
                  "[CMD] v1 auth: no matching active user for %s\n", user_host);
      secure_wipe(blob, (size_t)blob_len);
      free(blob);
      return;
    }

    unsigned char key[32];
    if (!crypto_derive_config_key(candidate->password, salt, key)) {
      log_message(L_CMD, state, "[CMD] v1 auth: PBKDF2 failed\n");
      secure_wipe(blob, (size_t)blob_len);
      free(blob);
      return;
    }

    /* crypto_aes_gcm_decrypt expects input = iv || ciphertext, plus tag. */
    int gcm_in_len = GCM_IV_LEN + ct_len;
    unsigned char *gcm_in = malloc((size_t)gcm_in_len);
    if (!gcm_in) {
      secure_wipe(key, sizeof(key));
      secure_wipe(blob, (size_t)blob_len);
      free(blob);
      return;
    }
    memcpy(gcm_in,              iv,                 GCM_IV_LEN);
    memcpy(gcm_in + GCM_IV_LEN, blob + SALT_SIZE + GCM_IV_LEN, (size_t)ct_len);

    unsigned char *plain = malloc((size_t)ct_len + 1);
    if (!plain) {
      secure_wipe(key, sizeof(key));
      secure_wipe(gcm_in, (size_t)gcm_in_len);
      free(gcm_in);
      secure_wipe(blob, (size_t)blob_len);
      free(blob);
      return;
    }
    int plain_len = crypto_aes_gcm_decrypt(gcm_in, gcm_in_len, key, plain, tag);
    secure_wipe(key, sizeof(key));
    secure_wipe(gcm_in, (size_t)gcm_in_len);
    free(gcm_in);
    secure_wipe(blob, (size_t)blob_len);
    free(blob);

    if (plain_len < 0) {
      log_message(L_CMD, state,
                  "[CMD] v1 auth: GCM tag failed for %s (wrong password?)\n",
                  user_host);
      secure_wipe(plain, (size_t)ct_len + 1);
      free(plain);
      return;
    }
    plain[plain_len] = '\0';

    /* Copy decrypted plaintext to v1_plaintext so strtok_r pointers we save
     * remain valid for the dispatch below. */
    if ((size_t)plain_len >= sizeof(v1_plaintext)) {
      secure_wipe(plain, (size_t)plain_len);
      free(plain);
      return;
    }
    memcpy(v1_plaintext, plain, (size_t)plain_len);
    v1_plaintext[plain_len] = '\0';
    secure_wipe(plain, (size_t)plain_len);
    free(plain);

    /* Same framing rule as v1c: control bytes drop the whole command. */
    if (has_control_bytes(v1_plaintext, (size_t)plain_len)) {
      log_message(L_CMD, state,
                  "[CMD] v1 auth: control character in command from %s; "
                  "dropped\n", user_host);
      secure_wipe(v1_plaintext, sizeof(v1_plaintext));
      return;
    }

    /* Parse: timestamp:nonce:command args */
    char *sp_v1;
    char *ts_str    = strtok_r(v1_plaintext, ":", &sp_v1);
    char *nonce_str = strtok_r(NULL,         ":", &sp_v1);
    char *cmd_line  = strtok_r(NULL,         "",  &sp_v1);
    if (!ts_str || !nonce_str || !cmd_line) {
      log_message(L_CMD, state,
                  "[CMD] v1 auth: malformed plaintext (missing fields)\n");
      secure_wipe(v1_plaintext, sizeof(v1_plaintext));
      return;
    }

    /* Freshness window — narrower than legacy because the script doesn't
     * need clock-skew tolerance beyond a few seconds. */
    time_t client_ts = (time_t)strtoll(ts_str, NULL, 10);
    if (llabs((long long)(now_auth - client_ts)) > 30) {
      log_message(L_CMD, state,
                  "[CMD] v1 auth: timestamp skew %lds (max 30) from %s\n",
                  (long)(now_auth - client_ts), user_host);
      secure_wipe(v1_plaintext, sizeof(v1_plaintext));
      return;
    }

    /* Replay check against the shared admin_nonces ring. */
    nonce_val = strtoull(nonce_str, NULL, 10);
    bool replay_v1 = false;
    { time_t _now = time(NULL);
      for (int _ri = 0; _ri < MAX_SEEN_HASHES; _ri++) {
        if (state->admin_nonces[_ri].nonce == nonce_val &&
            _now - state->admin_nonces[_ri].ts <= NONCE_TTL_SECONDS)
          { replay_v1 = true; break; }
      }
    }
    if (replay_v1) {
      log_message(L_CMD, state,
                  "[CMD] v1 auth: replay detected (nonce=%llu) from %s\n",
                  (unsigned long long)nonce_val, user_host);
      secure_wipe(v1_plaintext, sizeof(v1_plaintext));
      return;
    }
    state->admin_nonces[state->admin_nonce_idx] = (nonce_entry_t){ nonce_val, time(NULL) };
    state->admin_nonce_idx = (state->admin_nonce_idx + 1) % MAX_SEEN_HASHES;

    /* Tokenize the command line, in place, the same way the legacy path does. */
    char *sp_cmd;
    command = strtok_r(cmd_line, " ", &sp_cmd);
    arg1    = strtok_r(NULL,     " ", &sp_cmd);
    arg2    = strtok_r(NULL,     " ", &sp_cmd);
    arg3    = strtok_r(NULL,     " ", &sp_cmd);
    if (!command) {
      secure_wipe(v1_plaintext, sizeof(v1_plaintext));
      return;
    }

    auth_user = candidate;
    if (candidate->type == 'a') is_admin = true;
    if (candidate->type == 'o') is_op    = true;

    /* No command text here: log_user_command records it, redacted. */
    log_message(L_DEBUG, state,
                "[CMD_DEBUG] v1 frame verified: User='%s' Type=%c\n",
                candidate->name, candidate->type);
  }

  if (!is_admin && !is_op) {
    log_message(L_CMD, state, "[CMD_DEBUG] Auth failed for %s.\n", user_host);
    if (used_v1) secure_wipe(v1_plaintext, sizeof(v1_plaintext));
    /* Nothing below this point may run for an unauthenticated sender: bail
     * rather than relying on every downstream branch staying guarded.
     * `command` is still NULL here on the no-prefix path. */
    return;
  }

  /* Every value a command stores lands in a '|'-delimited config line and
   * hub record (o|uuid|name|password|add|last_seen|ts), where a '|' shifts
   * the fields after it: `chpass me pw|add|0|<far future>` would plant a
   * timestamp that outranks any later -oper. */
  const char *const toks[] = {command, arg1, arg2, arg3};
  bool has_delim = false;
  for (size_t i = 0; i < sizeof(toks) / sizeof(toks[0]); i++)
    if (toks[i] && strchr(toks[i], '|'))
      has_delim = true;

  if (has_delim) {
    log_message(L_CMD, state, "[CMD] '|' in command from %s (%s); dropped\n",
                auth_user->name, user_host);
    irc_printf(state,
               "PRIVMSG %s :Error: '|' is not allowed in commands.\r\n", nick);
  } else {
    log_user_command(state, is_admin ? "CMD_ADMIN" : "CMD_OP", auth_user,
                     user_host, command, arg1, arg2, arg3);
    dispatch_user_command(state, nick, auth_user, is_admin, is_op, command,
                          arg1, arg2, arg3);
  }
  /* The decrypted command can carry a new password (chpass, +admin, +oper,
   * botpass) and nothing points into it once dispatch has returned. */
  secure_wipe(v1_plaintext, sizeof(v1_plaintext));
}

/* The admin/oper command tree, split out of commands_handle_private_message
 * so the caller wipes the decrypted command after every return path here.
 * command/arg1..arg3 point into the caller's v1_plaintext. */
static void dispatch_user_command(bot_state_t *state, const char *nick,
                                  user_record_t *auth_user, bool is_admin,
                                  bool is_op, char *command, char *arg1,
                                  char *arg2, char *arg3) {
  if (is_admin) {
    /* opt 'h' (OPT_HUB_ONLY_MUTATIONS): when set by the network, the bot
     * refuses local mutation of hub-authoritative records.  These commands
     * must be performed via hub_admin instead.  Help text also hides them. */
    if (is_opt_set(state, OPT_HUB_ONLY_MUTATIONS)) {
      static const char * const HUB_ONLY_CMDS[] = {
        "+admin", "-admin", "+oper", "-oper",
        "+usermask", "-usermask",
        "+bot", "-bot",
        "join", "part",
        "botpass", "chpass",
        /* +hub / -hub are intentionally NOT here: hub membership is a
         * bot-local connection concern (the hub-only-mutation boundary
         * covers mesh-replicated records, not which hubs this bot dials),
         * and with per-hub keypairs adding a hub must work even under
         * opt 'h'. */
        NULL
      };
      for (int i = 0; HUB_ONLY_CMDS[i]; i++) {
        if (strcasecmp(command, HUB_ONLY_CMDS[i]) == 0) {
          irc_printf(state,
                     "PRIVMSG %s :Error: '%s' is disabled — network is in "
                     "hub-only-mutation mode (opt 'h'). Use hub_admin.\r\n",
                     nick, HUB_ONLY_CMDS[i]);
          return;
        }
      }
    }

    if (strcasecmp(command, "die") == 0) {
      irc_printf(state, "QUIT :Sayonara.\r\n");
      state->status |= S_DIE;
    } else if (strcasecmp(command, "jump") == 0) {
      if (arg1) {
        /* Jump to named server: match by hostname only, ignore stored port */
        char arg_host[256];
        snprintf(arg_host, sizeof(arg_host), "%s", arg1);
        char *arg_colon = strrchr(arg_host, ':');
        if (arg_colon) *arg_colon = '\0';
        int target_idx = -1;
        for (int i = 0; i < state->server_count; i++) {
          char srv_host[256];
          snprintf(srv_host, sizeof(srv_host), "%s", state->server_list[i]);
          char *srv_colon = strrchr(srv_host, ':');
          if (srv_colon) *srv_colon = '\0';
          if (strcasecmp(arg_host, srv_host) == 0) { target_idx = i; break; }
        }
        if (target_idx == -1) {
          irc_printf(state, "PRIVMSG %s :Error: Server '%s' not in list.\r\n",
                     nick, arg1);
        } else {
          /* An explicit jump overrides any ban/throttle hold on the target. */
          char held[64];
          irc_server_block_desc(state, target_idx, held, sizeof(held));
          if (held[0])
            log_message(L_INFO, state, "[BAN] %s: hold (%s) cleared by jump.\n",
                        state->server_list[target_idx], held);
          irc_server_block_clear(state, target_idx);
          state->current_server_index = target_idx;
          irc_printf(state, "QUIT :Jumping to %s...\r\n", arg1);
          irc_disconnect(state);
        }
      } else {
        irc_printf(state, "QUIT :Jumping servers...\r\n");
        irc_disconnect(state);
      }
    } else if (strcasecmp(command, "join") == 0) {
      char channel_name[MAX_CHAN];
      if (!arg1) {
        irc_printf(state, "PRIVMSG %s :Syntax: join <#channel>\r\n", nick);
        return;
      }
      if (arg1[0] == '#') {
        snprintf(channel_name, sizeof(channel_name), "%s", arg1);
      } else {
        snprintf(channel_name, sizeof(channel_name), "#%s", arg1);
      }

      chan_t *c = channel_find(state, channel_name);
      if (c && c->is_managed) {
        irc_printf(state,
                   "PRIVMSG %s :Error: Channel %s is already in my list.\r\n",
                   nick, channel_name);
        return;
      }
      if (!c) {
        c = channel_add(state, channel_name);
      }
      if (c) {
        if (arg2)
          snprintf(c->key, MAX_KEY, "%s", arg2);
        c->is_managed = true;      // Mark as managed for syncing
        c->timestamp = time(NULL); // Set timestamp for sync
        log_message(L_DEBUG, state, "[JOIN] Channel %s: re-enabled ts=%ld\n",
                    channel_name, (long)c->timestamp);
      }
      config_write_with_state_pass(state);
      hub_client_push_config(state); // Sync to hub immediately
      irc_printf(state, "PRIVMSG %s :JOIN %s and saving config file.\r\n", nick,
                 arg1);
    } else if (strcasecmp(command, "part") == 0) {
      if (!arg1) {
        irc_printf(state, "PRIVMSG %s :Syntax: part <#channel>\r\n", nick);
        return;
      }
      char channel_name[MAX_CHAN];
      if (arg1[0] == '#') {
        snprintf(channel_name, sizeof(channel_name), "%s", arg1);
      } else {
        snprintf(channel_name, sizeof(channel_name), "#%s", arg1);
      }
      chan_t *c = channel_find(state, channel_name);
      if (c) {
        // Soft delete - mark as unmanaged instead of removing
        c->is_managed = false;
        c->timestamp = time(NULL);
        log_message(L_DEBUG, state, "[PART-OP] Channel %s: soft delete ts=%ld\n",
                    channel_name, (long)c->timestamp);
        irc_printf(state, "PART %s\r\n", channel_name);
        config_write_with_state_pass(state);
      }
    } else if (strcasecmp(command, "op") == 0) {
      if (!arg1) {
        irc_printf(state, "PRIVMSG %s :Syntax: op <#channel>\r\n", nick);
        return;
      }
      irc_printf(state, "MODE %s +o %s\r\n", arg1, nick);
    } else if (strcasecmp(command, "invite") == 0) {
      if (!arg1) {
        irc_printf(state, "PRIVMSG %s :Syntax: invite <#channel>\r\n", nick);
        return;
      }
      char inv_channel[MAX_CHAN];
      if (arg1[0] == '#' || arg1[0] == '&') {
        snprintf(inv_channel, sizeof(inv_channel), "%s", arg1);
      } else {
        snprintf(inv_channel, sizeof(inv_channel), "#%s", arg1);
      }
      chan_t *ic = channel_find(state, inv_channel);
      if (ic && ic->status == C_IN) {
        /* i_am_opped, not our roster entry: the roster isn't re-read while
         * we hold ops, so after a nick change our entry has the old nick. */
        if (ic->i_am_opped) {
          irc_printf(state, "INVITE %s %s\r\n", nick, inv_channel);
          irc_printf(state, "PRIVMSG %s :Inviting you to %s\r\n",
                     nick, inv_channel);
          return;
        }
      }
      /* Escalate: hub or encrypted PRIVMSG to trusted bots */
      if (!hub_client_send_invite_request(state, nick, inv_channel)) {
        for (int i = 0; i < state->trusted_bot_count; i++) {
          char tb_nick[MAX_NICK];
          if (sscanf(state->trusted_bots[i], "%9[^!]", tb_nick) == 1) {
            bot_comms_send_command(state, tb_nick,
                                   "INVITE %s %s", inv_channel, nick);
          }
        }
      }
    } else if (strcasecmp(command, "botpass") == 0) {
      if (!arg1) {
        irc_printf(state, "PRIVMSG %s :Syntax: botpass <password>\r\n", nick);
        return;
      }
      snprintf(state->bot_comm_pass, MAX_PASS, "%s", arg1);
      state->bot_comm_pass_ts = time(NULL);
      config_write_with_state_pass(state);
      irc_printf(state,
                 "PRIVMSG %s :Bot communication password set and saved.\r\n",
                 nick);
    } else if (strcasecmp(command, "+bot") == 0) {
      if (state->hub_count > 0) {
        irc_printf(state,
                   "PRIVMSG %s :Error: Bot management disabled when hub is configured. "
                   "Bot additions/deletions must be performed on the hub.\r\n",
                   nick);
        return;
      }
      if (!arg1) {
        irc_printf(state,
                   "PRIVMSG %s :Syntax: +bot <nick*!*user@hostmask.com>\r\n",
                   nick);
        return;
      }
      for (int i = 0; i < state->trusted_bot_count; i++) {
        if (strcasecmp(state->trusted_bots[i], arg1) == 0) {
          irc_printf(
              state,
              "PRIVMSG %s :Error: Trusted bot mask '%s' already exists.\r\n",
              nick, arg1);
          return;
        }
      }
      if (state->trusted_bot_count < MAX_TRUSTED_BOTS) {
        char *dup = strdup(arg1);
        if (!dup) return;
        state->trusted_bots[state->trusted_bot_count++] = dup;
        state->trusted_bots[state->trusted_bot_count] = NULL;
        config_write_with_state_pass(state);
        irc_printf(state, "PRIVMSG %s :Added trusted bot: %s\r\n", nick, arg1);
      }
    } else if (strcasecmp(command, "-bot") == 0) {
      if (state->hub_count > 0) {
        irc_printf(state,
                   "PRIVMSG %s :Error: Bot management disabled when hub is configured. "
                   "Bot additions/deletions must be performed on the hub.\r\n",
                   nick);
        return;
      }
      if (!arg1) {
        irc_printf(state,
                   "PRIVMSG %s :Syntax: -bot <nick*!*user@hostmask.com>\r\n",
                   nick);
        return;
      }
      int found_index = -1;
      for (int i = 0; i < state->trusted_bot_count; i++) {
        if (strcasecmp(state->trusted_bots[i], arg1) == 0) {
          found_index = i;
          break;
        }
      }
      if (found_index != -1) {
        free(state->trusted_bots[found_index]);
        for (int i = found_index; i < state->trusted_bot_count - 1; i++) {
          state->trusted_bots[i] = state->trusted_bots[i + 1];
        }
        state->trusted_bot_count--;
        state->trusted_bots[state->trusted_bot_count] = NULL;
        config_write_with_state_pass(state);
        irc_printf(state, "PRIVMSG %s :Removed trusted bot: %s\r\n", nick,
                   arg1);
      }
    } else if (strcasecmp(command, "status") == 0) {
#define ST_SEP  "+----------------------------------------------------------------------------"
#define ST_FOOT "`----------------------------------------------------------------------------"
#define ST_LINE "| "
      /* Uptime — bot process lifetime, independent of any connection */
      char uptime_str[64];
      if (state->bot_start_time > 0)
        status_fmt_elapsed(uptime_str, sizeof(uptime_str), state->bot_start_time);
      else
        snprintf(uptime_str, sizeof(uptime_str), "N/A");

      /* Network string — include port after hostname */
      char srv_buf[300] = "N/A";
      if (state->actual_server_name[0] != '\0') {
        int srv_port = 0;
        if (state->current_server_index > 0) {
          const char *sl = state->server_list[state->current_server_index - 1];
          const char *colon = sl ? strrchr(sl, ':') : NULL;
          if (colon) srv_port = atoi(colon + 1);
        }
        if (srv_port > 0)
          snprintf(srv_buf, sizeof(srv_buf), "%s:%d", state->actual_server_name, srv_port);
        else
          snprintf(srv_buf, sizeof(srv_buf), "%s", state->actual_server_name);
      } else if (state->current_server_index > 0 &&
                 state->server_list[state->current_server_index - 1]) {
        snprintf(srv_buf, sizeof(srv_buf), "%s",
                 state->server_list[state->current_server_index - 1]);
      }
      const char *srv = srv_buf;
      /* Connected time on the Network line tracks the IRC link only */
      char conn_buf[80];
      if (state->status & S_CONNECTED) {
        if (state->connection_time > 0) {
          char irc_up_str[64];
          status_fmt_elapsed(irc_up_str, sizeof(irc_up_str), state->connection_time);
          snprintf(conn_buf, sizeof(conn_buf), "CONNECTED %s", irc_up_str);
        } else {
          snprintf(conn_buf, sizeof(conn_buf), "CONNECTED");
        }
      } else {
        snprintf(conn_buf, sizeof(conn_buf), "DISCONNECTED");
      }
      const char *conn_str = conn_buf;

      /* Count active admins and opers */
      int admin_count = 0, oper_count = 0;
      for (int i = 0; i < state->user_record_count; i++) {
        if (!state->user_records[i].is_active) continue;
        if (state->user_records[i].type == 'a') admin_count++;
        else if (state->user_records[i].type == 'o') oper_count++;
      }

      struct timespec st_delay = {0, 80000000}; /* 80ms anti-flood */

      irc_printf(state, "PRIVMSG %s :| ircbot %s status\r\n", nick, BOT_VERSION);
      irc_printf(state, "PRIVMSG %s :%s\r\n", nick, ST_SEP);
      irc_printf(state, "PRIVMSG %s :| Identity : %s (Target: %s) | UUID: %s\r\n",
                 nick, state->current_nick, state->target_nick,
                 state->bot_uuid[0] ? state->bot_uuid : "none");
      irc_printf(state, "PRIVMSG %s :| Uptime   : %s\r\n", nick, uptime_str);
      irc_printf(state, "PRIVMSG %s :| Network  : %s (%s, TLS: %s)\r\n",
                 nick, srv, conn_str, state->is_ssl ? "YES" : "NO");
      nanosleep(&st_delay, NULL);

      /* Servers section — only shown when multiple servers configured */
      if (state->server_count > 1) {
        irc_printf(state, "PRIVMSG %s :+-[ Servers ]---------------------------------------------------------------\r\n", nick);
        char srv_line[600] = ""; int soff = 0;
        for (int i = 0; i < state->server_count; i++) {
          const char *s = state->server_list[i];
          if (!s) continue;
          bool is_cur = (state->current_server_index > 0 &&
                         i == state->current_server_index - 1 &&
                         (state->status & S_CONNECTED));
          char held[64], entry[200];
          irc_server_block_desc(state, i, held, sizeof(held));
          snprintf(entry, sizeof(entry), "%s%s%s%s%s", is_cur ? "*" : " ", s,
                   held[0] ? " (" : "", held, held[0] ? ")" : "");
          int elen = (int)strlen(entry);
          if (soff > 0 && soff + 2 + elen < (int)sizeof(srv_line) - 1) {
            srv_line[soff++] = ','; srv_line[soff++] = ' ';
          }
          if (soff + elen < (int)sizeof(srv_line) - 1) {
            memcpy(srv_line + soff, entry, elen);
            soff += elen; srv_line[soff] = '\0';
          }
        }
        irc_printf(state, "PRIVMSG %s :| %s\r\n", nick, srv_line);
        nanosleep(&st_delay, NULL);
      }

      /* Channels section — collect IN and OUT into comma-wrapped lines */
      irc_printf(state, "PRIVMSG %s :+-[ Channels ]---------------------------------------------------------------\r\n", nick);
      {
        /* Build IN channel list */
        char in_buf[800] = "", out_buf[400] = "";
        int in_off = 0, out_off = 0;
        for (chan_t *c = state->chanlist; c; c = c->next) {
          if (!c->is_managed) continue;
          char entry[128];
          if (c->status == C_IN) {
            snprintf(entry, sizeof(entry), "%s%s",
                     c->i_am_opped ? "@" : "", c->name);
            int elen = (int)strlen(entry);
            if (in_off > 0 && in_off + 2 + elen < (int)sizeof(in_buf) - 1) {
              in_buf[in_off++] = ','; in_buf[in_off++] = ' ';
            }
            if (in_off + elen < (int)sizeof(in_buf) - 1) {
              memcpy(in_buf + in_off, entry, elen);
              in_off += elen; in_buf[in_off] = '\0';
            }
          } else {
            int elen = (int)strlen(c->name);
            if (out_off > 0 && out_off + 2 + elen < (int)sizeof(out_buf) - 1) {
              out_buf[out_off++] = ','; out_buf[out_off++] = ' ';
            }
            if (out_off + elen < (int)sizeof(out_buf) - 1) {
              memcpy(out_buf + out_off, c->name, elen);
              out_off += elen; out_buf[out_off] = '\0';
            }
          }
        }
        /* Word-wrap and send IN line(s): prefix "| (IN)  " = 8 chars, content 68 */
        if (in_buf[0]) {
          const char *pfx1 = "| (IN)  ", *pfx2 = "|        ";
          int cw = 68;
          char *p = in_buf; int first = 1;
          while (*p) {
            char seg[80]; int n = 0;
            while (*p && n < cw) seg[n++] = *p++;
            /* back up to last comma+space if not at end */
            if (*p) {
              int back = n;
              while (back > 0 && !(seg[back-1] == ' ' && back > 1 && seg[back-2] == ','))
                back--;
              if (back > 0) { p -= (n - back); n = back; }
            }
            seg[n] = '\0';
            irc_printf(state, "PRIVMSG %s :%s%s\r\n", nick, first ? pfx1 : pfx2, seg);
            first = 0;
          }
        } else {
          irc_printf(state, "PRIVMSG %s :| (IN)  (none)\r\n", nick);
        }
        if (out_buf[0])
          irc_printf(state, "PRIVMSG %s :| (OUT) %s\r\n", nick, out_buf);
      }
      nanosleep(&st_delay, NULL);

      /* Access Control — counts only */
      irc_printf(state, "PRIVMSG %s :+-[ Access Control ]---------------------------------------------------------\r\n", nick);
      irc_printf(state, "PRIVMSG %s :| Admins : %-4d  Ops: %d\r\n",
                 nick, admin_count, oper_count);
      nanosleep(&st_delay, NULL);

      /* Hub Config or standalone Bots section */
#define HUB_TRUST_MAX 100
#define BOTS_PFX1 "| Bots   : "
#define BOTS_PFX2 "|          "
#define BOTS_CW   66
      if (state->hub_count > 0) {
        /* Hub is configured — show full Hub Config */
        irc_printf(state, "PRIVMSG %s :+-[ Hub Config ]-------------------------------------------------------------\r\n", nick);
        if (state->hub_connected && state->current_hub[0]) {
          if (state->hub_connect_time > 0 && state->hub_authenticated) {
            char hub_up_str[64];
            status_fmt_elapsed(hub_up_str, sizeof(hub_up_str),
                               state->hub_connect_time);
            irc_printf(state, "PRIVMSG %s :| Hub    : %s (CONNECTED %s)\r\n",
                       nick, state->current_hub, hub_up_str);
          } else {
            irc_printf(state, "PRIVMSG %s :| Hub    : %s (CONNECTED)\r\n",
                       nick, state->current_hub);
          }
        } else {
          irc_printf(state, "PRIVMSG %s :| Hub    : DISCONNECTED\r\n", nick);
        }
        /* Configured hubs */
        {
          char hubs_line[300] = ""; int hoff = 0;
          for (int i = 0; i < state->hub_count; i++) {
            int hlen = (int)strlen(state->hubs[i].addr);
            if (hoff) { hubs_line[hoff++] = ','; hubs_line[hoff++] = ' '; }
            if (hoff + hlen < (int)sizeof(hubs_line) - 1) {
              memcpy(hubs_line + hoff, state->hubs[i].addr, hlen);
              hoff += hlen; hubs_line[hoff] = '\0';
            }
          }
          irc_printf(state, "PRIVMSG %s :| Hubs   : %s\r\n", nick, hubs_line);
        }
        /* Bots — word-wrap, truncate after 100 */
        if (state->trusted_bot_count > 0) {
          char trust_line[512] = ""; int toff = 0;
          int first = 1, shown = 0;
          for (int i = 0; i < state->trusted_bot_count && shown < HUB_TRUST_MAX; i++, shown++) {
            char tname[64] = "";
            sscanf(state->trusted_bots[i], "%63[^!]", tname);
            int tlen = (int)strlen(tname);
            int need = toff ? tlen + 2 : tlen;
            if (toff && toff + need > BOTS_CW) {
              irc_printf(state, "PRIVMSG %s :%s%s\r\n", nick, first ? BOTS_PFX1 : BOTS_PFX2, trust_line);
              first = 0; toff = 0; trust_line[0] = '\0';
            }
            if (toff) { trust_line[toff++] = ','; trust_line[toff++] = ' '; }
            memcpy(trust_line + toff, tname, tlen);
            toff += tlen; trust_line[toff] = '\0';
          }
          if (toff)
            irc_printf(state, "PRIVMSG %s :%s%s\r\n", nick, first ? BOTS_PFX1 : BOTS_PFX2, trust_line);
          if (state->trusted_bot_count > HUB_TRUST_MAX)
            irc_printf(state, "PRIVMSG %s :|          ...and %d more\r\n", nick,
                       state->trusted_bot_count - HUB_TRUST_MAX);
        } else {
          irc_printf(state, "PRIVMSG %s :| Bots   : (none)\r\n", nick);
        }
        irc_printf(state, "PRIVMSG %s :%s\r\n", nick, ST_FOOT);
      } else if (state->trusted_bot_count > 0) {
        /* No hub — standalone bot-to-bot mode, show Bots section only */
        irc_printf(state, "PRIVMSG %s :+-[ Bots ]-------------------------------------------------------------------\r\n", nick);
        char trust_line[512] = ""; int toff = 0;
        int first = 1, shown = 0;
        for (int i = 0; i < state->trusted_bot_count && shown < HUB_TRUST_MAX; i++, shown++) {
          char tname[64] = "";
          sscanf(state->trusted_bots[i], "%63[^!]", tname);
          int tlen = (int)strlen(tname);
          int need = toff ? tlen + 2 : tlen;
          if (toff && toff + need > BOTS_CW) {
            irc_printf(state, "PRIVMSG %s :%s%s\r\n", nick, first ? BOTS_PFX1 : BOTS_PFX2, trust_line);
            first = 0; toff = 0; trust_line[0] = '\0';
          }
          if (toff) { trust_line[toff++] = ','; trust_line[toff++] = ' '; }
          memcpy(trust_line + toff, tname, tlen);
          toff += tlen; trust_line[toff] = '\0';
        }
        if (toff)
          irc_printf(state, "PRIVMSG %s :%s%s\r\n", nick, first ? BOTS_PFX1 : BOTS_PFX2, trust_line);
        if (state->trusted_bot_count > HUB_TRUST_MAX)
          irc_printf(state, "PRIVMSG %s :|          ...and %d more\r\n", nick,
                     state->trusted_bot_count - HUB_TRUST_MAX);
        irc_printf(state, "PRIVMSG %s :%s\r\n", nick, ST_FOOT);
      } else {
        /* No hub, no bots — just close the box */
        irc_printf(state, "PRIVMSG %s :%s\r\n", nick, ST_FOOT);
      }
#undef HUB_TRUST_MAX
#undef BOTS_PFX1
#undef BOTS_PFX2
#undef BOTS_CW
#undef ST_SEP
#undef ST_FOOT
#undef ST_LINE
    } else if (strcasecmp(command, "givenick") == 0) {
      irc_printf(state,
                 "PRIVMSG %s :You have about %d seconds to retrieve.\r\n", nick,
                 NICK_TAKE_TIME);
      irc_generate_new_nick(state);
      state->nick_release_time = time(NULL);
    } else if (strcasecmp(command, "chnick") == 0) {
      if (!arg1 || !arg2) {
        irc_printf(state, "PRIVMSG %s :Syntax: chnick <oldnick> <newnick>\r\n", nick);
        return;
      }
      if (!is_valid_bot_nick(arg2)) {
        if (strchr(arg2, '|'))
          irc_printf(state,
              "PRIVMSG %s :Error: New nick cannot contain '|'.\r\n", nick);
        else
          irc_printf(state,
              "PRIVMSG %s :Error: New nick too long (max %d chars).\r\n",
              nick, MAX_NICK - 1);
        return;
      }
      /* Uniqueness check: newnick must not already exist in any type */
      for (int i = 0; i < state->user_record_count; i++) {
        if (state->user_records[i].is_active &&
            strcasecmp(state->user_records[i].name, arg2) == 0) {
          irc_printf(state, "PRIVMSG %s :Error: Name '%s' already in use.\r\n",
                     nick, arg2);
          return;
        }
      }
      if (strcasecmp(state->target_nick, arg2) == 0) {
        irc_printf(state, "PRIVMSG %s :Error: Name '%s' already in use by this bot.\r\n",
                   nick, arg2);
        return;
      }
      for (int i = 0; i < state->trusted_bot_count; i++) {
        char bnick[MAX_NICK] = "";
        sscanf(state->trusted_bots[i], "%9[^!]", bnick);
        if (strcasecmp(bnick, arg2) == 0) {
          irc_printf(state, "PRIVMSG %s :Error: Name '%s' already in use by a bot.\r\n",
                     nick, arg2);
          return;
        }
      }
      bool cn_found = false;
      /* Case 1: this bot's own target nick */
      if (strcasecmp(state->target_nick, arg1) == 0) {
        snprintf(state->target_nick, MAX_NICK, "%s", arg2);
        state->current_nick_ts = time(NULL);
        config_write_with_state_pass(state);
        hub_client_push_delta(state, "n", arg2, state->current_nick_ts);
        irc_printf(state, "PRIVMSG %s :This bot's nick changed to '%s' and saved.\r\n",
                   nick, arg2);
        cn_found = true;
      }
      /* Case 2: admin or oper */
      if (!cn_found) {
        for (int i = 0; i < state->user_record_count; i++) {
          user_record_t *u = &state->user_records[i];
          if (u->is_active && strcasecmp(u->name, arg1) == 0) {
            snprintf(u->name, sizeof(u->name), "%s", arg2);
            u->timestamp = time(NULL);
            config_write_with_state_pass(state);
            hub_client_push_admin_delta(state);
            irc_printf(state, "PRIVMSG %s :User '%s' renamed to '%s'.\r\n",
                       nick, arg1, arg2);
            cn_found = true;
            break;
          }
        }
      }
      /* Case 3: trusted bot */
      if (!cn_found) {
        for (int i = 0; i < state->trusted_bot_count; i++) {
          char bnick[MAX_NICK] = "", bmask[MAX_MASK_LEN] = "";
          char buuid[64] = "";
          long long bts = 0;
          sscanf(state->trusted_bots[i], "%9[^!]", bnick);
          if (strcasecmp(bnick, arg1) != 0) continue;
          sscanf(state->trusted_bots[i], "%255[^|]|%63[^|]|%lld",
                 bmask, buuid, &bts);
          /* Replace the nick part of the mask (up to '!') */
          char newmask[MAX_MASK_LEN] = "";
          char *bang = strchr(bmask, '!');
          if (bang)
            snprintf(newmask, sizeof(newmask), "%s%s", arg2, bang);
          else
            snprintf(newmask, sizeof(newmask), "%s", arg2);
          long new_ts = time(NULL);
          char new_entry[512];
          snprintf(new_entry, sizeof(new_entry), "%s|%s|%ld",
                   newmask, buuid, new_ts);
          char *dup_entry = strdup(new_entry);
          if (!dup_entry) {
            irc_printf(state, "PRIVMSG %s :Error: Memory allocation failed.\r\n", nick);
            return;
          }
          free(state->trusted_bots[i]);
          state->trusted_bots[i] = dup_entry;
          config_write_with_state_pass(state);
          /* Send SETNICK to the bot via encrypted bot comms (old nick) */
          bot_comms_send_command(state, arg1, "SETNICK %s", arg2);
          irc_printf(state, "PRIVMSG %s :Bot '%s' renamed to '%s' and notified.\r\n",
                     nick, arg1, arg2);
          cn_found = true;
          break;
        }
      }
      if (!cn_found)
        irc_printf(state, "PRIVMSG %s :Error: No bot/admin/oper named '%s' found.\r\n",
                   nick, arg1);
    } else if (strcasecmp(command, "saveconf") == 0) {
      config_write_with_state_pass(state);
      irc_printf(state, "PRIVMSG %s :Configuration state saved to %s.\r\n",
                 nick, CONFIG_FILE);
    } else if (strcasecmp(command, "setlog") == 0) {
      if (!arg1) {
        irc_printf(state,
                   "PRIVMSG %s :Syntax: setlog <loglevel> :: LOGLEVELS: "
                   "0=NONE,15=INFO,63=DEBUG\r\n",
                   nick);
        return;
      }
      bool is_valid_int = true;
      for (int i = 0; arg1[i] != '\0'; i++)
        if (!isdigit(arg1[i])) {
          is_valid_int = false;
          break;
        }
      if (is_valid_int) {
        int new_level = atoi(arg1);
        state->log_type = (log_type_t)new_level;
        irc_printf(state, "PRIVMSG %s :Log level set to %d.\r\n", nick,
                   new_level);
        config_write_with_state_pass(state);
      } else
        irc_printf(state,
                   "PRIVMSG %s :Invalid log level. Please provide a valid "
                   "integer.\r\n",
                   nick);
    } else if (strcasecmp(command, "getlog") == 0) {
      if (!arg1) {
        irc_printf(
            state,
            "PRIVMSG %s :Syntax: getlog <level> [lines]. Levels are 'msg' "
            "'ctcp' 'info' 'cmd' 'raw' 'debug'. Default: %d. Max: %d.\r\n",
            nick, DEFAULT_LOG_LINES, MAX_LOG_LINES);
        return;
      }
      int buffer_index = -1;
      if (strcasecmp(arg1, "msg") == 0)
        buffer_index = 0;
      else if (strcasecmp(arg1, "ctcp") == 0)
        buffer_index = 1;
      else if (strcasecmp(arg1, "info") == 0)
        buffer_index = 2;
      else if (strcasecmp(arg1, "cmd") == 0)
        buffer_index = 3;
      else if (strcasecmp(arg1, "raw") == 0)
        buffer_index = 4;
      else if (strcasecmp(arg1, "debug") == 0)
        buffer_index = 5;

      if (buffer_index == -1) {
        irc_printf(state, "PRIVMSG %s :Error: Unknown log level '%s'.\r\n",
                   nick, arg1);
        return;
      }

      int lines_to_show = DEFAULT_LOG_LINES;
      if (arg2) {
        lines_to_show = atoi(arg2);
        if (lines_to_show <= 0)
          lines_to_show = DEFAULT_LOG_LINES;
        if (lines_to_show > MAX_LOG_LINES) {
          irc_printf(state, "PRIVMSG %s :Warning: Line count capped at %d.\r\n",
                     nick, MAX_LOG_LINES);
          lines_to_show = MAX_LOG_LINES;
        }
      }

      log_entry_t *matches[LOG_BUFFER_LINES];
      int matches_found = 0;
      log_buffer_t *log_buf_ptr = &state->in_memory_logs[buffer_index];

      for (int i = 0; i < LOG_BUFFER_LINES; i++) {
        int idx = (log_buf_ptr->log_idx + i) % LOG_BUFFER_LINES;
        log_entry_t *entry = &log_buf_ptr->entries[idx];
        if (entry->line[0] != '\0')
          matches[matches_found++] = entry;
      }

      int lines_to_print =
          (matches_found < lines_to_show) ? matches_found : lines_to_show;
      int start_index = matches_found - lines_to_print;
      irc_printf(state,
                 "PRIVMSG %s :--- Start of Log (%s) - Showing last %d of %d "
                 "lines --- \r\n",
                 nick, arg1, lines_to_print, matches_found);

      struct timespec delay = {0, 250000000};
      for (int i = matches_found - 1; i >= start_index; i--) {
        irc_printf(state, "PRIVMSG %s :%s\r\n", nick, matches[i]->line);
        nanosleep(&delay, NULL);
      }
      irc_printf(state, "PRIVMSG %s :--- End of Log (%s) --- \r\n", nick, arg1);
    } else if (strcasecmp(command, "admins") == 0) {
      struct timespec delay = {0, 100000000};
      /* Find max name width for alignment (min 8) */
      int name_w = 8;
      for (int i = 0; i < state->user_record_count; i++) {
        if (state->user_records[i].type != 'a') continue;
        int nl = (int)strlen(state->user_records[i].name);
        if (nl > name_w) name_w = nl;
      }
      irc_printf(state, "PRIVMSG %s :| ircbot %s admins\r\n", nick, BOT_VERSION);
      irc_printf(state, "PRIVMSG %s :+----------------------------------------------------------------------------\r\n", nick);
      int shown = 0;
      for (int i = 0; i < state->user_record_count && shown < BOT_STATUS_MAX_LINES; i++) {
        user_record_t *u = &state->user_records[i];
        if (u->type != 'a') continue;
        char ts_buf[48];
        if (u->last_seen == 0) {
          snprintf(ts_buf, sizeof(ts_buf), "never");
        } else {
          struct tm *tm = gmtime(&u->last_seen);
          if (tm) strftime(ts_buf, sizeof(ts_buf), "%Y-%m-%d %H:%M:%S UTC", tm);
          else    snprintf(ts_buf, sizeof(ts_buf), "invalid");
        }
        char del_tag[16] = "";
        if (!u->is_active) snprintf(del_tag, sizeof(del_tag), " [deleted]");
        irc_printf(state, "PRIVMSG %s :| %-*s  (last seen: %s)%s\r\n",
                   nick, name_w, u->name, ts_buf, del_tag);
        shown++;
        nanosleep(&delay, NULL);
      }
      if (shown == 0)
        irc_printf(state, "PRIVMSG %s :| (no admins)\r\n", nick);
      irc_printf(state, "PRIVMSG %s :`----------------------------------------------------------------------------\r\n", nick);

    } else if (strcasecmp(command, "opers") == 0) {
      struct timespec delay = {0, 100000000};
      int name_w = 8;
      for (int i = 0; i < state->user_record_count; i++) {
        if (state->user_records[i].type != 'o') continue;
        int nl = (int)strlen(state->user_records[i].name);
        if (nl > name_w) name_w = nl;
      }
      irc_printf(state, "PRIVMSG %s :| ircbot %s opers\r\n", nick, BOT_VERSION);
      irc_printf(state, "PRIVMSG %s :+----------------------------------------------------------------------------\r\n", nick);
      int shown = 0;
      for (int i = 0; i < state->user_record_count && shown < BOT_STATUS_MAX_LINES; i++) {
        user_record_t *u = &state->user_records[i];
        if (u->type != 'o') continue;
        char ts_buf[48];
        if (u->last_seen == 0) {
          snprintf(ts_buf, sizeof(ts_buf), "never");
        } else {
          struct tm *tm = gmtime(&u->last_seen);
          if (tm) strftime(ts_buf, sizeof(ts_buf), "%Y-%m-%d %H:%M:%S UTC", tm);
          else    snprintf(ts_buf, sizeof(ts_buf), "invalid");
        }
        char del_tag[16] = "";
        if (!u->is_active) snprintf(del_tag, sizeof(del_tag), " [deleted]");
        irc_printf(state, "PRIVMSG %s :| %-*s  (last seen: %s)%s\r\n",
                   nick, name_w, u->name, ts_buf, del_tag);
        shown++;
        nanosleep(&delay, NULL);
      }
      if (shown == 0)
        irc_printf(state, "PRIVMSG %s :| (no opers)\r\n", nick);
      irc_printf(state, "PRIVMSG %s :`----------------------------------------------------------------------------\r\n", nick);

    } else if (strcasecmp(command, "match") == 0) {
      /* Show active records for named user or * for all */
      if (!arg1) {
        irc_printf(state, "PRIVMSG %s :Syntax: match <name|*>\r\n", nick);
        return;
      }
      bool match_all = (strcmp(arg1, "*") == 0);
      irc_printf(state, "PRIVMSG %s :| ircbot %s match%s\r\n", nick, BOT_VERSION,
                 match_all ? " *" : "");
      irc_printf(state, "PRIVMSG %s :+----------------------------------------------------------------------------\r\n", nick);
      struct timespec delay = {0, 100000000};
      int shown = 0;
      for (int i = 0; i < state->user_record_count; i++) {
        user_record_t *u = &state->user_records[i];
        if (!match_all && strcasecmp(u->name, arg1) != 0) continue;
        if (!u->is_active) continue;
        char ts_buf[48];
        if (u->last_seen == 0) {
          snprintf(ts_buf, sizeof(ts_buf), "never");
        } else {
          struct tm *tm_utc = gmtime(&u->last_seen);
          if (tm_utc) strftime(ts_buf, sizeof(ts_buf), "%Y-%m-%d %H:%M:%S UTC", tm_utc);
          else        snprintf(ts_buf, sizeof(ts_buf), "invalid");
        }
        irc_printf(state, "PRIVMSG %s :| [%c] %-20s  (last seen: %s)\r\n",
                   nick, u->type, u->name, ts_buf);
        nanosleep(&delay, NULL);
        for (int j = 0; j < state->mask_record_count; j++) {
          mask_record_t *m = &state->mask_records[j];
          if (strcmp(m->uuid, u->uuid) != 0) continue;
          if (!m->is_active) continue;
          char used_buf[48];
          if (m->last_used == 0) {
            snprintf(used_buf, sizeof(used_buf), "never");
          } else {
            struct tm *tm_used = gmtime(&m->last_used);
            if (tm_used) strftime(used_buf, sizeof(used_buf), "%Y-%m-%d %H:%M:%S UTC", tm_used);
            else         snprintf(used_buf, sizeof(used_buf), "invalid");
          }
          irc_printf(state, "PRIVMSG %s :|   %s  (last used: %s)\r\n",
                     nick, m->mask, used_buf);
          nanosleep(&delay, NULL);
          if (++shown >= BOT_STATUS_MAX_LINES) goto match_done;
        }
      }
      /* If no user record found and not wildcard, check trusted bots */
      if (shown == 0 && !match_all) {
        for (int i = 0; i < state->trusted_bot_count; i++) {
          char bot_mask[256] = "", bot_uuid[64] = "";
          long long bot_ts = 0;
          sscanf(state->trusted_bots[i], "%255[^|]|%63[^|]|%lld",
                 bot_mask, bot_uuid, &bot_ts);
          char bot_nick[MAX_NICK] = "";
          sscanf(bot_mask, "%9[^!]", bot_nick);
          if (strcasecmp(bot_nick, arg1) != 0) continue;
          /* Found a matching bot */
          char ts_buf[48];
          if (bot_ts == 0) {
            snprintf(ts_buf, sizeof(ts_buf), "never");
          } else {
            time_t bts = (time_t)bot_ts;
            struct tm *tm_utc = gmtime(&bts);
            if (tm_utc) strftime(ts_buf, sizeof(ts_buf), "%Y-%m-%d %H:%M:%S UTC", tm_utc);
            else        snprintf(ts_buf, sizeof(ts_buf), "invalid");
          }
          irc_printf(state, "PRIVMSG %s :| [b] %-20s  (last seen: %s)\r\n",
                     nick, bot_nick, ts_buf);
          nanosleep(&delay, NULL);
          if (bot_mask[0])
            irc_printf(state, "PRIVMSG %s :|   mask: %s\r\n", nick, bot_mask);
          if (bot_uuid[0])
            irc_printf(state, "PRIVMSG %s :|   uuid: %s\r\n", nick, bot_uuid);
          const char *hub_str = (state->hub_connected && state->current_hub[0])
                                ? state->current_hub : "none";
          irc_printf(state, "PRIVMSG %s :|   hub : %s\r\n", nick, hub_str);
          shown++;
          nanosleep(&delay, NULL);
          break;
        }
      }
      if (shown == 0 && !match_all)
        irc_printf(state, "PRIVMSG %s :| unknown user: %s\r\n", nick, arg1);
      match_done:
      irc_printf(state, "PRIVMSG %s :`----------------------------------------------------------------------------\r\n", nick);

    } else if (strcasecmp(command, "+admin") == 0) {
      /* +admin <name> <password> <usermask> */
      if (!arg1 || !arg2 || !arg3) {
        irc_printf(state, "PRIVMSG %s :Syntax: +admin <name> <password> <nick!user@host>\r\n", nick);
        return;
      }
      if (!strchr(arg3,'!') || !strchr(arg3,'@')) {
        irc_printf(state, "PRIVMSG %s :Error: mask must contain ! and @\r\n", nick);
        return;
      }
      for (int i = 0; i < state->user_record_count; i++) {
        if (state->user_records[i].is_active &&
            strcasecmp(state->user_records[i].name, arg1) == 0) {
          irc_printf(state, "PRIVMSG %s :Error: name '%s' already exists.\r\n", nick, arg1);
          return;
        }
      }
      if (state->user_record_count >= MAX_USER_RECORDS) {
        irc_printf(state, "PRIVMSG %s :Error: user record table full.\r\n", nick); return;
      }
      if (state->mask_record_count >= MAX_USER_MASKS) {
        irc_printf(state, "PRIVMSG %s :Error: mask table full.\r\n", nick); return;
      }
      /* Generate UUID using random bytes */
      unsigned char rnd[16]; RAND_bytes(rnd, sizeof(rnd));
      rnd[6]=(rnd[6]&0x0f)|0x40; rnd[8]=(rnd[8]&0x3f)|0x80;
      char new_uuid[37];
      snprintf(new_uuid, sizeof(new_uuid),
               "%02x%02x%02x%02x-%02x%02x-%02x%02x-%02x%02x-%02x%02x%02x%02x%02x%02x",
               rnd[0],rnd[1],rnd[2],rnd[3],rnd[4],rnd[5],rnd[6],rnd[7],
               rnd[8],rnd[9],rnd[10],rnd[11],rnd[12],rnd[13],rnd[14],rnd[15]);
      time_t now = time(NULL);
      user_record_t *u = &state->user_records[state->user_record_count++];
      memset(u, 0, sizeof(*u));
      snprintf(u->uuid, sizeof(u->uuid), "%s", new_uuid);
      snprintf(u->name, sizeof(u->name), "%s", arg1);
      snprintf(u->password, sizeof(u->password), "%s", arg2);
      u->type = 'a'; u->is_active = true; u->timestamp = now;
      mask_record_t *m = &state->mask_records[state->mask_record_count++];
      memset(m, 0, sizeof(*m));
      snprintf(m->uuid, sizeof(m->uuid), "%s", new_uuid);
      snprintf(m->mask, sizeof(m->mask), "%s", arg3);
      m->is_active = true; m->timestamp = now;
      config_write_with_state_pass(state);
      hub_client_push_admin_delta(state);
      irc_printf(state, "PRIVMSG %s :Admin '%s' added with mask %s\r\n", nick, arg1, arg3);

    } else if (strcasecmp(command, "-admin") == 0) {
      if (!arg1) {
        irc_printf(state, "PRIVMSG %s :Syntax: -admin <name>\r\n", nick); return;
      }
      user_record_t *target = NULL;
      for (int i = 0; i < state->user_record_count; i++) {
        if (state->user_records[i].is_active && state->user_records[i].type=='a' &&
            strcasecmp(state->user_records[i].name, arg1) == 0) {
          target = &state->user_records[i]; break;
        }
      }
      if (!target) { irc_printf(state, "PRIVMSG %s :Error: admin '%s' not found.\r\n", nick, arg1); return; }
      target->is_active = false;
      target->timestamp = time(NULL);
      for (int i = 0; i < state->mask_record_count; i++)
        if (strcmp(state->mask_records[i].uuid, target->uuid) == 0) {
          state->mask_records[i].is_active = false;
          state->mask_records[i].timestamp = time(NULL);
        }
      config_write_with_state_pass(state);
      hub_client_push_admin_delta(state);
      irc_printf(state, "PRIVMSG %s :Admin '%s' and all their masks removed.\r\n", nick, arg1);

    } else if (strcasecmp(command, "+oper") == 0) {
      /* +oper <name> <password> <usermask> */
      if (!arg1 || !arg2 || !arg3) {
        irc_printf(state, "PRIVMSG %s :Syntax: +oper <name> <password> <nick!user@host>\r\n", nick);
        return;
      }
      if (!strchr(arg3,'!') || !strchr(arg3,'@')) {
        irc_printf(state, "PRIVMSG %s :Error: mask must contain ! and @\r\n", nick); return;
      }
      for (int i = 0; i < state->user_record_count; i++) {
        if (state->user_records[i].is_active &&
            strcasecmp(state->user_records[i].name, arg1) == 0) {
          irc_printf(state, "PRIVMSG %s :Error: name '%s' already exists.\r\n", nick, arg1); return;
        }
      }
      if (state->user_record_count >= MAX_USER_RECORDS || state->mask_record_count >= MAX_USER_MASKS) {
        irc_printf(state, "PRIVMSG %s :Error: table full.\r\n", nick); return;
      }
      unsigned char rnd2[16]; RAND_bytes(rnd2, sizeof(rnd2));
      rnd2[6]=(rnd2[6]&0x0f)|0x40; rnd2[8]=(rnd2[8]&0x3f)|0x80;
      char new_uuid2[37];
      snprintf(new_uuid2, sizeof(new_uuid2),
               "%02x%02x%02x%02x-%02x%02x-%02x%02x-%02x%02x-%02x%02x%02x%02x%02x%02x",
               rnd2[0],rnd2[1],rnd2[2],rnd2[3],rnd2[4],rnd2[5],rnd2[6],rnd2[7],
               rnd2[8],rnd2[9],rnd2[10],rnd2[11],rnd2[12],rnd2[13],rnd2[14],rnd2[15]);
      time_t now2 = time(NULL);
      user_record_t *u2 = &state->user_records[state->user_record_count++];
      memset(u2, 0, sizeof(*u2));
      snprintf(u2->uuid, sizeof(u2->uuid), "%s", new_uuid2);
      snprintf(u2->name, sizeof(u2->name), "%s", arg1);
      snprintf(u2->password, sizeof(u2->password), "%s", arg2);
      u2->type = 'o'; u2->is_active = true; u2->timestamp = now2;
      mask_record_t *m2 = &state->mask_records[state->mask_record_count++];
      memset(m2, 0, sizeof(*m2));
      snprintf(m2->uuid, sizeof(m2->uuid), "%s", new_uuid2);
      snprintf(m2->mask, sizeof(m2->mask), "%s", arg3);
      m2->is_active = true; m2->timestamp = now2;
      config_write_with_state_pass(state);
      hub_client_push_admin_delta(state);
      irc_printf(state, "PRIVMSG %s :Oper '%s' added with mask %s\r\n", nick, arg1, arg3);

    } else if (strcasecmp(command, "-oper") == 0) {
      if (!arg1) {
        irc_printf(state, "PRIVMSG %s :Syntax: -oper <name>\r\n", nick); return;
      }
      user_record_t *target_o = NULL;
      for (int i = 0; i < state->user_record_count; i++) {
        if (state->user_records[i].is_active && state->user_records[i].type=='o' &&
            strcasecmp(state->user_records[i].name, arg1) == 0) {
          target_o = &state->user_records[i]; break;
        }
      }
      if (!target_o) { irc_printf(state, "PRIVMSG %s :Error: oper '%s' not found.\r\n", nick, arg1); return; }
      target_o->is_active = false;
      target_o->timestamp = time(NULL);
      for (int i = 0; i < state->mask_record_count; i++)
        if (strcmp(state->mask_records[i].uuid, target_o->uuid) == 0) {
          state->mask_records[i].is_active = false;
          state->mask_records[i].timestamp = time(NULL);
        }
      config_write_with_state_pass(state);
      hub_client_push_admin_delta(state);
      irc_printf(state, "PRIVMSG %s :Oper '%s' and all their masks removed.\r\n", nick, arg1);

    } else if (strcasecmp(command, "+usermask") == 0) {
      /* +usermask <name> <mask> */
      if (!arg1 || !arg2) {
        irc_printf(state, "PRIVMSG %s :Syntax: +usermask <name> <nick!user@host>\r\n", nick); return;
      }
      if (!strchr(arg2,'!') || !strchr(arg2,'@')) {
        irc_printf(state, "PRIVMSG %s :Error: mask must contain ! and @\r\n", nick); return;
      }
      user_record_t *tum = NULL;
      for (int i = 0; i < state->user_record_count; i++) {
        if (state->user_records[i].is_active &&
            strcasecmp(state->user_records[i].name, arg1) == 0) {
          tum = &state->user_records[i]; break;
        }
      }
      if (!tum) { irc_printf(state, "PRIVMSG %s :Error: user '%s' not found.\r\n", nick, arg1); return; }
      for (int i = 0; i < state->mask_record_count; i++) {
        if (state->mask_records[i].is_active &&
            strcmp(state->mask_records[i].uuid, tum->uuid) == 0 &&
            strcasecmp(state->mask_records[i].mask, arg2) == 0) {
          irc_printf(state, "PRIVMSG %s :Error: mask already exists.\r\n", nick); return;
        }
      }
      if (state->mask_record_count >= MAX_USER_MASKS) {
        irc_printf(state, "PRIVMSG %s :Error: mask table full.\r\n", nick); return;
      }
      char tum_uuid[37]; snprintf(tum_uuid, sizeof(tum_uuid), "%s", tum->uuid);
      mask_record_t *nm = &state->mask_records[state->mask_record_count++];
      memset(nm, 0, sizeof(*nm));
      snprintf(nm->uuid, sizeof(nm->uuid), "%s", tum_uuid);
      snprintf(nm->mask, sizeof(nm->mask), "%s", arg2);
      nm->is_active = true; nm->timestamp = time(NULL);
      config_write_with_state_pass(state);
      hub_client_push_admin_delta(state);
      irc_printf(state, "PRIVMSG %s :Mask %s added to %s\r\n", nick, arg2, arg1);

    } else if (strcasecmp(command, "-usermask") == 0) {
      /* -usermask <name> <mask> */
      if (!arg1 || !arg2) {
        irc_printf(state, "PRIVMSG %s :Syntax: -usermask <name> <mask>\r\n", nick); return;
      }
      user_record_t *dum = NULL;
      for (int i = 0; i < state->user_record_count; i++) {
        if (state->user_records[i].is_active &&
            strcasecmp(state->user_records[i].name, arg1) == 0) {
          dum = &state->user_records[i]; break;
        }
      }
      if (!dum) { irc_printf(state, "PRIVMSG %s :Error: user '%s' not found.\r\n", nick, arg1); return; }
      mask_record_t *fdm = NULL;
      for (int i = 0; i < state->mask_record_count; i++) {
        if (state->mask_records[i].is_active &&
            strcmp(state->mask_records[i].uuid, dum->uuid) == 0 &&
            strcasecmp(state->mask_records[i].mask, arg2) == 0) {
          fdm = &state->mask_records[i]; break;
        }
      }
      if (!fdm) { irc_printf(state, "PRIVMSG %s :Error: mask '%s' not found for %s.\r\n", nick, arg2, arg1); return; }
      fdm->is_active = false;
      fdm->timestamp = time(NULL);
      config_write_with_state_pass(state);
      hub_client_push_admin_delta(state);
      irc_printf(state, "PRIVMSG %s :Mask %s removed from %s\r\n", nick, arg2, arg1);

    } else if (strcasecmp(command, "+server") == 0) {
      if (!arg1) {
        irc_printf(state,
                   "PRIVMSG %s :Syntax: +server <irc.server.net:6667>\r\n",
                   nick);
        return;
      }
      if (state->server_count < MAX_SERVERS) {
        char *dup = strdup(arg1);
        if (!dup) return;
        irc_server_block_clear(state, state->server_count); /* fresh slot */
        state->server_list[state->server_count++] = dup;
        state->server_list[state->server_count] = NULL;
        config_write_with_state_pass(state);
        irc_printf(state, "PRIVMSG %s :Added server '%s' and saved config.\r\n",
                   nick, arg1);
      } else
        irc_printf(state, "PRIVMSG %s :Error: Server list is full.\r\n", nick);
    } else if (strcasecmp(command, "-server") == 0) {
      if (!arg1) {
        irc_printf(state, "PRIVMSG %s :Syntax: -server <server>\r\n", nick);
        return;
      }
      int found_index = -1;
      for (int i = 0; i < state->server_count; i++)
        if (strcasecmp(state->server_list[i], arg1) == 0) {
          found_index = i;
          break;
        }
      if (found_index != -1) {
        irc_server_block_remove(state, found_index); /* before compaction */
        free(state->server_list[found_index]);
        for (int i = found_index; i < state->server_count - 1; i++)
          state->server_list[i] = state->server_list[i + 1];
        state->server_count--;
        state->server_list[state->server_count] = NULL;
        config_write_with_state_pass(state);
        irc_printf(state,
                   "PRIVMSG %s :Removed server '%s' and saved config.\r\n",
                   nick, arg1);
      }
    } else if (strcasecmp(command, "update") == 0) {
      if (arg1)
        updater_perform_upgrade(state, nick, arg1);
      else
        updater_check_for_updates(state, nick);
    } else if (strcasecmp(command, "+hub") == 0) {
      /* +hub <host:port> <pubkey-b64>
       * The pubkey is the hub's pinned long-term Ed25519 public key — either
       * 44-char base64 (raw 32-byte Ed25519) or 88-char base64 (combined
       * 64-byte Curve25519 pubkey, first 32 bytes used; same as the hub's
       * hub_public.b64). Per-hub keypairs mean the pinned key is REQUIRED:
       * the bot refuses to connect to a hub it can't authenticate. This
       * folds in the old 'sethubpub' behaviour per hub. */
      if (!arg1 || !arg2) {
        irc_printf(state,
                   "PRIVMSG %s :Syntax: +hub <host:port> <pubkey-b64>\r\n",
                   nick);
        return;
      }
      /* Validate address has a host and a numeric port. */
      const char *colon = strrchr(arg1, ':');
      if (!colon || colon == arg1 || atoi(colon + 1) <= 0) {
        irc_printf(state,
                   "PRIVMSG %s :Error: address must be HOST:PORT (e.g. "
                   "hub.example.com:7000).\r\n", nick);
        return;
      }
      /* Duplicate check (by address). */
      for (int i = 0; i < state->hub_count; i++) {
        if (strcmp(state->hubs[i].addr, arg1) == 0) {
          irc_printf(state,
                     "PRIVMSG %s :Error: Hub '%s' already exists. Remove it "
                     "with -hub first to change its key.\r\n", nick, arg1);
          return;
        }
      }
      if (state->hub_count >= MAX_SERVERS) {
        irc_printf(state, "PRIVMSG %s :Error: Hub list is full.\r\n", nick);
        return;
      }
      /* Validate + decode the pinned pubkey. */
      int dec_len = 0;
      unsigned char *dec = base64_decode(arg2, &dec_len);
      if (!dec || (dec_len != 32 && dec_len != HUB_KEY_RAW_LEN)) {
        irc_printf(state,
                   "PRIVMSG %s :Error: pubkey must be base64 of a 32-byte "
                   "Ed25519 key (44 chars) or 64-byte combined Curve25519 "
                   "key (88 chars).\r\n", nick);
        if (dec) free(dec);
        return;
      }
      hub_entry_t *he = &state->hubs[state->hub_count];
      memset(he, 0, sizeof(*he));
      snprintf(he->addr, sizeof(he->addr), "%s", arg1);
      memcpy(he->ed_pub, dec, 32);
      he->ed_pub_set = true;
      secure_wipe(dec, (size_t)dec_len);
      free(dec);
      state->hub_count++;
      config_write_with_state_pass(state);
      irc_printf(state,
                 "PRIVMSG %s :Added Hub: %s (pubkey pinned)\r\n", nick, arg1);
      /* If we are not connected to any hub yet, try the new one now. */
      if (state->hub_fd == -1) {
        state->last_hub_connect_attempt = 0;
        hub_client_connect(state);
      }
    } else if (strcasecmp(command, "-hub") == 0) {
      if (!arg1) {
        irc_printf(state, "PRIVMSG %s :Syntax: -hub <host:port>\r\n", nick);
        return;
      }
      int found = -1;
      for (int i = 0; i < state->hub_count; i++)
        if (strcmp(state->hubs[i].addr, arg1) == 0) {
          found = i;
          break;
        }
      if (found != -1) {
        // Check if this is the currently connected hub
        bool is_current_hub = (state->hub_connected &&
                               strcmp(state->current_hub, arg1) == 0);

        // If removing the currently connected hub, disconnect first
        if (is_current_hub) {
          irc_printf(state, "PRIVMSG %s :Disconnecting from current hub: %s\r\n",
                     nick, arg1);
          hub_client_disconnect(state);
        }

        // Remove the hub from the list (shift entries down, wiping the key)
        secure_wipe(state->hubs[found].ed_pub, sizeof(state->hubs[found].ed_pub));
        for (int i = found; i < state->hub_count - 1; i++)
          state->hubs[i] = state->hubs[i + 1];
        state->hub_count--;
        memset(&state->hubs[state->hub_count], 0,
               sizeof(state->hubs[state->hub_count]));
        config_write_with_state_pass(state);
        irc_printf(state, "PRIVMSG %s :Removed Hub: %s\r\n", nick, arg1);

        // If we disconnected and there are other hubs available, reconnect
        if (is_current_hub && state->hub_count > 0) {
          irc_printf(state, "PRIVMSG %s :Reconnecting to another hub...\r\n", nick);
          state->last_hub_connect_attempt = 0; // Reset cooldown
          hub_client_connect(state);
        } else if (is_current_hub && state->hub_count == 0) {
          irc_printf(state, "PRIVMSG %s :No other hubs available to connect to.\r\n",
                     nick);
        }
      } else {
        irc_printf(state, "PRIVMSG %s :Error: Hub '%s' not found.\r\n",
                   nick, arg1);
      }
    } else if (strcasecmp(command, "rekey") == 0) {
      /* Rotate the bot's own Curve25519 identity keypair.
       *
       * Trust model: the bot generates the new keypair locally (the private
       * key never leaves this host) and pushes only the new PUBLIC key to the
       * hub. The push rides the CURRENT authenticated session, so possession
       * of the OLD private key authorises the rotation — only the legitimate
       * bot can rekey itself, and only its own record (the hub keys the entry
       * by the authenticated client UUID). The hub is the source of trust: it
       * stores the new pub, re-verifies us against it on reconnect, and fans
       * it out to peer hubs. The UUID is unchanged.
       *
       * Ordering is fail-safe: we push the new pub FIRST and only commit the
       * new private key locally if that send succeeds, so an interrupted
       * rekey can never leave us holding a key the hub has never seen. */
      if (state->hub_count == 0) {
        irc_printf(state,
                   "PRIVMSG %s :Error: no hub configured; nothing to rekey.\r\n",
                   nick);
        return;
      }
      if (!state->hub_authenticated || state->hub_fd == -1) {
        irc_printf(state,
                   "PRIVMSG %s :Error: not authenticated to a hub. Rekey needs "
                   "an active session so the new key is pushed under the old "
                   "one. Try again once connected.\r\n", nick);
        return;
      }

      unsigned char new_priv[HUB_KEY_RAW_LEN], new_pub[HUB_KEY_RAW_LEN];
      if (!crypto_generate_combined_keypair(new_priv, new_pub)) {
        irc_printf(state,
                   "PRIVMSG %s :Error: keypair generation failed.\r\n", nick);
        return;
      }
      char *new_priv_b64 = base64_encode(new_priv, HUB_KEY_RAW_LEN);
      char *new_pub_b64  = base64_encode(new_pub,  HUB_KEY_RAW_LEN);
      if (!new_priv_b64 || !new_pub_b64) {
        if (new_priv_b64) { secure_wipe(new_priv_b64, strlen(new_priv_b64)); free(new_priv_b64); }
        if (new_pub_b64) free(new_pub_b64);
        secure_wipe(new_priv, sizeof(new_priv));
        secure_wipe(new_pub, sizeof(new_pub));
        irc_printf(state, "PRIVMSG %s :Error: base64 encode failed.\r\n", nick);
        return;
      }

      /* 1) Push the new PUBLIC key to the hub under the current session. */
      if (!hub_client_push_delta(state, "pub", new_pub_b64, time(NULL))) {
        secure_wipe(new_priv, sizeof(new_priv));
        secure_wipe(new_pub, sizeof(new_pub));
        secure_wipe(new_priv_b64, strlen(new_priv_b64));
        free(new_priv_b64);
        free(new_pub_b64);
        irc_printf(state,
                   "PRIVMSG %s :Error: failed to push new pubkey to hub; key "
                   "left UNCHANGED.\r\n", nick);
        return;
      }

      /* 2) Commit the new PRIVATE key locally: mlock'd raw cache, the base64
       *    serialization field, and the encrypted config on disk. */
      OPENSSL_cleanse(state->hub_key_raw, sizeof(state->hub_key_raw));
      memcpy(state->hub_key_raw, new_priv, HUB_KEY_RAW_LEN);
      secure_wipe(state->hub_key, sizeof(state->hub_key));
      snprintf(state->hub_key, sizeof(state->hub_key), "%s", new_priv_b64);
      config_write_with_state_pass(state);

      irc_printf(state,
                 "PRIVMSG %s :✓ Rekeyed. New pubkey pushed to hub; "
                 "reconnecting with new key.\r\n", nick);
      log_message(L_INFO, state,
                  "[HUB] Rekey: generated new identity, pushed new pub to hub, "
                  "reconnecting.\n");

      secure_wipe(new_priv, sizeof(new_priv));
      secure_wipe(new_pub, sizeof(new_pub));
      secure_wipe(new_priv_b64, strlen(new_priv_b64));
      free(new_priv_b64);
      free(new_pub_b64);

      /* 3) Reconnect so the hub re-verifies us against the new pub. */
      hub_client_disconnect(state);
      state->last_hub_connect_attempt = 0;
      hub_client_connect(state);
    } else if (strcasecmp(command, "chpass") == 0) {
      /* chpass <name> <newpassword> — admin changes anyone; oper changes own only */
      if (!arg1 || !arg2) {
        irc_printf(state, "PRIVMSG %s :Syntax: chpass <name> <newpassword>\r\n", nick); return;
      }
      user_record_t *cp_target = NULL;
      for (int i = 0; i < state->user_record_count; i++) {
        if (state->user_records[i].is_active &&
            strcasecmp(state->user_records[i].name, arg1) == 0) {
          cp_target = &state->user_records[i]; break;
        }
      }
      if (!cp_target) { irc_printf(state, "PRIVMSG %s :Error: user '%s' not found.\r\n", nick, arg1); return; }
      snprintf(cp_target->password, sizeof(cp_target->password), "%s", arg2);
      cp_target->timestamp = time(NULL);
      config_write_with_state_pass(state);
      hub_client_push_admin_delta(state);
      irc_printf(state, "PRIVMSG %s :Password changed for %s\r\n", nick, arg1);

    } else if (strcasecmp(command, "help") == 0) {
      if (!arg1) {
        irc_printf(state, "PRIVMSG %s : | " BOT_NAME " " BOT_VERSION " help\r\n", nick);
        irc_printf(state, "PRIVMSG %s : +----------------------------------------------------------------------------\r\n", nick);
        irc_printf(state, "PRIVMSG %s : | \r\n", nick);
        if (is_opt_set(state, OPT_HUB_ONLY_MUTATIONS)) {
          irc_printf(state, "PRIVMSG %s : |   die, jump, op, invite, status, givenick, chnick\r\n", nick);
          irc_printf(state, "PRIVMSG %s : |   +server, -server, admins, opers, match\r\n", nick);
          irc_printf(state, "PRIVMSG %s : |   +hub, -hub, rekey, saveconf, setlog, getlog, update, help\r\n", nick);
        } else {
          irc_printf(state, "PRIVMSG %s : |   die, jump, op, join, part, status, givenick, chnick\r\n", nick);
          irc_printf(state, "PRIVMSG %s : |   +server, -server, admins, opers\r\n", nick);
          irc_printf(state, "PRIVMSG %s : |   +admin, -admin, +oper, -oper, +usermask, -usermask, chpass, match\r\n", nick);
          irc_printf(state, "PRIVMSG %s : |   botpass, +bot, -bot, +hub, -hub, rekey\r\n", nick);
          irc_printf(state, "PRIVMSG %s : |   saveconf, setlog, getlog, update, help\r\n", nick);
        }
        irc_printf(state, "PRIVMSG %s : |\r\n", nick);
        irc_printf(state, "PRIVMSG %s : `----------------------------------------------------------------------------\r\n", nick);
      } else {
        if (strcasecmp(arg1, "die") == 0) {
          irc_printf(state,
                     "PRIVMSG %s :Syntax: die - Kills the bot process.\r\n",
                     nick);
        } else if (strcasecmp(arg1, "jump") == 0) {
          irc_printf(
              state,
              "PRIVMSG %s :Syntax: jump [server] - Jump to the next IRC server, "
              "or to a specific server by hostname (port-independent match). "
              "Servers that banned or throttled the bot are skipped; naming one "
              "clears its hold and retries it now.\r\n",
              nick);
        } else if (strcasecmp(arg1, "op") == 0) {
          irc_printf(state,
                     "PRIVMSG %s :Syntax: op <#channel> - Get operator status "
                     "on a channel.\r\n",
                     nick);
        } else if (strcasecmp(arg1, "status") == 0) {
          irc_printf(state, "PRIVMSG %s :Syntax: status - Show bot status.\r\n",
                     nick);
        } else if (strcasecmp(arg1, "givenick") == 0) {
          irc_printf(
              state,
              "PRIVMSG %s :Syntax: givenick - Temporarily changes the bot nick "
              "to an alternate. Will try to regain primary nick after 20 "
              "seconds until it accomplishes the task.\r\n",
              nick);
        } else if (strcasecmp(arg1, "chnick") == 0) {
          irc_printf(state,
                     "PRIVMSG %s :Syntax: chnick <oldnick> <newnick> - Renames "
                     "a bot, admin, or oper. Nicks must be unique across all types. "
                     "For bots, propagates the change via hub mesh.\r\n",
                     nick);
        } else if (strcasecmp(arg1, "+server") == 0) {
          irc_printf(state,
                     "PRIVMSG %s :Syntax: +server <irc.network.net:6667> - Add "
                     "another irc server to the bot's server list. Port not "
                     "required.\r\n",
                     nick);
        } else if (strcasecmp(arg1, "-server") == 0) {
          irc_printf(state,
                     "PRIVMSG %s :Syntax: -server <irc.network.net:6667> - "
                     "Removes a server from the bot's server list. Specify "
                     "server as it is listed in 'status' command.\r\n",
                     nick);
        } else if (strcasecmp(arg1, "admins") == 0) {
          irc_printf(state, "PRIVMSG %s :Syntax: admins - List all admins.\r\n", nick);
        } else if (strcasecmp(arg1, "opers") == 0) {
          irc_printf(state, "PRIVMSG %s :Syntax: opers - List all opers.\r\n", nick);
        } else if (strcasecmp(arg1, "+admin") == 0) {
          irc_printf(state,
                     "PRIVMSG %s :Syntax: +admin <name> <password> <mask> - "
                     "Add a named admin with first usermask. Name must be unique across admins and opers.\r\n", nick);
        } else if (strcasecmp(arg1, "-admin") == 0) {
          irc_printf(state,
                     "PRIVMSG %s :Syntax: -admin <name> - Remove admin and all their masks.\r\n", nick);
        } else if (strcasecmp(arg1, "+oper") == 0) {
          irc_printf(state,
                     "PRIVMSG %s :Syntax: +oper <name> <password> <mask> - "
                     "Add a named oper with first usermask.\r\n", nick);
        } else if (strcasecmp(arg1, "-oper") == 0) {
          irc_printf(state,
                     "PRIVMSG %s :Syntax: -oper <name> - Remove oper and all their masks.\r\n", nick);
        } else if (strcasecmp(arg1, "+usermask") == 0) {
          irc_printf(state,
                     "PRIVMSG %s :Syntax: +usermask <name> <mask> - Add a usermask to admin or oper.\r\n", nick);
        } else if (strcasecmp(arg1, "-usermask") == 0) {
          irc_printf(state,
                     "PRIVMSG %s :Syntax: -usermask <name> <mask> - Remove a specific usermask from admin or oper.\r\n", nick);
        } else if (strcasecmp(arg1, "chpass") == 0) {
          irc_printf(state,
                     "PRIVMSG %s :Syntax: chpass <name> <newpassword> - Change password for named admin or oper. "
                     "Opers may only change their own password.\r\n", nick);
        } else if (strcasecmp(arg1, "match") == 0) {
          irc_printf(state,
                     "PRIVMSG %s :Syntax: match <name|*> - Show all records for a user, or * for all users.\r\n", nick);
        } else if (strcasecmp(arg1, "botpass") == 0) {
          irc_printf(state,
                     "PRIVMSG %s :Syntax: botpass <password> - Creates a bot "
                     "password that bots use to communicate with each other. "
                     "This password is used in all bot communication with "
                     "known bots matching a stored usermask.\r\n",
                     nick);
        } else if (strcasecmp(arg1, "+bot") == 0) {
          irc_printf(
              state,
              "PRIVMSG %s :Syntax: +bot <nick*!*user@hostmask.com> - Adds a "
              "bot mask for secure bot communication. The usermask should be "
              "reflective of potential nick changes.\r\n",
              nick);
        } else if (strcasecmp(arg1, "-bot") == 0) {
          irc_printf(state,
                     "PRIVMSG %s :Syntax: -bot <nick*!*user@hostmask.com> - "
                     "Removes a bot from the known bot list as shown in the "
                     "'status' command.\r\n",
                     nick);
        } else if (strcasecmp(arg1, "saveconf") == 0) {
          irc_printf(state,
                     "PRIVMSG %s :Syntax: saveconf - Immediately save config "
                     "file.\r\n",
                     nick);
        } else if (strcasecmp(arg1, "setlog") == 0) {
          irc_printf(state,
                     "PRIVMSG %s :Syntax: setlog <loglevel> - Set loglevel for "
                     "output to a log file. 0=NONE,15=INFO,63=DEBUG.\r\n",
                     nick);
        } else if (strcasecmp(arg1, "getlog") == 0) {
          irc_printf(state,
                     "PRIVMSG %s :Syntax: getlog <loglevel> [lines]. Get "
                     "latest logs for requested loglevel. Levels are 'msg' "
                     "'ctcp' 'info' 'cmd' 'raw' 'debug'. Default number of "
                     "lines: %d. Max number of lines: %d.\r\n",
                     nick, DEFAULT_LOG_LINES, MAX_LOG_LINES);
        } else if (strcasecmp(arg1, "update") == 0) {
          irc_printf(state,
                     "PRIVMSG %s :Syntax: update without argument shows "
                     "available versions. "
                     "Run with update <ver> to download/compile/and update bot "
                     "binary.\r\n",
                     nick);
        } else if (strcasecmp(arg1, "join") == 0) {
          irc_printf(
              state,
              "PRIVMSG %s :Syntax: join <#channel> - Joins a channel.\r\n",
              nick);
        } else if (strcasecmp(arg1, "part") == 0) {
          irc_printf(
              state,
              "PRIVMSG %s :Syntax: part <#channel> - Parts a channel.\r\n",
              nick);
        } else if (strcasecmp(arg1, "+hub") == 0) {
          irc_printf(
              state,
              "PRIVMSG %s :Syntax: +hub <host:port> <pubkey-b64> - Add a hub "
              "and pin its Ed25519 pubkey (44 or 88 char base64 from the "
              "hub's hub_public.b64).\r\n",
              nick);
        } else if (strcasecmp(arg1, "-hub") == 0) {
          irc_printf(
              state,
              "PRIVMSG %s :Syntax: -hub <host:port> - Remove a configured "
              "hub.\r\n",
              nick);
        } else if (strcasecmp(arg1, "rekey") == 0) {
          irc_printf(
              state,
              "PRIVMSG %s :Syntax: rekey - Generate a new Curve25519 identity "
              "keypair locally, push the new public key to the hub, and "
              "reconnect. UUID is unchanged. Requires an active hub session.\r\n",
              nick);
        } else {
          irc_printf(state,
                     "PRIVMSG %s :No help available for command '%s'.\r\n",
                     nick, arg1);
        }
      }
    }

  } else if (is_op) {
    if (strcasecmp(command, "op") == 0 && arg1) {
      char *saveptr_op;
      char *op_arg1 = strtok_r(arg1, " ", &saveptr_op);
      if (op_arg1)
        irc_printf(state, "MODE %s +o %s\r\n", op_arg1, nick);
    } else if (strcasecmp(command, "chpass") == 0) {
      /* Opers can only change their own password */
      if (!arg1 || !arg2) {
        irc_printf(state, "PRIVMSG %s :Syntax: chpass <yourname> <newpassword>\r\n", nick); return;
      }
      if (!auth_user || strcasecmp(auth_user->name, arg1) != 0) {
        irc_printf(state, "PRIVMSG %s :Error: opers may only change their own password.\r\n", nick); return;
      }
      snprintf(auth_user->password, sizeof(auth_user->password), "%s", arg2);
      auth_user->timestamp = time(NULL);
      config_write_with_state_pass(state);
      hub_client_push_admin_delta(state);
      irc_printf(state, "PRIVMSG %s :Your password has been changed.\r\n", nick);
    } else if (strcasecmp(command, "help") == 0) {
      if (!arg1) {
        irc_printf(state, "PRIVMSG %s : | " BOT_NAME " " BOT_VERSION " help\r\n", nick);
        irc_printf(state, "PRIVMSG %s : +----------------------------------------------------------------------------\r\n", nick);
        irc_printf(state, "PRIVMSG %s : | \r\n", nick);
        irc_printf(state, "PRIVMSG %s : |   op, chpass, help\r\n", nick);
        irc_printf(state, "PRIVMSG %s : |\r\n", nick);
        irc_printf(state, "PRIVMSG %s : `----------------------------------------------------------------------------\r\n", nick);
      } else {
        if (strcasecmp(arg1, "op") == 0) {
          irc_printf(state, "PRIVMSG %s :Syntax: op <#channel> - Get operator status on a channel.\r\n", nick);
        } else if (strcasecmp(arg1, "chpass") == 0) {
          irc_printf(state, "PRIVMSG %s :Syntax: chpass <yourname> <newpassword> - Change your own password.\r\n", nick);
        } else if (strcasecmp(arg1, "help") == 0) {
          irc_printf(state, "PRIVMSG %s :Syntax: help [command] - Show available commands.\r\n", nick);
        } else {
          irc_printf(state, "PRIVMSG %s :No help available for command '%s'.\r\n", nick, arg1);
        }
      }
    }
  }
}
