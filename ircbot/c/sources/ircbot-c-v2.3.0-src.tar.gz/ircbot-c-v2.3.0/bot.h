#ifndef BOT_H
#define BOT_H

#ifdef HAVE_CURL
#include <curl/curl.h>
#endif
#include <limits.h>
#include <netinet/in.h>
#include <openssl/err.h>
#include <openssl/ssl.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <time.h>

#define BOT_NAME "ircbot.c by trojanman"
#define BOT_VERSION "2.3.0"

// Only edit this section
// #define DEFAULT_USER "ircbot"         // Default bot user
#define VHOST "NULL" // NULL for default host, set for alternate
#define PASS_FILE ".ircbot.pass"        // Machine-bound password file
#define PBKDF2_ITERATIONS 100000        // PBKDF2 iterations for pass file key derivation
#define VERSION_RESPONSE                                                       \
  "A robot may not injure a human being" // This is the response to a CTCP
                                         // Version

// #define GECOS "ircbot"         // Gecos field storage
#define CONFIG_FILE ".ircbot.cnf" // Config file name
#define PID_FILE ".ircbot.pid"    // PID file name
#define SALT_SIZE 16          // Modern standard: 128-bit entropy (matches hub)
#define DEFAULT_LOG_LEVEL 63  // Set the default log level. 0=none
#define LOGFILE ".ircbot.log" // Log file name. Only used if log level > 0
#define BOT_LOG_FILE_SIZE (10 * 1024 * 1024) // 10MB cap; LOGFILE is truncated past this
#define BOT_UPDATE_URL                                                         \
  "https://raw.githubusercontent.com/robertclemens/ircbot/main/releases/"      \
  "releases.txt"
// Detached Ed25519 signature for releases.txt (raw 64-byte sig, base64-encoded).
#define BOT_UPDATE_SIG_URL                                                     \
  "https://raw.githubusercontent.com/robertclemens/ircbot/main/releases/"      \
  "releases.sig"
// Base64 of the 32-byte raw Ed25519 PUBLIC key that signs releases.txt.
// MUST be set to enable the self-updater; an empty value DISABLES updates
// (fail-closed).  Generate the keypair, publish releases.txt.sig, and paste the
// 44-char base64 public key here.  Full procedure: docs/security.md ->
// "Signed Release Process (Ed25519 detached signatures)".
#define BOT_UPDATE_PUBKEY_B64 "qkXMh/F8TC+cnKuIwrP5TJIynfrLBD+MDUwvkyh9lBU="
// End of edit section

// You should not edit below this line. While some of the macros may be
// editable, some macros may cause issues. Proceed at your own risk.

// Timeouts
#define JOIN_RETRY_TIME 10 // Time delay between trying to join a channel
#define NICK_TAKE_TIME                                                         \
  20 // Time delay for givenick to stop trying to take the nick back
#define NICK_RETRY_TIME                                                        \
  10 // Time delay for trying to gain the target nick (outside of givenick cmd)
#define DEAD_SERVER_TIMEOUT 120 // Server connection timeout
#define CHECK_LAG_TIMEOUT 60    // Lag timeout
#define ROSTER_REFRESH_INTERVAL 120 // WHO interval (s) when NOT opped (seeking ops); opped bots WHO only on deop
#define HUB_RECONNECT_DELAY 30 // [NEW] Delay between hub connection attempts
/* IRC server refusals (bans / throttles) -- see irc_note_refusal().  A server
 * that refuses the bot is skipped until its hold expires. */
#define IRC_RECONNECT_MIN_INTERVAL 10 // Floor between any two IRC connect attempts
#define IRC_THROTTLE_BACKOFF 60       // Throttled: first hold, doubling per strike...
#define IRC_THROTTLE_BACKOFF_MAX 1800 // ...capped at 30 min
#define IRC_BAN_BACKOFF 900           // Banned, no length stated: 15 min, doubling...
#define IRC_BAN_BACKOFF_MAX 86400     // ...capped at 24 h
#define IRC_BAN_STATED_MAX 2592000    // Clamp a server-stated ban length to 30 days
#define IRC_BAN_GRACE 30              // Added to a stated ban length (clock skew)

// Limits
#define MAX_SERVERS 10 // Max number of servers to store
#define MAX_MASKS 20   // Max number of admin masks to store (kept for migration)
#define MAX_USER_RECORDS 40   // max combined admin + oper records
#define MAX_USER_MASKS   200  // max total usermask records across all users
#define MAX_CHAN 65    // Max length of channel name. Do not change
#define MAX_BUFFER                                                             \
  16384 // Size of RAW IRC message. Do not change (Matched to Hub size)
#define MAX_NICK 10  // Max nick length 9 + NULL terminator = 10. Do not change
#define MAX_PASS 128 // Max password length.
#define MAX_KEY 31   // Max length for a channel key
#define MAX_MASK_LEN 256    // Max usermask length
#define MAX_OP_MASKS 20     // Max number of operators
#define MAX_TRUSTED_BOTS 200 // Max number of trusted bots

/* ==========================================================================
 * Bulk config-payload ceiling (Change 5) — shared contract with irchub/hub.h.
 * MAX_BUFFER (16 KB) stays the wire-frame size for small messages (deltas, op
 * requests, pings).  A full CMD_CONFIG_DATA from the hub can be much larger, so
 * its receive/decrypt/parse buffers size to MAX_CONFIG_PAYLOAD instead.  This
 * must be >= the hub's MAX_CONFIG_PAYLOAD so the bot can always receive what the
 * hub sends; the counts match (records 40, masks 200) and MAX_TRUSTED_BOTS (200)
 * >= the hub's MAX_BOTS, so this formula yields >= the hub's ceiling.
 * ========================================================================== */
#define CFG_GLOBAL_LINE_MAX 1088  /* key[32]+value[1024]+ts+seps */
#define CFG_BOT_FIELD_LINE  320   /* per-bot line: capped value */
#define CFG_USER_LINE_MAX   384   /* a|/o|: uuid+name+MAX_PASS+pubkey */
#define CFG_MASK_LINE_MAX   352   /* m|: uuid+MAX_MASK_LEN */
#define CFG_BLINE_MAX       352   /* b|<mask>|<uuid>|<ts> */
#define CFG_MAX_GLOBALS     64    /* mirrors hub MAX_BOT_ENTRIES */
#define CFG_BOT_SYNC_FIELDS 8
#define CFG_PAYLOAD_SLACK   8192
#define MAX_CONFIG_PAYLOAD \
  ( CFG_MAX_GLOBALS     * CFG_GLOBAL_LINE_MAX + \
    MAX_USER_RECORDS    * CFG_USER_LINE_MAX   + \
    MAX_USER_MASKS      * CFG_MASK_LINE_MAX   + \
    CFG_BOT_SYNC_FIELDS * CFG_BOT_FIELD_LINE  + \
    MAX_TRUSTED_BOTS    * CFG_BLINE_MAX       + \
    CFG_PAYLOAD_SLACK )
/* Largest inbound hub frame = envelope(5) + payload + GCM tag, plus margin. */
#define MAX_HUB_FRAME (MAX_CONFIG_PAYLOAD + 64)
#define MAX_ROSTER_SIZE                                                        \
  50 // Max channel roster size to store. Increase if in very large channels.
#define MAX_SEEN_HASHES                                                        \
  4096 // Stores admin request hashes to protect against anti-replay attacks
#define NONCE_CACHE_SIZE                                                       \
  4096 // Nonce cache for secure communication. Prevents replay attacks
#define NONCE_TTL_SECONDS 60 // Entries older than this are treated as empty
typedef struct { uint64_t nonce; time_t ts; } nonce_entry_t;
/* Config-write debounce.  auth_find_user() bumps last_seen/last_used on every
 * successful admin auth, which would otherwise mean a full config rewrite --
 * including a PBKDF2 key derivation -- per admin command.  The main loop
 * flushes at most once every CONFIG_WRITE_DEBOUNCE_S seconds instead.
 * Mirrors irchub's hub.h:564 / hub_main.c:435. */
#define CONFIG_WRITE_DEBOUNCE_S 5

#define GCM_IV_LEN 12 // 12 bytes (96 bits) is industry standard. Do not change
#define GCM_TAG_LEN                                                            \
  16 // 16 bytes (128 bits) is industry standard. Do not change
#define NUM_LOG_LEVELS 6     // For L_MSG, L_CTCP, L_INFO, L_CMD, L_RAW, L_DEBUG
#define LOG_BUFFER_LINES 50  // Store the last 50 log lines for each log level
#define MAX_LOG_LINE_LEN 256 // Max length of a single log line
#define DEFAULT_LOG_LINES                                                      \
  10 // Default number of getlog lines to display to admin when requested if not
     // provided
#define MAX_LOG_LINES                                                          \
  20 // Max number of lines to cap getlog request to help prevent flooding
#define BOT_STATUS_MAX_LINES 30 // Max trusted-bot lines in status output (anti-flood)
#define MAX_IRC_CHANNELS 10     // Realistic per-bot IRC channel ceiling (server CHANLIMIT)
#define OP_REQUEST_MIN_INTERVAL 5 // Minimum seconds between any OP-REQ sent by this bot
#define MAX_CONFIG_SIZE                                                        \
  (1024 * 1024) // Limit config file size to 1MB to provent OOM
#define MAX_HUB_KEY_SIZE  128  // 88 chars base64 + null + headroom (Curve25519)
#define HUB_KEY_RAW_LEN   64  // 32-byte Ed25519 + 32-byte X25519
#define COMBINED_KEY_B64  88  // base64 of 64-byte combined key
#define MAX_OPT_FLAGS     32  // characters in opt| string (alnum letters)

/* Network-controlled options synced from hub via the 'opt|' record.
 * Each option is a single letter [a-zA-Z0-9].  See is_opt_set() helper. */
#define OPT_HUB_ONLY_MUTATIONS 'h'   // refuse local mutations of hub-authoritative records

#define CMD_PING 0x01
#define CMD_CONFIG_PUSH 0x02
#define CMD_CONFIG_PULL 0x03
#define CMD_CONFIG_DATA 0x04
#define CMD_UPDATE_PUBKEY 0x05
#define CMD_PEER_SYNC 0x06
#define CMD_MESH_STATE 0x07
#define CMD_INVITE_REQUEST 0x09 // Bot -> Hub: Request invite for nick into channel

#define CMD_ADMIN_AUTH 0x10
#define CMD_ADMIN_LIST_FULL 0x11
#define CMD_ADMIN_ADD 0x12
#define CMD_ADMIN_DEL 0x13
#define CMD_ADMIN_REGEN_KEYS 0x14
#define CMD_ADMIN_LIST_SUMMARY 0x15
#define CMD_ADMIN_GET_PENDING 0x16
#define CMD_ADMIN_APPROVE 0x17
#define CMD_ADMIN_ADD_PEER 0x18
#define CMD_ADMIN_LIST_PEERS 0x19
#define CMD_ADMIN_DEL_PEER 0x1A
#define CMD_ADMIN_GET_PUBKEY 0x1B
#define CMD_ADMIN_SET_PRIVKEY 0x1C
#define CMD_ADMIN_GET_PRIVKEY 0x1D
#define CMD_ADMIN_SET_PUBKEY 0x1E
#define CMD_ADMIN_SYNC_MESH 0x1F
#define CMD_ADMIN_CREATE_BOT 0x32     // 50 decimal
#define CMD_ADMIN_REKEY_BOT 0x20      // Generate new bot keypair
#define CMD_ADMIN_DISCONNECT_BOT 0x21 // Force disconnect bot
#define CMD_ADMIN_BOT_STATUS 0x22     // Get bot connection info
#define CMD_BOT_KEY_UPDATE 0x40       // Hub -> Bot: New private key update
#define CMD_BOT_DELTA      0x45       // Bot -> Hub: single-key delta (mesh.md Phase 4)

// Named Admin/Oper/Usermask Commands (v2) — must match hub.h
#define CMD_ADMIN_ADD_ADMIN      0x46
#define CMD_ADMIN_DEL_ADMIN      0x47
#define CMD_ADMIN_ADD_OPER_RECORD 0x48
#define CMD_ADMIN_DEL_OPER_RECORD 0x49
#define CMD_ADMIN_ADD_USERMASK   0x4A
#define CMD_ADMIN_DEL_USERMASK   0x4B
#define CMD_ADMIN_SET_USERPASS   0x4C
#define CMD_ADMIN_MATCH          0x4D
#define CMD_ADMIN_LIST_ADMINS    0x4E
#define CMD_ADMIN_LIST_OPERS_V2  0x4F

// Global Config Management Commands
#define CMD_ADMIN_LIST_CHANNELS 0x23  // List all channels
#define CMD_ADMIN_ADD_CHANNEL 0x24    // Add channel
#define CMD_ADMIN_DEL_CHANNEL 0x25    // Remove channel
#define CMD_ADMIN_LIST_MASKS 0x26     // List admin masks
#define CMD_ADMIN_ADD_MASK 0x27       // Add admin mask
#define CMD_ADMIN_DEL_MASK 0x2B       // Remove admin mask
#define CMD_ADMIN_LIST_OPERS 0x2C     // List oper masks
#define CMD_ADMIN_ADD_OPER 0x2D       // Add oper mask
#define CMD_ADMIN_DEL_OPER 0x2E       // Remove oper mask
#define CMD_ADMIN_SET_ADMIN_PASS 0x2F // Change admin password
#define CMD_ADMIN_SET_BOT_PASS 0x30   // Change bot password
#define CMD_ADMIN_OP_USER 0x31        // Op a user in a channel

// Bot-to-Bot Op Commands (via Hub)
#define CMD_OP_REQUEST 0x28 // Bot -> Hub: Request ops from another bot
#define CMD_OP_GRANT 0x29   // Hub -> Bot: Grant ops to requesting bot
#define CMD_OP_FAILED 0x2A  // Hub -> Bot: Op request failed

// Bot-to-Bot Relay Commands (via Hub)
#define CMD_BOT_RELAY 0x50  // Bot -> Hub: relay encrypted bot command to target bot by UUID
#define CMD_BOT_MSG   0x51  // Hub -> Bot: relayed encrypted bot command payload

extern volatile bool g_shutdown_flag;

// Enums
typedef enum {
  S_NONE = 0,
  S_CONNECTED = 1 << 0,
  S_AUTHED = 1 << 1,
  S_DIE = 1 << 2
} bot_status_t;
typedef enum {
  L_NONE = 0,
  L_MSG = 1,
  L_CTCP = 2,
  L_INFO = 4,
  L_CMD = 8,
  L_RAW = 16,
  L_DEBUG = 32
} log_type_t;

typedef enum {
  HUB_AUTH_NONE,
  HUB_AUTH_SENT_UUID,
  HUB_AUTH_SENT_SIGNATURE,
  HUB_AUTH_COMPLETE
} hub_auth_state_t;

typedef enum { C_NONE = 0, C_OUT = 1 << 0, C_IN = 1 << 1 } chan_status_t;
typedef enum { M_NONE = 0, M_K = 64, M_I = 128 } chan_mode_t;
typedef enum { LS_NONE = 0, LS_LISTEN = 1, LS_CONNECTED = 2 } listen_status_t;

// Struct Forward Declarations
typedef struct bot_state bot_state_t;
typedef struct chan_t chan_t;


typedef struct {
  char   uuid[37];
  char   name[64];
  /* Per-user Curve25519 combined pubkey (Ed25519 + X25519), base64-encoded
   * (88 chars + NUL).  Empty when no key on file.  Bots never need to use
   * the pubkey themselves but they replicate the field via mesh sync. */
  char   pubkey_b64[COMBINED_KEY_B64 + 1];
  bool   has_pubkey;
  char   password[MAX_PASS];
  char   type;         /* 'a' = admin, 'o' = oper */
  bool   is_active;    /* false when action == "del" */
  time_t last_seen;
  time_t timestamp;
} user_record_t;

typedef struct {
  char   uuid[37];     /* matches user_record_t.uuid */
  char   mask[MAX_MASK_LEN];
  bool   is_active;    /* false when action == "del" */
  time_t last_used;    /* 0 = never used */
  time_t timestamp;
} mask_record_t;

typedef struct {
  char nick[MAX_NICK];
  char hostmask[MAX_MASK_LEN];
  bool is_op;
} roster_entry_t;

typedef struct {
  char line[MAX_LOG_LINE_LEN];
} log_entry_t;

typedef struct {
  log_entry_t entries[LOG_BUFFER_LINES];
  int log_idx;
} log_buffer_t;

typedef struct {
  char *buffer;
  size_t size;
} http_response_t;

struct chan_t {
  char name[MAX_CHAN];
  char key[MAX_KEY];
  chan_status_t status;
  chan_mode_t modes;
  bool is_managed;
  time_t timestamp;
  time_t last_who_request;
  roster_entry_t roster[MAX_ROSTER_SIZE];
  int roster_count;
  time_t last_join_attempt;
  bool join_disabled;  // 405 received: stop retrying this channel this session
  bool i_am_opped;
  bool op_request_pending;
  time_t last_op_request_time;
  int op_request_retry_count;
  chan_t *next;
};

/* One configured hub: its "host:port" address plus the hub's pinned
 * long-term Ed25519 public key (32 raw bytes). Per-hub pinning replaced the
 * old single global hub pubkey: each hub now has its own keypair, so the
 * pinned key must travel with the address it authenticates. Set via
 * '+hub <host:port> <pubkey-b64>' (or the -setup wizard). */
typedef struct {
  char addr[256];               /* "host:port" */
  unsigned char ed_pub[32];     /* hub's pinned Ed25519 public key */
  bool ed_pub_set;
} hub_entry_t;

/* Why a server_list[] slot is being skipped (irc_client.c). */
typedef enum {
  SB_NONE = 0,    /* eligible */
  SB_THROTTLED,   /* "reconnecting too fast" / connection limits */
  SB_BANNED,      /* banned, no length stated: escalating backoff */
  SB_BANNED_TEMP, /* banned for a length the server stated */
  SB_BANNED_PERM  /* server said permanent: never retried automatically */
} server_block_kind_t;

#define IRC_REFUSAL_LEN 256 /* stored server refusal text, sanitized */

/* Per-server hold, parallel to server_list[].  Runtime only (not in the
 * config): a restart, +server/-server, or 'jump <server>' clears it. */
typedef struct {
  server_block_kind_t kind;
  time_t until;                 /* not retried before this (0 for PERM) */
  int strikes;                  /* consecutive refusals since the last 001 */
  char reason[IRC_REFUSAL_LEN]; /* what the server said, sanitized */
} server_block_t;

struct bot_state {
  int server_fd;
  int pid_fd;
  char executable_path[PATH_MAX];
  bot_status_t status;
  char current_nick[MAX_NICK];
  char target_nick[MAX_NICK];
  char user[64];
  char gecos[128];
  char vhost[128];
  char *server_list[MAX_SERVERS + 1];
  char actual_server_name[256];
  char actual_hostname[MAX_MASK_LEN];
  time_t actual_hostname_ts;
  time_t current_nick_ts;
  int server_count;
  int current_server_index;
  server_block_t server_blocks[MAX_SERVERS]; // ban/throttle holds, per slot
  int irc_server_idx;          // server_list[] slot of the current/last attempt
  time_t last_irc_attempt;     // enforces IRC_RECONNECT_MIN_INTERVAL
  bool irc_refusal_ban;        // this link got 465 / 463
  char irc_refusal[IRC_REFUSAL_LEN]; // this link's 465/463/ERROR text
  bool irc_blocked_logged;     // "every server refusing" logged this episode
  int nick_generation_attempt;
  time_t bot_start_time;
  time_t connection_time;
  time_t last_pong_time;
  time_t nick_release_time;
  time_t last_nick_attempt;
  bool pong_pending;
  bool nick_change_pending;
  bool default_server_ignored;
  bool is_ssl;
  SSL_CTX *ssl_ctx;
  SSL *ssl;
  log_type_t log_type;
  chan_t *chanlist;
  char ignored_default_channel[MAX_CHAN];
  char ignored_default_mask[MAX_MASK_LEN];
  int ignored_chan_count;
  int chan_count;
  /* startup_password holds the plaintext config-file password for the
   * lifetime of the process (needed on every config write).  It is mlock'd
   * so the OS cannot page it to swap, and OPENSSL_cleanse'd at shutdown.
   *
   * Threat model: mlock prevents swap-file / hibernate leaks.  Root with
   * ptrace or /proc/<pid>/mem CAN still read this while the bot is running —
   * that is unavoidable without hardware-backed key storage.  Real defences
   * are OS-level (ptrace_scope, process isolation, 0600 file permissions). */
  char startup_password[MAX_PASS];
  char bot_comm_pass[MAX_PASS];
  time_t bot_comm_pass_ts;
  char *trusted_bots[MAX_TRUSTED_BOTS + 1];
  int trusted_bot_count;
  roster_entry_t channel_roster[MAX_ROSTER_SIZE];
  char who_request_channel[MAX_CHAN];
  nonce_entry_t recent_nonces[NONCE_CACHE_SIZE];
  int nonce_idx;
  nonce_entry_t admin_nonces[MAX_SEEN_HASHES];
  int admin_nonce_idx;
  log_buffer_t in_memory_logs[NUM_LOG_LEVELS];

  // Named admin/oper records and their usermasks (v2)
  user_record_t user_records[MAX_USER_RECORDS];
  int user_record_count;
  mask_record_t mask_records[MAX_USER_MASKS];
  int mask_record_count;
  bool config_dirty;   // true when last_used/last_seen needs flushing
  time_t last_config_write; // last debounced flush (CONFIG_WRITE_DEBOUNCE_S)

  // Network options (opt| record, hub-pushed)
  char opt_flags[MAX_OPT_FLAGS + 1];
  time_t opt_flags_ts;

  // Hub Management
  char bot_uuid[64];
  char hub_key[MAX_HUB_KEY_SIZE];    // 88-char base64 — used for config serialization only
  unsigned char hub_key_raw[HUB_KEY_RAW_LEN]; // decoded key; mlock'd and cleansed on exit
  /* hub_remote_ed_pub holds the pinned pubkey of the hub currently being
   * connected to: it is copied from hubs[idx].ed_pub at connect time so the
   * handshake-verification code has a single place to read from. The
   * authoritative per-hub keys live in hubs[]. */
  unsigned char hub_remote_ed_pub[32];
  bool          hub_remote_ed_pub_set;
  hub_entry_t hubs[MAX_SERVERS];
  int hub_count;
  int hub_fd;
  char current_hub[256]; // Track currently connected hub (ip:port)
  bool hub_connecting;
  bool hub_connected;
  bool hub_authenticated;
  unsigned char hub_session_key[32];
  time_t last_hub_connect_attempt;
  time_t last_hub_ping_time;    // Last time we sent a PING to the hub
  time_t last_hub_activity;     // Last time we received a valid PONG/Data from hub
  time_t last_op_request_sent;  // Global rate-limit: last OP-REQ sent across all channels
  time_t hub_connect_time;      // When current hub connection was authenticated
};

// ... [Function Prototypes same as before] ...
void ssl_init_openssl(void);
user_record_t *auth_find_user(bot_state_t *state, const char *user_host,
                              time_t now);
bool auth_is_trusted_bot(const bot_state_t *state, const char *user_host,
                         char *uuid_out, size_t uuid_out_size);
void setup_signals(void);
void daemonize(void);
void change_proc_name(int argc, char *argv[]);
void handle_signal(int signum);
void config_read(bot_state_t *state, const char *filename);
bool config_load(bot_state_t *state, const char *password,
                 const char *filename);
void config_write(const bot_state_t *state, const char *password);
void config_write_local(const bot_state_t *state, const char *password);
void config_notify_hub_if_changed(bot_state_t *state);
chan_t *channel_add(bot_state_t *state, const char *name);
bool channel_remove(bot_state_t *state, const char *name);
chan_t *channel_find(const bot_state_t *state, const char *name);
void channel_list_destroy(bot_state_t *state);
void channel_list_reset_status(bot_state_t *state);
void channel_manager_check_joins(bot_state_t *state);
void irc_connect(bot_state_t *state);
void irc_disconnect(bot_state_t *state);
int irc_printf(bot_state_t *state, const char *format, ...);
void irc_handle_read(bot_state_t *state);
void irc_check_status(bot_state_t *state);
void irc_attempt_nick_change(bot_state_t *state, const char *new_nick);
void irc_generate_new_nick(bot_state_t *state);
/* Server refusal handling (irc_client.c) */
void irc_note_refusal(bot_state_t *state, const char *text, bool ban_numeric);
void irc_note_registered(bot_state_t *state);
void irc_server_block_clear(bot_state_t *state, int idx);
void irc_server_block_remove(bot_state_t *state, int idx);
void irc_server_block_desc(const bot_state_t *state, int idx, char *buf,
                           size_t len);
void parser_handle_line(bot_state_t *state, char *line);
void commands_handle_private_message(bot_state_t *state, const char *nick,
                                     const char *user, const char *host,
                                     const char *dest, char *message);
void bot_comms_send_command(bot_state_t *state, const char *target_nick,
                            const char *format, ...);
_Noreturn void handle_fatal_error(const char *message);
void updater_check_for_updates(bot_state_t *state, const char *nick);
void updater_perform_upgrade(bot_state_t *state, const char *nick,
                             const char *version);
bool util_download_file(const char *url, const char *path);
bool util_sha256_file(const char *path, char *output_hash_hex);
void log_message(log_type_t log_type_flag, const bot_state_t *state,
                 const char *format, ...);
int crypto_aes_gcm_encrypt(const unsigned char *plaintext, int plaintext_len,
                           const unsigned char *key, unsigned char *ciphertext,
                           unsigned char *tag);
int crypto_aes_gcm_decrypt(const unsigned char *ciphertext, int ciphertext_len,
                           const unsigned char *key, unsigned char *plaintext,
                           unsigned char *tag);
int crypto_aes_gcm_encrypt_aad(const unsigned char *plaintext, int plaintext_len,
                                const unsigned char *aad, int aad_len,
                                const unsigned char *key,
                                unsigned char *output_buffer,
                                unsigned char *tag);
int crypto_aes_gcm_decrypt_aad(const unsigned char *input_buffer, int input_len,
                                const unsigned char *aad, int aad_len,
                                const unsigned char *key,
                                unsigned char *plaintext,
                                unsigned char *tag);
int crypto_hkdf_sha256(const unsigned char *ikm, size_t ikm_len,
                       const unsigned char *salt, size_t salt_len,
                       const unsigned char *info, size_t info_len,
                       unsigned char *out, size_t out_len);
/* Derive a 32-byte AES-256-GCM key from a password using PBKDF2-HMAC-SHA256
 * with PBKDF2_ITERATIONS rounds. Returns true on success. */
bool crypto_derive_config_key(const char *password, const unsigned char *salt,
                              unsigned char out_key[32]);
bool crypto_generate_combined_keypair(unsigned char priv_out[HUB_KEY_RAW_LEN],
                                       unsigned char pub_out[HUB_KEY_RAW_LEN]);
/* Verify a 64-byte detached Ed25519 signature over msg with a 32-byte pubkey. */
bool crypto_ed25519_verify(const unsigned char pub[32],
                           const unsigned char *msg, size_t msg_len,
                           const unsigned char sig[64]);
/* Volatile-pointer secure zero. Compiler may NOT elide. */
void secure_wipe(void *ptr, size_t len);
char *base64_encode(const unsigned char *input, int length);
unsigned char *base64_decode(const char *input, int *out_len);
void hub_client_init(bot_state_t *state);
void hub_client_connect(bot_state_t *state);
void hub_client_process(bot_state_t *state);
void hub_client_promote_local_config(bot_state_t *state);
void hub_client_push_config(bot_state_t *state);
void hub_client_push_admin_delta(bot_state_t *state);
bool hub_client_push_delta(bot_state_t *state, const char *key,
                           const char *value, time_t ts);
void hub_client_push_channel(bot_state_t *state, chan_t *chan);
void hub_client_sync_hostmask(bot_state_t *state);
void hub_client_heartbeat(bot_state_t *state);
void hub_client_disconnect(bot_state_t *state);
void hub_client_on_connect(bot_state_t *state);
bool hub_client_request_op(bot_state_t *state, const char *target_uuid,
                           const char *channel);
bool hub_client_send_invite_request(bot_state_t *state, const char *nick,
                                    const char *channel);
bool hub_client_relay_bot_command(bot_state_t *state, const char *target_uuid,
                                  const char *encoded_cipher,
                                  const char *encoded_tag);
void bot_comms_process_payload(bot_state_t *state, const char *payload);
void bot_set_startup_pass(bot_state_t *s, const char *pass);
void bot_get_startup_pass(const bot_state_t *s, char out[MAX_PASS]);
bool bot_has_startup_pass(const bot_state_t *s);
void config_write_with_state_pass(bot_state_t *s);
void config_write_local_with_state_pass(bot_state_t *s);

static inline bool is_valid_bot_nick(const char *nick) {
  return nick && strlen(nick) > 0 && strlen(nick) < MAX_NICK &&
         strchr(nick, '|') == NULL;
}

/* True if buf[0..len) holds a C0 control byte (NUL, CR, LF, ...) or DEL.
 * Decrypted admin/oper/bot commands that match are dropped whole: a CR/LF in
 * an argument would otherwise split into a second IRC command. */
static inline bool has_control_bytes(const void *buf, size_t len) {
  const unsigned char *p = (const unsigned char *)buf;
  for (size_t i = 0; i < len; i++)
    if (p[i] < 0x20 || p[i] == 0x7f)
      return true;
  return false;
}

/* Returns true if option letter `c` is present in the network-pushed
 * opt_flags string.  `c` is matched as-is; flag letters are case-sensitive
 * (uppercase and lowercase are independent options). */
static inline bool is_opt_set(const bot_state_t *state, char c) {
  if (!state || !state->opt_flags[0]) return false;
  return strchr(state->opt_flags, c) != NULL;
}

#ifdef DEBUG
static inline void debug_hex_dump(const char *label, const unsigned char *data,
                                  int len) {
  printf("[DEBUG] %s (%d bytes): ", label, len);
  for (int i = 0; i < len; i++)
    printf("%02x", data[i]);
  printf("\n");
}
#endif
#endif
