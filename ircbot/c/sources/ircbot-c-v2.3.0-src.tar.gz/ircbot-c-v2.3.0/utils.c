#include <arpa/inet.h>
#include <ctype.h>
#ifdef HAVE_CURL
#include <curl/curl.h>
#endif
#include <netdb.h>
#include <openssl/crypto.h>
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <openssl/sha.h>
#include <sys/mman.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#include "bot.h"

void bot_set_startup_pass(bot_state_t *s, const char *pass) {
  /* Store plaintext and lock the page into RAM so it cannot be swapped.
   * See the threat-model comment on bot_state_t.startup_password in bot.h. */
  size_t n = pass ? strlen(pass) : 0;
  if (n >= MAX_PASS) n = MAX_PASS - 1;
  memcpy(s->startup_password, pass ? pass : "", n);
  memset(s->startup_password + n, 0, MAX_PASS - n);
  mlock(s->startup_password, MAX_PASS);
}

void bot_get_startup_pass(const bot_state_t *s, char out[MAX_PASS]) {
  memcpy(out, s->startup_password, MAX_PASS);
  out[MAX_PASS - 1] = '\0';
}

bool bot_has_startup_pass(const bot_state_t *s) {
  return s->startup_password[0] != '\0';
}

void config_write_with_state_pass(bot_state_t *s) {
  char pass[MAX_PASS];
  bot_get_startup_pass(s, pass);
  config_write(s, pass);
  OPENSSL_cleanse(pass, MAX_PASS);
}

void config_write_local_with_state_pass(bot_state_t *s) {
  char pass[MAX_PASS];
  bot_get_startup_pass(s, pass);
  config_write_local(s, pass);
  OPENSSL_cleanse(pass, MAX_PASS);
}

_Noreturn void handle_fatal_error(const char *message) {
  perror(message);
  exit(EXIT_FAILURE);
}

#ifdef HAVE_CURL

static int local_strverscmp(const char *s1, const char *s2) {
  const unsigned char *p1 = (const unsigned char *)s1;
  const unsigned char *p2 = (const unsigned char *)s2;
  int state;
  unsigned char c1, c2;

  while ((c1 = *p1++) == (c2 = *p2++)) {
    if (c1 == '\0') return 0;
  }
  p1--;
  p2--;

  if (isdigit(c1) && isdigit(c2)) {
    state = 0;
    while (1) {
      if (state == 0) {
        if (c1 > c2)
          state = 1;
        else if (c1 < c2)
          state = -1;
      }
      if (!isdigit(*p1))
        c1 = 0;
      else
        c1 = *p1++;
      if (!isdigit(*p2))
        c2 = 0;
      else
        c2 = *p2++;
      if (!c1 && !c2) break;
      if (c1 == 0 && c2 != 0) return -1;
      if (c1 != 0 && c2 == 0) return 1;
    }
    return state;
  }
  return (int)p1[0] - (int)p2[0];
}

static size_t write_callback(void *contents, size_t size, size_t nmemb,
                             void *userp) {
  size_t realsize = size * nmemb;
  http_response_t *mem = (http_response_t *)userp;

  char *ptr = realloc(mem->buffer, mem->size + realsize + 1);
  if (ptr == NULL) {
    printf("ERROR: not enough memory (realloc returned NULL)\n");
    return 0;
  }

  mem->buffer = ptr;
  memcpy(&(mem->buffer[mem->size]), contents, realsize);
  mem->size += realsize;
  mem->buffer[mem->size] = 0;

  return realsize;
}
static size_t write_file_callback(void *ptr, size_t size, size_t nmemb,
                                  FILE *stream) {
  return fwrite(ptr, size, nmemb, stream);
}

static bool fetch_url(const char *url, http_response_t *response) {
  CURL *curl_handle = curl_easy_init();
  if (!curl_handle) return false;

  response->buffer = malloc(1);
  response->size = 0;

  curl_easy_setopt(curl_handle, CURLOPT_URL, url);
  curl_easy_setopt(curl_handle, CURLOPT_WRITEFUNCTION, write_callback);
  curl_easy_setopt(curl_handle, CURLOPT_WRITEDATA, (void *)response);
  curl_easy_setopt(curl_handle, CURLOPT_USERAGENT, "ircbot-updater/1.0");
  curl_easy_setopt(curl_handle, CURLOPT_FOLLOWLOCATION, 1L);
  curl_easy_setopt(curl_handle, CURLOPT_SSL_VERIFYPEER, 1L);
  curl_easy_setopt(curl_handle, CURLOPT_SSL_VERIFYHOST, 2L);

  CURLcode res = curl_easy_perform(curl_handle);
  curl_easy_cleanup(curl_handle);

  return (res == CURLE_OK);
}

static bool download_file(const char *url, const char *outfile) {
  CURL *curl = curl_easy_init();
  if (!curl) return false;

  FILE *fp = fopen(outfile, "wb");
  if (!fp) {
    curl_easy_cleanup(curl);
    return false;
  }

  curl_easy_setopt(curl, CURLOPT_URL, url);
  curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_file_callback);
  curl_easy_setopt(curl, CURLOPT_WRITEDATA, fp);
  curl_easy_setopt(curl, CURLOPT_USERAGENT, "ircbot-updater/1.0");
  curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
  curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 1L);
  curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 2L);

  CURLcode res = curl_easy_perform(curl);
  curl_easy_cleanup(curl);
  fclose(fp);

  return (res == CURLE_OK);
}

static bool verify_sha256(const char *filepath, const char *expected_hash) {
  unsigned char hash[EVP_MAX_MD_SIZE];
  unsigned int hash_len;
  EVP_MD_CTX *ctx;
  const EVP_MD *md;

  ctx = EVP_MD_CTX_new();
  md = EVP_sha256();
  if (ctx == NULL || md == NULL) {
    EVP_MD_CTX_free(ctx);
    return false;
  }
  if (1 != EVP_DigestInit_ex(ctx, md, NULL)) {
    EVP_MD_CTX_free(ctx);
    return false;
  }

  FILE *f = fopen(filepath, "rb");
  if (!f) {
    EVP_MD_CTX_free(ctx);
    return false;
  }
  unsigned char buffer[4096];
  size_t bytes_read = 0;
  while ((bytes_read = fread(buffer, 1, sizeof(buffer), f)) > 0) {
    if (1 != EVP_DigestUpdate(ctx, buffer, bytes_read)) {
      EVP_MD_CTX_free(ctx);
      fclose(f);
      return false;
    }
  }
  if (1 != EVP_DigestFinal_ex(ctx, hash, &hash_len)) {
    EVP_MD_CTX_free(ctx);
    fclose(f);
    return false;
  }
  EVP_MD_CTX_free(ctx);
  fclose(f);

  char hex_hash[EVP_MAX_MD_SIZE * 2 + 1];
  int offset = 0;
  for (unsigned int i = 0; i < hash_len; i++) {
    int written = snprintf(hex_hash + offset,
                           sizeof(hex_hash) - (size_t)offset,
                           "%02x", hash[i]);
    if (written > 0)
      offset += written;
  }
  hex_hash[offset] = '\0';

  return (strcasecmp(hex_hash, expected_hash) == 0);
}

static bool validate_dependency_name(const char *dep) {
  if (!dep || strlen(dep) == 0) return false;
  if (strlen(dep) > 64) return false;

  for (const char *p = dep; *p; p++) {
    if (!isalnum(*p) && *p != '-' && *p != '_' && *p != '.' && *p != '+') {
      return false;
    }
  }
  return true;
}

static bool check_dependency(const char *dep) {
  if (!validate_dependency_name(dep)) {
      return false;
  }

  char command[256];

  if (strcmp(dep, "gcc") == 0 || strcmp(dep, "make") == 0 ||
      strcmp(dep, "tar") == 0 || strcmp(dep, "bash") == 0) {
    snprintf(command, sizeof(command), "command -v %s >/dev/null 2>&1", dep);
  } else {
    snprintf(command, sizeof(command),
             "pkg-config --exists %s >/dev/null 2>&1 || "
             "echo '#include <%s.h>' | gcc -E - >/dev/null 2>&1",
             dep, dep);
  }
  return (system(command) == 0);
}

static bool sanitize_filename(const char *input, char *output, size_t output_size) {
  if (!input || !output || output_size == 0) return false;

  size_t len = 0;
  for (const char *p = input; *p && len < output_size - 1; p++) {
    if (isalnum(*p) || *p == '-' || *p == '_' || *p == '.') {
      output[len++] = *p;
    }
  }
  output[len] = '\0';

  if (len < 8 || strcmp(output + len - 7, ".tar.gz") != 0) {
    return false;
  }
  return len > 0;
}

static bool validate_url(const char *url) {
  if (!url) return false;
  if (strncmp(url, "https://", 8) != 0) {
    return false;
  }
  if (strstr(url, "github.com") == NULL && 
      strstr(url, "githubusercontent.com") == NULL) {
    return false;
  }
  if (strstr(url, ";") || strstr(url, "|") || strstr(url, "&") ||
      strstr(url, "`") || strstr(url, "$") || strstr(url, "$(")) {
    return false;
  }
  return true;
}

/* Fetch the release manifest AND its detached Ed25519 signature, then verify
 * the signature against the compiled-in public key (BOT_UPDATE_PUBKEY_B64)
 * over the EXACT manifest bytes received.  Returns the verified, NUL-terminated
 * manifest text on success (caller frees); returns NULL on ANY failure and
 * sets *err to a short human-readable reason.  Fail-closed: an unconfigured,
 * unreachable, or invalid signature all yield NULL so no unauthenticated
 * manifest is ever parsed, downloaded from, or executed. */
static char *fetch_verified_manifest(const char **err) {
  *err = NULL;

  /* Empty pinned key = updater intentionally disabled. */
  if (BOT_UPDATE_PUBKEY_B64[0] == '\0') {
    *err = "self-updater disabled (no signing key configured)";
    return NULL;
  }

  /* Decode the compiled-in Ed25519 public key (must be exactly 32 raw bytes). */
  int publen = 0;
  unsigned char *pub = base64_decode(BOT_UPDATE_PUBKEY_B64, &publen);
  if (!pub || publen != 32) {
    if (pub) free(pub);
    *err = "configured update public key is malformed";
    return NULL;
  }

  /* Fetch the manifest. */
  http_response_t man;
  man.buffer = NULL;
  man.size = 0;
  if (!fetch_url(BOT_UPDATE_URL, &man)) {
    free(pub);
    if (man.buffer) free(man.buffer);
    *err = "failed to download release manifest";
    return NULL;
  }

  /* Fetch the detached signature (base64 of 64 raw bytes). */
  http_response_t sig;
  sig.buffer = NULL;
  sig.size = 0;
  if (!fetch_url(BOT_UPDATE_SIG_URL, &sig)) {
    free(pub);
    if (man.buffer) free(man.buffer);
    if (sig.buffer) free(sig.buffer);
    *err = "failed to download release signature (releases.txt.sig)";
    return NULL;
  }

  int siglen = 0;
  unsigned char *sigbytes = base64_decode(sig.buffer, &siglen);
  bool ok = (sigbytes && siglen == 64 &&
             crypto_ed25519_verify(pub, (const unsigned char *)man.buffer,
                                   man.size, sigbytes));

  free(pub);
  if (sigbytes) free(sigbytes);
  if (sig.buffer) free(sig.buffer);

  if (!ok) {
    if (man.buffer) free(man.buffer);
    *err = "release manifest signature INVALID — possible tampering";
    return NULL;
  }
  return man.buffer; /* verified manifest; caller frees */
}

void updater_check_for_updates(bot_state_t *state, const char *nick) {
  log_message(L_DEBUG, state, "[DEBUG] updater_check_for_updates called.\n");

  const char *verr = NULL;
  char *manifest = fetch_verified_manifest(&verr);
  if (!manifest) {
    irc_printf(state, "PRIVMSG %s :Update check failed: %s.\r\n",
               nick, verr ? verr : "unknown error");
    return;
  }
  http_response_t response;
  response.buffer = manifest; /* verified bytes; existing parse/free below */
  response.size = 0;

  irc_printf(state, "PRIVMSG %s :--- Available Updates (Current: %s) ---\r\n",
             nick, BOT_VERSION);
  char *saveptr_line;
  char *line = strtok_r(response.buffer, "\n", &saveptr_line);
  int updates_found = 0;

  while (line) {
    if (line[0] == '#') {
      line = strtok_r(NULL, "\n", &saveptr_line);
      continue;
    }

    char version[64], date[64], url[512], hash[128], deps[256];
    if (sscanf(line, "%63s %63s %511s %127s %255s", version, date, url, hash,
               deps) == 5) {
      if (local_strverscmp(version, BOT_VERSION) > 0) {
        updates_found++;
        char deps_status[512] = "[OK]";
        bool all_deps_ok = true;

        char deps_copy[256];
        snprintf(deps_copy, sizeof(deps_copy), "%s", deps);
        char *saveptr_dep;
        char *dep = strtok_r(deps_copy, ",", &saveptr_dep);

        while (dep) {
          if (!check_dependency(dep)) {
            if (all_deps_ok) {
              snprintf(deps_status, sizeof(deps_status), "[FAILED: %s", dep);
            } else {
              strncat(deps_status, ", ",
                      sizeof(deps_status) - strlen(deps_status) - 1);
              strncat(deps_status, dep,
                      sizeof(deps_status) - strlen(deps_status) - 1);
            }
            all_deps_ok = false;
          }
          dep = strtok_r(NULL, ",", &saveptr_dep);
        }
        if (!all_deps_ok)
          strncat(deps_status, "]",
                  sizeof(deps_status) - strlen(deps_status) - 1);

        irc_printf(state, "PRIVMSG %s :%s (%s) - Dependencies: %s\r\n", nick,
                   version, date, deps_status);
      }
    }
    line = strtok_r(NULL, "\n", &saveptr_line);
  }

  if (updates_found == 0) {
    irc_printf(state, "PRIVMSG %s :Bot is up-to-date.\r\n", nick);
  } else {
    irc_printf(
        state,
        "PRIVMSG %s :To upgrade, type: update <version>. IE: update v2.0.0\r\n",
        nick);
  }

  if (response.buffer) {
    free(response.buffer);
  }
}

void updater_perform_upgrade(bot_state_t *state, const char *nick,
                             const char *version_to_install) {
  log_message(L_DEBUG, state,
              "[DEBUG] updater_perform_upgrade called for %s.\n",
              version_to_install);

  http_response_t response;
  char *binary_url = NULL;
  char *expected_hash = NULL;
  char *deps_to_check = NULL;

  /* Downgrade protection: refuse to install anything older than the running
   * build, defeating a replay of an old (but validly signed) manifest that
   * points at a known-vulnerable version. */
  if (local_strverscmp(version_to_install, BOT_VERSION) < 0) {
    irc_printf(state,
               "PRIVMSG %s :Refusing downgrade: %s is older than the running "
               "version %s.\r\n",
               nick, version_to_install, BOT_VERSION);
    return;
  }

  /* Fetch + Ed25519-verify the manifest before trusting any field in it. */
  const char *verr = NULL;
  char *manifest = fetch_verified_manifest(&verr);
  if (!manifest) {
    irc_printf(state, "PRIVMSG %s :Upgrade aborted: %s.\r\n",
               nick, verr ? verr : "unknown error");
    return;
  }
  response.buffer = manifest;
  response.size = 0;

  char *saveptr;
  char *line = strtok_r(response.buffer, "\n", &saveptr);

  while (line) {
    char version[64], date[64], url[512], hash[128], deps[256];
    if (sscanf(line, "%63s %63s %511s %127s %255s", version, date, url, hash,
               deps) == 5) {
      if (strcasecmp(version, version_to_install) == 0) {
        if (!validate_url(url)) {
          irc_printf(state, "PRIVMSG %s :Error: Invalid or untrusted URL in release file.\r\n", nick);
          free(response.buffer);
          return;
        }
        binary_url = strdup(url);
        expected_hash = strdup(hash);
        deps_to_check = strdup(deps);
        break;
      }
    }
    line = strtok_r(NULL, "\n", &saveptr);
  }

  if (!binary_url) {
    irc_printf(state,
               "PRIVMSG %s :Error: Version '%s' not found in release file.\r\n",
               nick, version_to_install);
    if (response.buffer) free(response.buffer);
    /* If strdup(url) failed mid-match while hash/deps succeeded, those two are
     * non-NULL here; free(NULL) is a no-op for the normal not-found path. */
    free(expected_hash);
    free(deps_to_check);
    return;
  }
  if (response.buffer) {
    free(response.buffer);
    response.buffer = NULL;
  }

  char failed_deps[256] = "";
  bool all_deps_ok = true;
  char *dep = strtok_r(deps_to_check, ",", &saveptr);
  while (dep) {
    if (!check_dependency(dep)) {
      if (!all_deps_ok)
        strncat(failed_deps, ", ",
                sizeof(failed_deps) - strlen(failed_deps) - 1);
      strncat(failed_deps, dep, sizeof(failed_deps) - strlen(failed_deps) - 1);
      all_deps_ok = false;
    }
    dep = strtok_r(NULL, ",", &saveptr);
  }
  free(deps_to_check);

  if (!all_deps_ok) {
    irc_printf(
        state,
        "PRIVMSG %s :Error: Cannot upgrade. Missing dependencies: %s\r\n", nick,
        failed_deps);
    free(binary_url);
    free(expected_hash);
    return;
  }

  const char *url_filename = strrchr(binary_url, '/');
  if (url_filename) {
    url_filename++;
  } else {
    url_filename = "ircbot.tar.gz";
  }
  char safe_filename[256];
  if (!sanitize_filename(url_filename, safe_filename, sizeof(safe_filename))) {
    irc_printf(state, "PRIVMSG %s :Error: Invalid filename in URL.\r\n", nick);
    free(binary_url);
    free(expected_hash);
    return;
  }

  irc_printf(state, "PRIVMSG %s :Downloading %s...\r\n", nick, safe_filename);
  if (!download_file(binary_url, safe_filename)) {
    irc_printf(state, "PRIVMSG %s :Error: Failed to download new version.\r\n",
               nick);
    free(binary_url);
    free(expected_hash);
    return;
  }

  irc_printf(state, "PRIVMSG %s :Verifying hash...\r\n", nick);
  if (!verify_sha256(safe_filename, expected_hash)) {
    irc_printf(state,
               "PRIVMSG %s :Error: SHA256 hash mismatch! Aborting upgrade.\r\n",
               nick);
    remove(safe_filename);
    free(binary_url);
    free(expected_hash);
    return;
  }

  free(binary_url);
  free(expected_hash);

  char dir_name[256];
  snprintf(dir_name, sizeof(dir_name), "%s", safe_filename);
  char *tar_gz = strstr(dir_name, ".tar.gz");
  if (tar_gz) {
    *tar_gz = '\0';
  } else {
    irc_printf(
        state,
        "PRIVMSG %s :Error: Invalid archive name. Must end in .tar.gz\r\n",
        nick);
    remove(safe_filename);
    return;
  }
  config_write_with_state_pass(state);
  char backup_path[PATH_MAX + 8];
  snprintf(backup_path, sizeof(backup_path), "%s.backup", state->executable_path);
  rename(state->executable_path, backup_path);

  irc_printf(state, "PRIVMSG %s :Hash verified. Creating upgrade script...\r\n",
             nick);

  /* Create with mode 0700 atomically (no umask-dependent world-readable/
   * writable window on a script we are about to exec); fchmod as belt-and-
   * suspenders.  Avoids the TOCTOU between fopen and a later path-based chmod. */
  int up_fd = open("upgrade.sh", O_WRONLY | O_CREAT | O_TRUNC, 0700);
  FILE *f = (up_fd >= 0) ? fdopen(up_fd, "w") : NULL;
  if (!f) {
    if (up_fd >= 0) close(up_fd);
    irc_printf(state,
               "PRIVMSG %s :Error: Could not create upgrade.sh script.\r\n",
               nick);
    remove(safe_filename);
    rename(backup_path, state->executable_path);
    return;
  }

  fprintf(f, "#!/bin/bash\n");
  fprintf(f, "set -e\n");
  fprintf(f, "OLD_PID=%d\n", getpid());
  fprintf(f, "echo \"[UPGRADE] Waiting for old process (PID: $OLD_PID) to exit...\"\n");
  fprintf(f, "for i in {1..30}; do\n");
  fprintf(f, "  if ! kill -0 $OLD_PID 2>/dev/null; then\n");
  fprintf(f, "    break\n");
  fprintf(f, "  fi\n");
  fprintf(f, "  sleep 1\n");
  fprintf(f, "done\n");
  fprintf(f, "UPGRADE_DIR=\"./bot_build_tmp\"\n");
  fprintf(f, "rm -rf \"$UPGRADE_DIR\"\n");
  fprintf(f, "mkdir \"$UPGRADE_DIR\"\n");
  fprintf(f, "if [ ! -d \"$UPGRADE_DIR\" ]; then\n");
  fprintf(f, "  echo \"[UPGRADE] FATAL: Could not create build directory.\"\n");
  fprintf(f, "  exit 1\n");
  fprintf(f, "fi\n");
  fprintf(f, "echo \"[UPGRADE] Unpacking archive...\"\n");
  fprintf(f, "tar -xzf \"%s\" --strip-components=1 -C \"$UPGRADE_DIR\" 2>/dev/null\n", 
          safe_filename);
  fprintf(f, "if [ $? -ne 0 ]; then\n");
  fprintf(f, "  echo \"[UPGRADE] FATAL: Failed to extract archive.\"\n");
  fprintf(f, "  mv \"%s\" \"%s\" 2>/dev/null\n", backup_path, state->executable_path);
  fprintf(f, "  exit 1\n");
  fprintf(f, "fi\n");
  fprintf(f, "echo \"[UPGRADE] Entering $UPGRADE_DIR and compiling...\"\n");
  fprintf(f, "cd \"$UPGRADE_DIR\"\n");
  fprintf(f, "make clean >/dev/null 2>&1\n");
  fprintf(f, "make 2>&1 | tee make.log\n");
  fprintf(f, "if [ ! -f ircbot ]; then\n");
  fprintf(f, "  echo \"[UPGRADE] FATAL: Make failed. Binary not found.\"\n");
  fprintf(f, "  echo \"[UPGRADE] Restoring backup...\"\n");
  fprintf(f, "  cd ..\n");
  fprintf(f, "  mv \"%s\" \"%s\" 2>/dev/null\n", backup_path, state->executable_path);
  fprintf(f, "  rm -f \"%s\"\n", PID_FILE);
  fprintf(f, "  rm -rf \"$UPGRADE_DIR\"\n");
  fprintf(f, "  rm -f \"%s\"\n", safe_filename);
  fprintf(f, "  exit 1\n");
  fprintf(f, "fi\n");
  fprintf(f, "echo \"[UPGRADE] Moving new binary into place...\"\n");
  fprintf(f, "mv ircbot \"%s\"\n", state->executable_path);
  fprintf(f, "chmod 700 \"%s\"\n", state->executable_path);
  fprintf(f, "cd ..\n");
  fprintf(f, "echo \"[UPGRADE] Removing old PID file...\"\n");
  fprintf(f, "rm -f \"%s\"\n", PID_FILE);
  fprintf(f, "echo \"[UPGRADE] Removing backup...\"\n");
  fprintf(f, "rm -f \"%s\"\n", backup_path);
  fprintf(f, "echo \"[UPGRADE] Scheduling cleanup...\"\n");
  fprintf(f, "(sleep 5; rm -rf \"$UPGRADE_DIR\" \"%s\" \"./upgrade.sh\" 2>/dev/null) &\n",
          safe_filename);
  fprintf(f, "echo \"[UPGRADE] Restarting bot...\"\n");
  fprintf(f, "exec %s\n", state->executable_path);

  (void)fchmod(fileno(f), 0700);
  fclose(f);

  irc_printf(state, "QUIT :Upgrading to %s...\r\n", version_to_install);
  irc_disconnect(state);
  close(state->pid_fd);

  sleep(1);

  execl("./upgrade.sh", "./upgrade.sh", NULL);

  perror("execl failed");
  exit(1);
}
#else /* !HAVE_CURL */
void updater_check_for_updates(bot_state_t *state, const char *nick) {
  irc_printf(state, "PRIVMSG %s :Update feature unavailable - bot compiled without curl support.\r\n", nick);
}

void updater_perform_upgrade(bot_state_t *state, const char *nick,
                             const char *version_to_install) {
  (void)version_to_install;  /* Unused parameter */
  irc_printf(state, "PRIVMSG %s :Update feature unavailable - bot compiled without curl support.\r\n", nick);
}
#endif /* HAVE_CURL */
