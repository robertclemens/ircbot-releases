#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <openssl/crypto.h>
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <pwd.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/file.h>
#include <sys/mman.h>
#include <sys/prctl.h>
#include <sys/resource.h>
#include <sys/select.h>
#include <sys/stat.h>
#include <sys/utsname.h>
#include <termios.h>
#include <unistd.h>

#include "bot.h"

void ssl_init_openssl(void) {
  SSL_load_error_strings();
  OpenSSL_add_ssl_algorithms();
}

/* Process hardening: keep secrets out of anything that lands on disk.
 *
 * PR_SET_DUMPABLE(0) suppresses the core dump on a crash.  Without it a
 * crash hands the bot's identity private key and the config password to
 * /proc/sys/kernel/core_pattern -- on this host that pipes to
 * systemd-coredump, i.e. straight to disk.  It also blocks same-uid ptrace
 * attach, complementing kernel.yama.ptrace_scope.
 *
 * RLIMIT_CORE 0 covers the same ground and, unlike the dumpable flag
 * (which the kernel resets to 1 on execve), is inherited across the
 * updater's exec in utils.c.
 *
 * Neither defends against root.  See docs/admin_cmd_encryption.md.
 * Called before any config or key material is loaded. */
static void harden_process(void) {
  struct rlimit rl = { 0, 0 };
  setrlimit(RLIMIT_CORE, &rl);
#ifdef PR_SET_DUMPABLE
  prctl(PR_SET_DUMPABLE, 0, 0, 0, 0);
#endif
}

static void state_init(bot_state_t *state) {
  memset(state, 0, sizeof(bot_state_t));
  /* Lock the whole state into RAM so no part of it can reach swap or a
   * hibernation image.  bot_state_t is ~301 KB against a 4 MB RLIMIT_MEMLOCK,
   * so locking wholesale is cheaper than tracking individual fields and it
   * covers hub_key[] (base64 of the combined private key), hub_session_key[],
   * startup_password, and anything secret added later.  Best-effort: a failure
   * here is not fatal. */
  if (mlock(state, sizeof(bot_state_t)) != 0)
    fprintf(stderr, "Warning: mlock(state) failed (%s) - "
                    "secrets may reach swap.\n", strerror(errno));
  state->status = S_NONE;
  state->log_type = DEFAULT_LOG_LEVEL;
  state->bot_start_time = time(NULL);
  state->last_pong_time = time(NULL);
  state->nick_release_time = time(NULL) - NICK_TAKE_TIME;
  state->actual_hostname_ts = 0;
  state->current_nick_ts = time(NULL);
  state->server_fd = -1;
  state->server_count = 0;
  state->user_record_count = 0;
  state->mask_record_count = 0;
  state->trusted_bot_count = 0;
  state->config_dirty = false;
  state->last_config_write = 0;
  hub_client_init(state);
  dcc_init(state);
  srand(time(NULL));
}

static void state_destroy(bot_state_t *state) {
  for (int i = 0; i < state->server_count; i++)
    free(state->server_list[i]);
  /* hubs[] is an embedded array (no heap), but wipe the pinned key bytes. */
  for (int i = 0; i < state->hub_count; i++)
    OPENSSL_cleanse(state->hubs[i].ed_pub, sizeof(state->hubs[i].ed_pub));
  channel_list_destroy(state);
  /* The base64 copy of the identity key and the live session key die with
   * the raw key (the whole state is mlock'd in state_init; this is the wipe). */
  OPENSSL_cleanse(state->hub_key,         sizeof(state->hub_key));
  OPENSSL_cleanse(state->hub_session_key, sizeof(state->hub_session_key));
  OPENSSL_cleanse(state->hub_key_raw,     sizeof(state->hub_key_raw));
  munlock(state->hub_key_raw,             sizeof(state->hub_key_raw));
  OPENSSL_cleanse(state->startup_password, MAX_PASS);
  munlock(state->startup_password,         MAX_PASS);
}

static void flush_stdin_if_needed(const char *buffer, size_t len) {
  if (strlen(buffer) == len - 1 && strchr(buffer, '\n') == NULL) {
    int c;
    while ((c = getchar()) != '\n' && c != EOF)
      ;
  }
}

static void get_input(const char *prompt, char *buffer, size_t len) {
  printf("%s: ", prompt);
  fflush(stdout);
  if (fgets(buffer, len, stdin) == NULL) {
    buffer[0] = '\0';
    return;
  }
  flush_stdin_if_needed(buffer, len);
  buffer[strcspn(buffer, "\r\n")] = 0;
}

static void get_password(const char *prompt, char *buffer, size_t len) {
  struct termios oldt, newt;
  printf("%s: ", prompt);
  fflush(stdout);
  tcgetattr(STDIN_FILENO, &oldt);
  newt = oldt;
  newt.c_lflag &= ~ECHO;
  tcsetattr(STDIN_FILENO, TCSANOW, &newt);
  if (fgets(buffer, len, stdin) == NULL) {
    buffer[0] = '\0';
  } else {
    flush_stdin_if_needed(buffer, len);
    buffer[strcspn(buffer, "\r\n")] = 0;
  }
  tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
  printf("\n");
}

static bool get_confirmed_password(const char *prompt, char *buffer,
                                   size_t len) {
  char confirm_buffer[MAX_PASS];
  get_password(prompt, buffer, len);
  get_password("Confirm password", confirm_buffer, sizeof(confirm_buffer));
  if (strcmp(buffer, confirm_buffer) == 0 && strlen(buffer) > 0) {
    printf("Passwords match. Accepted.\n");
    return true;
  } else {
    printf(
        "🚨 ERROR: Passwords do not match or are empty. Please try again.\n");
    memset(buffer, 0, len);
    return false;
  }
}


void daemonize(void) {
  pid_t pid;

  pid = fork();
  if (pid < 0) { perror("fork"); exit(1); }
  if (pid > 0) exit(0);

  if (setsid() < 0) { perror("setsid"); exit(1); }

  pid = fork();
  if (pid < 0) { perror("fork"); exit(1); }
  if (pid > 0) exit(0);

  umask(0027);

  int devnull = open("/dev/null", O_RDWR);
  if (devnull < 0) exit(1);
  dup2(devnull, STDIN_FILENO);
  dup2(devnull, STDOUT_FILENO);
  dup2(devnull, STDERR_FILENO);
  if (devnull > STDERR_FILENO) close(devnull);
}

static void passfile_build_context(char *buf, size_t len) {
  struct stat home_st;
  struct utsname uts;
  struct passwd *pw = getpwuid(getuid());

  memset(&home_st, 0, sizeof(home_st));
  memset(&uts, 0, sizeof(uts));
  if (pw && pw->pw_dir)
    stat(pw->pw_dir, &home_st);
  uname(&uts);

  snprintf(buf, len, "%ju:%ju:%u:%u:%.64s",
           (uintmax_t)home_st.st_ino,
           (uintmax_t)home_st.st_dev,
           (unsigned int)getuid(),
           (unsigned int)getgid(),
           uts.machine);
}

static bool passfile_derive_key(const char *ctx, const unsigned char *salt,
                                unsigned char *key) {
  return PKCS5_PBKDF2_HMAC(ctx, (int)strlen(ctx), salt, SALT_SIZE,
                            PBKDF2_ITERATIONS, EVP_sha256(), 32, key) == 1;
}

static bool passfile_create(const char *path, const char *password) {
  unsigned char salt[SALT_SIZE];
  unsigned char key[32];
  unsigned char tag[GCM_TAG_LEN];
  char ctx[256];
  bool ok = false;

  if (RAND_bytes(salt, sizeof(salt)) != 1) {
    fprintf(stderr, "RNG failure.\n");
    goto done;
  }

  passfile_build_context(ctx, sizeof(ctx));
  if (!passfile_derive_key(ctx, salt, key)) {
    fprintf(stderr, "Key derivation failed.\n");
    goto done;
  }

  int pass_len = (int)strlen(password);
  unsigned char *enc_buf = malloc((size_t)(GCM_IV_LEN + pass_len));
  if (!enc_buf) goto done;

  int enc_len = crypto_aes_gcm_encrypt((const unsigned char *)password,
                                       pass_len, key, enc_buf, tag);
  if (enc_len <= 0) {
    fprintf(stderr, "Encryption failed.\n");
    free(enc_buf);
    goto done;
  }

  int fd = open(path, O_WRONLY | O_CREAT | O_TRUNC, 0600);
  if (fd < 0) { perror("open"); free(enc_buf); goto done; }
  if (fchmod(fd, 0600) != 0) { perror("fchmod"); close(fd); free(enc_buf); goto done; }

  ok = (write(fd, salt,    SALT_SIZE)   == SALT_SIZE &&
        write(fd, enc_buf, enc_len)     == enc_len   &&
        write(fd, tag,     GCM_TAG_LEN) == GCM_TAG_LEN);

  if (!ok) perror("write " PASS_FILE);
  close(fd);
  free(enc_buf);

done:
  memset(key, 0, sizeof(key));
  memset(ctx, 0, sizeof(ctx));
  return ok;
}

static bool passfile_load(const char *path, char *out_pass, size_t out_len) {
  struct stat st;
  bool ok = false;

  if (stat(path, &st) != 0) return false;

  if (st.st_uid != getuid()) {
    fprintf(stderr, "[WARN] %s: wrong owner, ignoring.\n", path);
    return false;
  }
  if ((st.st_mode & 0777) != 0600) {
    fprintf(stderr, "[WARN] %s: must be 0600, ignoring.\n", path);
    return false;
  }

  int min_size = SALT_SIZE + GCM_IV_LEN + 1 + GCM_TAG_LEN;
  if (st.st_size < min_size) return false;

  int fd = open(path, O_RDONLY);
  if (fd < 0) return false;

  size_t total = (size_t)st.st_size;
  unsigned char *buf = malloc(total);
  if (!buf) { close(fd); return false; }

  if (read(fd, buf, total) != (ssize_t)total) {
    close(fd); free(buf); return false;
  }
  close(fd);

  unsigned char *salt    = buf;
  unsigned char *enc_blk = buf + SALT_SIZE;
  int enc_len            = (int)(total - SALT_SIZE - GCM_TAG_LEN);
  unsigned char *tag     = buf + SALT_SIZE + enc_len;

  unsigned char key[32];
  char ctx[256];
  passfile_build_context(ctx, sizeof(ctx));
  if (!passfile_derive_key(ctx, salt, key)) goto done;

  mlock(out_pass, out_len);
  unsigned char *plain = malloc((size_t)enc_len);
  if (!plain) goto done;
  mlock(plain, (size_t)enc_len);

  int dec_len = crypto_aes_gcm_decrypt(enc_blk, enc_len, key, plain, tag);
  if (dec_len > 0 && (size_t)dec_len < out_len) {
    plain[dec_len] = 0;
    memcpy(out_pass, plain, (size_t)dec_len + 1);
    ok = true;
  } else {
    fprintf(stderr, "[WARN] %s: decryption failed (wrong machine or tampered file).\n", path);
  }

  memset(plain, 0, (size_t)enc_len);
  munlock(plain, (size_t)enc_len);
  free(plain);

done:
  memset(key, 0, sizeof(key));
  memset(ctx, 0, sizeof(ctx));
  munlock(out_pass, out_len);
  free(buf);
  return ok;
}

/* Read a user's public key for the wizard: the pasted 88-char key, or a
 * path to their .public.b64.  Shows the fingerprint and asks to confirm. */
static void wizard_read_pubkey(const char *who, char out[COMBINED_KEY_B64 + 1]) {
  for (;;) {
    char in[PATH_MAX];
    unsigned char raw[HUB_KEY_RAW_LEN];
    out[0] = '\0';
    get_input("Public key (paste the 88 chars, or a path to the .public.b64)",
              in, sizeof(in));
    if (in[0] == '\0') {
      printf("ERROR: a public key is required. Make one with "
             "'utils/keygen %s' and give its .public.b64.\n", who);
      continue;
    }
    /* Private and public key files have the same shape; refuse a keygen
     * private file by name before it gets published in the a| record. */
    if (strstr(in, ".private.")) {
      printf("ERROR: that is a PRIVATE key file — it stays with the admin. "
             "Use the matching .public.b64.\n");
      continue;
    }
    if (crypto_pubkey_b64_decode(in, raw)) {
      /* decode succeeded => exactly COMBINED_KEY_B64 chars */
      memcpy(out, in, COMBINED_KEY_B64);
      out[COMBINED_KEY_B64] = '\0';
    } else {
      FILE *f = fopen(in, "r");
      char line[256] = {0};
      if (f) {
        if (!fgets(line, sizeof(line), f)) line[0] = '\0';
        fclose(f);
        line[strcspn(line, " \t\r\n")] = '\0';
      }
      if (!line[0] || !crypto_pubkey_b64_decode(line, raw)) {
        printf("ERROR: not an 88-char public key%s. Use the .public.b64 "
               "(never the .private.b64).\n", f ? " in that file" : "");
        continue;
      }
      memcpy(out, line, COMBINED_KEY_B64);
      out[COMBINED_KEY_B64] = '\0';
    }
    char fp[KEY_FP_LEN + 1], yn[16];
    crypto_key_fingerprint(raw, fp);
    printf("  Key fingerprint for %s: %s\n", who, fp);
    get_input("Use this key? (Y/n)", yn, sizeof(yn));
    if (yn[0] != 'n' && yn[0] != 'N') return;
  }
}

static void run_config_wizard(void) {
  bot_state_t state;
  char config_pass[MAX_PASS];
  char server_buf[MAX_BUFFER];
  char chan_buf[MAX_CHAN];
  char confirm_char[16];
  char admin_name[64];
  char admin_pub[COMBINED_KEY_B64 + 1];
#define WIZARD_MAX_MASKS 20
  char admin_masks[WIZARD_MAX_MASKS][MAX_MASK_LEN];
  int  admin_mask_count = 0;
  bool hub_managed = false;
  memset(admin_name,  0, sizeof(admin_name));
  memset(admin_pub,   0, sizeof(admin_pub));
  memset(admin_masks, 0, sizeof(admin_masks));

  printf("--- IRC Bot Initial Setup ---\n");
  printf("No config file found. Let's create one.\n\n");

  do {
    state_init(&state);
    memset(config_pass, 0, MAX_PASS);
    memset(server_buf, 0, MAX_BUFFER);
    memset(chan_buf, 0, MAX_CHAN);

    /* Reset every mode-dependent field here rather than at its prompt: the
     * prompts now live in mutually exclusive branches, so a wizard restart that
     * switches from standalone to hub-managed would otherwise carry the first
     * pass's admin name/key/masks into the committed config. */
    hub_managed = false;
    admin_mask_count = 0;
    memset(admin_name,  0, sizeof(admin_name));
    memset(admin_pub,   0, sizeof(admin_pub));
    memset(admin_masks, 0, sizeof(admin_masks));

    printf("==========================================\n");
    printf("         Starting Configuration Wizard      \n");
    printf("==========================================\n");

    printf("\n--- Setup Config Master Password ---\n");
    while (!get_confirmed_password("Enter new config password", config_pass,
                                   MAX_PASS))
      ;

    /* Bot identity is generated locally up front so the operator can paste
     * the UUID + pubkey into hub_admin's "Add Bot" prompt before continuing.
     * The private key never leaves this machine. */
    printf("\n--- Bot Identity (Curve25519) ---\n");
    {
      unsigned char priv64[HUB_KEY_RAW_LEN], pub64[HUB_KEY_RAW_LEN];
      if (!crypto_generate_combined_keypair(priv64, pub64)) {
        fprintf(stderr, "🚨 ERROR: Failed to generate bot keypair.\n");
        return;
      }
      /* UUID v4 */
      unsigned char rnd[16];
      if (RAND_bytes(rnd, sizeof(rnd)) != 1) {
        fprintf(stderr, "🚨 ERROR: RAND_bytes failed.\n");
        secure_wipe(priv64, HUB_KEY_RAW_LEN);
        return;
      }
      rnd[6] = (rnd[6] & 0x0f) | 0x40;
      rnd[8] = (rnd[8] & 0x3f) | 0x80;
      snprintf(state.bot_uuid, sizeof(state.bot_uuid),
               "%02x%02x%02x%02x-%02x%02x-%02x%02x-%02x%02x-"
               "%02x%02x%02x%02x%02x%02x",
               rnd[0],rnd[1],rnd[2],rnd[3],rnd[4],rnd[5],rnd[6],rnd[7],
               rnd[8],rnd[9],rnd[10],rnd[11],rnd[12],rnd[13],rnd[14],rnd[15]);
      /* Store priv into the encrypted-config slot (k|<base64>) and the
       * mlock'd raw cache. */
      char *priv_b64 = base64_encode(priv64, HUB_KEY_RAW_LEN);
      char *pub_b64  = base64_encode(pub64,  HUB_KEY_RAW_LEN);
      if (!priv_b64 || !pub_b64) {
        fprintf(stderr, "🚨 ERROR: base64 encode failed.\n");
        if (priv_b64) { secure_wipe(priv_b64, strlen(priv_b64)); free(priv_b64); }
        if (pub_b64)  free(pub_b64);
        secure_wipe(priv64, HUB_KEY_RAW_LEN);
        return;
      }
      snprintf(state.hub_key, sizeof(state.hub_key), "%s", priv_b64);
      memcpy(state.hub_key_raw, priv64, HUB_KEY_RAW_LEN);
      mlock(state.hub_key_raw, HUB_KEY_RAW_LEN);
      secure_wipe(priv64, HUB_KEY_RAW_LEN);
      secure_wipe(priv_b64, strlen(priv_b64));
      free(priv_b64);

      char fp[KEY_FP_LEN + 1];
      crypto_key_fingerprint(pub64, fp);
      printf("\n  Bot UUID:        %s\n", state.bot_uuid);
      printf("  Bot public key:  %s\n", pub_b64);
      printf("  Key fingerprint: %s\n", fp);
      printf("\n  Save these — when registering this bot in hub_admin's\n");
      printf("  'Add Bot' menu the hub will ask for the UUID and pubkey above.\n");
      printf("  (Standalone bots: other bots trust this one with\n");
      printf("  '+bot <nick!user@host> <UUID> <public key>'.)\n");
      printf("\n  Press Enter to continue...");
      fflush(stdout);
      { int c; while ((c = getchar()) != '\n' && c != EOF); }
      free(pub_b64);
    }

    printf("\n--- Setup Bot Nickname ---\n");
    while (true) {
      get_input("Enter bot nick", state.target_nick, MAX_NICK);
      if (is_rfc_nick(state.target_nick)) {
        snprintf(state.current_nick, MAX_NICK, "%s", state.target_nick);
        break;
      }
      if (strchr(state.target_nick, '|'))
        printf("ERROR: Nick cannot contain '|' (reserved as protocol delimiter).\n");
      else if (!is_valid_bot_nick(state.target_nick))
        printf("ERROR: Invalid nick length (1-%d characters).\n", MAX_NICK - 1);
      else
        printf("ERROR: Not a valid IRC nick: start with a letter or one of "
               "[]\\`_^{}, then letters, digits, those or '-'.\n");
    }

    get_input("Enter bot username (ident)", state.user, sizeof(state.user));
    get_input("Enter bot real name (gecos)", state.gecos, sizeof(state.gecos));
    get_input("Enter VHOST IP (optional, press Enter for default [no vhost])",
              state.vhost, sizeof(state.vhost));

    printf("\n--- Setup IRC Server ---\n");
    while (true) {
      get_input("Enter IRC server (e.g., irc.efnet.org)", server_buf,
                MAX_BUFFER);
      if (strlen(server_buf) > 3 && strchr(server_buf, '.'))
        break;
      printf("🚨 ERROR: Invalid server format.\n");
    }

    /* Management mode decides the rest of the wizard.  A hub-managed bot owns
     * none of the records the hub is authoritative for, so prompting for them
     * only produces local state the first sync discards — or, under opt 'h'
     * (OPT_HUB_ONLY_MUTATIONS), state the hub rejects outright and the bot then
     * re-pushes forever with no way to notice.  Ask first, collect only what
     * this bot actually owns. */
    printf("\n--- Management Mode ---\n");
    printf("Hub-managed: admins, usermasks and channels live on the hub and are\n");
    printf("  managed with hub_admin. This bot only needs hub addresses and\n");
    printf("  their pinned public keys.\n");
    printf("Standalone:  this bot owns its own admin list and channels.\n\n");

    char mode_choice[16];
    get_input("Hub-managed? (Y/n)", mode_choice, sizeof(mode_choice));
    hub_managed = (mode_choice[0] != 'n' && mode_choice[0] != 'N');

    if (hub_managed) {
      printf("\n--- Hub Configuration ---\n");
      printf("You'll need each hub's address and public key (the base64 from\n");
      printf("the hub's hub_public.b64 file). Each hub has its own keypair, so\n");
      printf("the key is pinned per hub.\n");

      while (state.hub_count < MAX_SERVERS) {
        char hub_addr[256];
        char hub_pub_input[256];
        bool addr_valid = false;
        bool hpub_valid = false;

        /* Hub address */
        printf("\n--- Hub #%d Address ---\n", state.hub_count + 1);
        while (!addr_valid) {
          get_input("Enter hub address (e.g., 127.0.0.1:6000)", hub_addr,
                    sizeof(hub_addr));
          char *colon = strrchr(hub_addr, ':');
          if (colon && colon != hub_addr && strlen(colon + 1) > 0) {
            int port = atoi(colon + 1);
            if (port > 0 && port < 65536) addr_valid = true;
          }
          if (!addr_valid)
            printf("🚨 ERROR: Invalid format. Use HOST:PORT or IP:PORT.\n");
        }

        /* Reject duplicate addresses. */
        bool dup = false;
        for (int i = 0; i < state.hub_count; i++)
          if (strcmp(state.hubs[i].addr, hub_addr) == 0) { dup = true; break; }
        if (dup) {
          printf("🚨 ERROR: '%s' already added; skipping.\n", hub_addr);
        } else {
          /* Hub public key (44-char raw Ed25519 or 88-char combined). */
          unsigned char hub_pub[32];
          printf("\n--- Hub #%d Public Key ---\n", state.hub_count + 1);
          printf("Paste the base64 from the hub's hub_public.b64 file "
                 "(44 or 88 chars).\n");
          while (!hpub_valid) {
            get_input("Hub public key", hub_pub_input, sizeof(hub_pub_input));
            size_t hp_len = strlen(hub_pub_input);
            while (hp_len > 0 && (hub_pub_input[hp_len-1] == ' ' ||
                                  hub_pub_input[hp_len-1] == '\r' ||
                                  hub_pub_input[hp_len-1] == '\n' ||
                                  hub_pub_input[hp_len-1] == '\t')) {
              hub_pub_input[--hp_len] = '\0';
            }
            int dec_len = 0;
            unsigned char *dec = base64_decode(hub_pub_input, &dec_len);
            if (!dec || (dec_len != 32 && dec_len != HUB_KEY_RAW_LEN)) {
              printf("🚨 ERROR: Expected base64 of a 32-byte Ed25519 key "
                     "(44 chars) or 64-byte combined key (88 chars).\n");
              if (dec) free(dec);
              continue;
            }
            /* First 32 bytes are the Ed25519 portion — what the bot verifies
             * hub challenges against. */
            memcpy(hub_pub, dec, 32);
            secure_wipe(dec, (size_t)dec_len);
            free(dec);
            hpub_valid = true;
          }

          hub_entry_t *he = &state.hubs[state.hub_count];
          memset(he, 0, sizeof(*he));
          snprintf(he->addr, sizeof(he->addr), "%s", hub_addr);
          memcpy(he->ed_pub, hub_pub, 32);
          he->ed_pub_set = true;
          secure_wipe(hub_pub, sizeof(hub_pub));
          state.hub_count++;
          printf("\n✓ Hub added: %s\n", hub_addr);
        }

        if (state.hub_count >= MAX_SERVERS) {
          printf("Reached hub limit (%d).\n", MAX_SERVERS);
          break;
        }
        char more[16];
        get_input("Add another hub? (y/N)", more, sizeof(more));
        if (more[0] != 'y' && more[0] != 'Y') break;
      }
      if (state.hub_count == 0) {
        /* Defensive: the loop above always adds on its first pass, so this is
         * unreachable today.  Fail closed rather than write a hub-managed
         * config with nothing to connect to. */
        printf("\n🚨 ERROR: A hub-managed bot needs at least one hub. "
               "Restarting setup.\n\n");
        continue;
      }
      printf("\n✓ Hub configuration saved (%d hub%s).\n",
             state.hub_count, state.hub_count == 1 ? "" : "s");
      printf("\n  Admins, usermasks and channels for this bot are added with\n");
      printf("  hub_admin (IRC Admin Commands), not here. This wizard assumes\n");
      printf("  the hub network runs with opt 'h' (hub-only mutations), which\n");
      printf("  is the default — it cannot verify that until the first sync.\n");
      printf("  If your hub does not set opt 'h', you can also add them later\n");
      printf("  from IRC with '+admin' and 'join'.\n");
    } else {
      printf("\n--- Setup First Admin ---\n");
      while (true) {
        get_input("Enter admin friendly name (no spaces, e.g. robert)", admin_name, sizeof(admin_name));
        if (strlen(admin_name) > 0 && !strchr(admin_name,' ') && !strchr(admin_name,'|'))
          break;
        printf("ERROR: Name cannot contain spaces or '|'.\n");
      }
      printf("\nThe admin signs in with a Curve25519 key, not a password.\n");
      printf("On the admin's own machine run 'utils/keygen %s' (or see\n", admin_name);
      printf("'help +admin' for an openssl recipe) and give its .public.b64 here.\n");
      printf("The .private.b64 stays with the admin (chmod 600) for their IRC script.\n");
      wizard_read_pubkey(admin_name, admin_pub);
      printf("\n--- Setup Admin Usermasks ---\n");
      printf("Enter usermasks for this admin (e.g. nick!*@*.example.com).\n");
      printf("Press Enter with no mask when done (at least one required).\n\n");
      while (admin_mask_count < WIZARD_MAX_MASKS) {
        char tmp_mask[MAX_MASK_LEN] = {0};
        printf("Usermask %d%s: ", admin_mask_count + 1,
               admin_mask_count == 0 ? " (required)" : " (or Enter to finish)");
        fflush(stdout);
        char *res = fgets(tmp_mask, sizeof(tmp_mask), stdin);
        if (!res) break;
        tmp_mask[strcspn(tmp_mask, "\n")] = '\0';
        if (tmp_mask[0] == '\0') {
          if (admin_mask_count == 0) { printf("ERROR: At least one usermask required.\n"); continue; }
          break;
        }
        if (!strchr(tmp_mask, '!') || !strchr(tmp_mask, '@')) {
          printf("ERROR: Mask must contain '!' and '@'. Try again.\n");
          continue;
        }
        snprintf(admin_masks[admin_mask_count], MAX_MASK_LEN, "%s", tmp_mask);
        admin_mask_count++;
      }

      printf("\n--- Setup Initial Channel ---\n");
      while (true) {
        get_input("Enter channel to join (e.g., #bots) [Optional, Enter to skip]",
                  chan_buf, MAX_CHAN);
        if (strlen(chan_buf) == 0)
          break;
        if (chan_buf[0] == '#' && strlen(chan_buf) > 1)
          break;
        printf("🚨 ERROR: Channel must start with '#'.\n");
      }
    }

    printf("\n==========================================\n");
    printf("     Configuration Summary (Review)         \n");
    printf("==========================================\n");
    printf("Bot Nick: %s\n", state.target_nick);
    printf("IRC Server: %s\n", server_buf);
    if (hub_managed) {
      printf("Mode: HUB-MANAGED (%d hub%s)\n", state.hub_count,
             state.hub_count == 1 ? "" : "s");
      printf("Admins/channels: managed on the hub\n");
    } else {
      printf("Mode: STANDALONE\n");
      printf("Admin: %s (%d usermask%s)\n", admin_name, admin_mask_count,
             admin_mask_count == 1 ? "" : "s");
    {
      unsigned char raw[HUB_KEY_RAW_LEN];
      char fp[KEY_FP_LEN + 1];
      if (crypto_pubkey_b64_decode(admin_pub, raw)) {
        crypto_key_fingerprint(raw, fp);
        printf("Admin key: %s\n", fp);
      }
    }
      printf("Channel: %s\n", chan_buf[0] ? chan_buf : "(none)");
    }

    get_input("Does this look correct? (Y/n)", confirm_char,
              sizeof(confirm_char));
    if (confirm_char[0] == 'n' || confirm_char[0] == 'N') {
      printf("\nRestarting configuration wizard...\n\n");
      for (int i = 0; i < state.hub_count; i++)
        OPENSSL_cleanse(state.hubs[i].ed_pub, sizeof(state.hubs[i].ed_pub));
      state.hub_count = 0;
    } else {
      break;
    }
  } while (true);

  /* Commit — create admin user_record + all collected mask_records.  Skipped
   * entirely for a hub-managed bot: the hub is authoritative for a|/m| records
   * and replaces the bot's set wholesale on the first sync
   * (hub_client_process_config_data), so anything written here is dead on
   * arrival.  The guard is load-bearing, not cosmetic — admin_name/admin_pub
   * are never populated in hub-managed mode, so running this unguarded would
   * persist an admin record with an empty name and no key. */
  if (!hub_managed) {
    unsigned char rnd[16];
    RAND_bytes(rnd, sizeof(rnd));
    rnd[6]=(rnd[6]&0x0f)|0x40; rnd[8]=(rnd[8]&0x3f)|0x80;
    char new_uuid[37];
    snprintf(new_uuid, sizeof(new_uuid),
             "%02x%02x%02x%02x-%02x%02x-%02x%02x-%02x%02x-%02x%02x%02x%02x%02x%02x",
             rnd[0],rnd[1],rnd[2],rnd[3],rnd[4],rnd[5],rnd[6],rnd[7],
             rnd[8],rnd[9],rnd[10],rnd[11],rnd[12],rnd[13],rnd[14],rnd[15]);
    time_t now = time(NULL);
    user_record_t *u = &state.user_records[state.user_record_count++];
    memset(u, 0, sizeof(*u));
    snprintf(u->uuid,     sizeof(u->uuid),     "%s", new_uuid);
    snprintf(u->name,       sizeof(u->name),       "%s", admin_name);
    snprintf(u->pubkey_b64, sizeof(u->pubkey_b64), "%s", admin_pub);
    u->has_pubkey = (admin_pub[0] != '\0');
    u->type = 'a'; u->is_active = true; u->timestamp = now;
    for (int mi = 0; mi < admin_mask_count && state.mask_record_count < MAX_USER_MASKS; mi++) {
      mask_record_t *m = &state.mask_records[state.mask_record_count++];
      memset(m, 0, sizeof(*m));
      snprintf(m->uuid, sizeof(m->uuid), "%s", new_uuid);
      snprintf(m->mask, sizeof(m->mask), "%.255s", admin_masks[mi]);
      m->is_active = true; m->timestamp = now;
    }
  }
  /* Wipe unconditionally — the buffers exist in both modes even though only the
   * standalone branch fills them. */
  secure_wipe(admin_masks, sizeof(admin_masks));
#undef WIZARD_MAX_MASKS
  state.server_list[state.server_count++] = strdup(server_buf);

  if (strlen(chan_buf) > 0) {
    chan_t *c = channel_add(&state, chan_buf);
    if (c) {
      c->is_managed = true; // Active by default
      c->timestamp = time(NULL);
      c->status = C_OUT; // Will join on main loop start
    }
  }

  printf("\n--- Finalizing Configuration ---\n");
  config_write(&state, config_pass);
  printf("\nConfiguration saved to %s.\n", CONFIG_FILE);
  printf("You can now start the bot:\n");
  printf("  Run './ircbot -p' to create a machine-bound password file, then './ircbot'\n");
  printf("  Or run './ircbot' directly and enter the password when prompted.\n");

  /* Release the wizard's local state: frees server_list[] entries (the strdup
   * at the server_buf line) and the channel list, and cleanses key material. */
  state_destroy(&state);
}

int main(int argc, char *argv[]) {
  harden_process();
#ifdef HAVE_CURL
  curl_global_init(CURL_GLOBAL_DEFAULT);
#endif

  bool do_setup = false;
  bool do_passfile = false;
  for (int i = 1; i < argc; i++) {
    if (strcmp(argv[i], "-setup") == 0) do_setup = true;
    if (strcmp(argv[i], "-p")     == 0) do_passfile = true;
  }

  if (do_setup) {
    if (access(CONFIG_FILE, F_OK) == 0) {
      fprintf(stderr, "Error: Config file '%s' already exists.\n", CONFIG_FILE);
      return 1;
    }
    run_config_wizard();
    return 0;
  }

  if (do_passfile) {
    char pass1[MAX_PASS], pass2[MAX_PASS];
    do {
      get_password("Config Password", pass1, sizeof(pass1));
      if (!pass1[0]) {
        fprintf(stderr, "Password cannot be empty.\n");
        return 1;
      }
      get_password("Confirm Config Password", pass2, sizeof(pass2));
      if (strcmp(pass1, pass2) != 0)
        printf("Passwords do not match. Try again.\n");
    } while (strcmp(pass1, pass2) != 0);

    bool ok = passfile_create(PASS_FILE, pass1);
    memset(pass1, 0, sizeof(pass1));
    memset(pass2, 0, sizeof(pass2));
    if (ok) {
      printf("Saved: %s (0600, machine-bound)\n", PASS_FILE);
      return 0;
    }
    fprintf(stderr, "Failed to create %s.\n", PASS_FILE);
    return 1;
  }

  if (access(CONFIG_FILE, F_OK) != 0) {
    fprintf(stderr, "No config file found. First run: ./ircbot -setup\n");
    return 1;
  }

  /* Password resolution: .ircbot.pass → stdin prompt */
  char startup_password[MAX_PASS];
  memset(startup_password, 0, sizeof(startup_password));

  if (!passfile_load(PASS_FILE, startup_password, sizeof(startup_password))) {
    get_password("Config Password", startup_password, sizeof(startup_password));
    if (!startup_password[0]) {
      fprintf(stderr, "No password provided.\n");
      return 1;
    }
  }

  printf("%s %s\n", BOT_NAME, BOT_VERSION);
  daemonize();

  ssl_init_openssl();

  int pid_fd = open(PID_FILE, O_CREAT | O_RDWR, 0600);
  if (pid_fd == -1) {
    memset(startup_password, 0, sizeof(startup_password));
    return 1;
  }
  if (flock(pid_fd, LOCK_EX | LOCK_NB) == -1) {
    /* Read existing PID to report the conflict clearly */
    char existing[16] = "";
    if (read(pid_fd, existing, sizeof(existing) - 1) > 0) {
      existing[strcspn(existing, "\n")] = '\0';
      fprintf(stderr, "Already running (pid %s) — %s\n", existing, PID_FILE);
    } else {
      fprintf(stderr, "Already running — %s locked\n", PID_FILE);
    }
    close(pid_fd);
    memset(startup_password, 0, sizeof(startup_password));
    return 1;
  }
  /* Truncate then write so no stale bytes remain if new PID is shorter */
  if (ftruncate(pid_fd, 0) < 0) {
    close(pid_fd);
    memset(startup_password, 0, sizeof(startup_password));
    return 1;
  }
  char pid_str[16];
  snprintf(pid_str, sizeof(pid_str), "%d\n", getpid());
  if (write(pid_fd, pid_str, strlen(pid_str)) < 0) {
    close(pid_fd);
    memset(startup_password, 0, sizeof(startup_password));
    return 1;
  }

  bot_state_t state;
  state_init(&state);
  state.pid_fd = pid_fd;
  if (!realpath(argv[0], state.executable_path)) {
    close(pid_fd);
    remove(PID_FILE);
    memset(startup_password, 0, sizeof(startup_password));
    return 1;
  }
  setup_signals();

  if (!config_load(&state, startup_password, CONFIG_FILE)) {
    close(pid_fd);
    remove(PID_FILE);
    memset(startup_password, 0, sizeof(startup_password));
    return 1;
  }
  /* Lock the raw key material into RAM so it cannot be swapped to disk. */
  mlock(state.hub_key_raw, sizeof(state.hub_key_raw));
  /* XOR-protect the password in memory after successful load */
  bot_set_startup_pass(&state, startup_password);
  memset(startup_password, 0, sizeof(startup_password));
  state.server_list[state.server_count] = NULL;

  // --- MAIN LOOP ---
  while (!(state.status & S_DIE) && !g_shutdown_flag) {
    irc_check_status(&state);
    channel_manager_check_joins(&state);

    /* Debounced config flush.  auth_mark_used() sets config_dirty whenever it
     * bumps last_seen / last_used, which happens on every successful admin
     * auth; writing on each one would cost a full config rewrite (PBKDF2
     * included) per command.  Flush at most once every
     * CONFIG_WRITE_DEBOUNCE_S seconds instead.  select() below has a 1 s
     * timeout, so this is evaluated at least once a second.
     *
     * Local writer on purpose: these timestamps are this bot's own view of
     * when a mask was last used against it.  Pushing them to the hub would
     * generate mesh sync traffic for every admin command.  Records that the
     * hub is authoritative for still propagate via their own paths
     * (hub_client_push_admin_delta on +admin/-admin, etc.).
     *
     * The cleanup path after this loop calls config_write_with_state_pass()
     * unconditionally, so a still-dirty flag is flushed on clean shutdown. */
    {
      time_t cfg_now = time(NULL);
      if (state.config_dirty &&
          (cfg_now - state.last_config_write) >= CONFIG_WRITE_DEBOUNCE_S) {
        config_write_local_with_state_pass(&state);
        state.config_dirty = false;
        state.last_config_write = cfg_now;
      }
    }

    dcc_check_timeouts(&state);

    // --- HUB GATEKEEPER ---
    // Only execute hub logic if we actually have hubs configured
    if (state.hub_count > 0) {
      hub_client_connect(&state);   // Attempts connection if needed
      hub_client_heartbeat(&state); // Sends pings if authenticated
    }

    fd_set read_fds, write_fds;
    FD_ZERO(&read_fds);
    FD_ZERO(&write_fds);
    int max_fd = -1;

    // Add IRC socket to select
    if (state.server_fd != -1) {
      FD_SET(state.server_fd, &read_fds);
      if (state.server_fd > max_fd)
        max_fd = state.server_fd;
    }

    // Hub Socket (Only if it's actually active)
    if (state.hub_count > 0 && state.hub_fd != -1) {
      FD_SET(state.hub_fd, &read_fds);
      if (!state.hub_connected) {
        FD_SET(state.hub_fd, &write_fds);
      }
      if (state.hub_fd > max_fd)
        max_fd = state.hub_fd;
    }

    // DCC chats (connect in progress, or open)
    dcc_fill_fds(&state, &read_fds, &write_fds, &max_fd);

    struct timeval tv = {1, 0}; // 1 second timeout
    if (max_fd == -1) {
      select(0, NULL, NULL, NULL, &tv);
      continue;
    }

    int activity = select(max_fd + 1, &read_fds, &write_fds, NULL, &tv);

    if (activity > 0) {
      // Handle IRC Data
      if (state.server_fd != -1 && FD_ISSET(state.server_fd, &read_fds)) {
        irc_handle_read(&state);
      }

      // Handle Hub Async Connection Completion
      if (state.hub_fd != -1 && !state.hub_connected &&
          FD_ISSET(state.hub_fd, &write_fds)) {
        state.hub_connected = true;
        hub_client_on_connect(&state);
      }

      // Handle Hub Incoming Data (Pongs, Configs, etc.)
      if (state.hub_fd != -1 && FD_ISSET(state.hub_fd, &read_fds)) {
        hub_client_process(&state);
      }

      dcc_process(&state, &read_fds, &write_fds);
    }
  }

  // --- CLEANUP ---
  dcc_close_all(&state, "Bot shutting down.");
  config_write_with_state_pass(&state);
  irc_disconnect(&state);
  if (state.hub_fd != -1)
    close(state.hub_fd);
  state_destroy(&state);
#ifdef HAVE_CURL
  curl_global_cleanup();
#endif
  /* Unlink while the flock is still held, then release it: the locked pid
   * file is what marks this bot as running, so a replacement that starts in
   * this window is refused rather than having its own pid file unlinked by
   * the copy on its way out (which would hide it from process control and
   * let a third copy start on the same identity).  Same order as irchub. */
  remove(PID_FILE);
  close(state.pid_fd);
  return 0;
}
